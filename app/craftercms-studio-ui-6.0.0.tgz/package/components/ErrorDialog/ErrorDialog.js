/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/CloseRounded';
import Dialog from '@mui/material/Dialog';
import ApiResponseErrorState from '../ApiResponseErrorState';
import { useUnmount } from '../../hooks/useUnmount';
import Box from '@mui/material/Box';
function ErrorDialogBody(props) {
	const { onClose, error, validationErrors } = props;
	useUnmount(props.onClosed);
	return _jsxs(Box, {
		sx: { padding: (theme) => theme.spacing(2) },
		children: [
			_jsx(IconButton, {
				'aria-label': 'close',
				sx: (theme) => ({
					position: 'absolute',
					right: theme.spacing(1),
					top: theme.spacing(1)
				}),
				onClick: () => onClose(),
				size: 'large',
				children: _jsx(CloseIcon, {})
			}),
			error && _jsx(ApiResponseErrorState, { error: error, validationErrors: validationErrors })
		]
	});
}
export function ErrorDialog(props) {
	return _jsx(Dialog, { open: props.open, onClose: props.onClose, children: _jsx(ErrorDialogBody, { ...props }) });
}
export default ErrorDialog;
