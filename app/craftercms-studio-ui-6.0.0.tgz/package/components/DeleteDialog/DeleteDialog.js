/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
import { DeleteDialogContainer } from './DeleteDialogContainer';
import EnhancedDialog from '../EnhancedDialog';
import { FormattedMessage } from 'react-intl';
export function DeleteDialog(props) {
	const { items, isSubmitting, onSuccess, isFetching, error, ...rest } = props;
	return _jsx(EnhancedDialog, {
		title: _jsx(FormattedMessage, { id: 'deleteDialog.title', defaultMessage: 'Delete' }),
		dialogHeaderProps: {
			subtitle: _jsx(FormattedMessage, {
				defaultMessage:
					'Selected items will be deleted along with their child items. Please review items that reference the selected item before deleting as these will end up with broken link references.'
			})
		},
		isSubmitting: isSubmitting,
		...rest,
		children: _jsx(DeleteDialogContainer, {
			items: items,
			onSuccess: onSuccess,
			isFetching: isFetching,
			isSubmitting: isSubmitting,
			error: error
		})
	});
}
export default DeleteDialog;
