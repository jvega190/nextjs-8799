/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
import { useRef, useLayoutEffect, forwardRef } from 'react';
import cn from 'classnames';
import { mergeRefs } from 'react-advanced-cropper';
/** Util component that helps with the rendering of the background image with adjustments like brightness, saturation and contrast. */
// https://advanced-cropper.github.io/react-advanced-cropper/docs/tutorials/image-editor/
export const AdjustableImage = forwardRef((props, ref) => {
	const { src, className, brightness = 0, saturation = 0, contrast = 0, style } = props;
	const imageRef = useRef(null);
	const canvasRef = useRef(null);
	const drawImage = () => {
		const image = imageRef.current;
		const canvas = canvasRef.current;
		if (canvas && image && image.complete) {
			const ctx = canvas.getContext('2d');
			canvas.width = image.naturalWidth;
			canvas.height = image.naturalHeight;
			if (ctx) {
				ctx.filter = [
					`brightness(${100 + brightness * 100}%)`,
					`contrast(${100 + contrast * 100}%)`,
					`saturate(${100 + saturation * 100}%)`
				].join(' ');
				ctx.drawImage(image, 0, 0, image.naturalWidth, image.naturalHeight);
			}
		}
	};
	useLayoutEffect(() => {
		drawImage();
	}, [src, brightness, saturation, contrast]);
	return _jsxs(_Fragment, {
		children: [
			_jsx(
				'canvas',
				{ ref: mergeRefs([ref, canvasRef]), className: cn('adjustable-image-element', className), style: style },
				`${src}-canvas`
			),
			src
				? _jsx(
						'img',
						{
							ref: imageRef,
							className: 'adjustable-image-source',
							src: src,
							onLoad: drawImage,
							style: { display: 'none' }
						},
						`${src}-img`
					)
				: null
		]
	});
});
export default AdjustableImage;
