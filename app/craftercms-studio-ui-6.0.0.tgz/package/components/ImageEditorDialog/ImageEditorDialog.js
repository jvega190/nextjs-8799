/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
import { EnhancedDialog } from '../EnhancedDialog';
import { FormattedMessage } from 'react-intl';
import { ImageEditorDialogContainer } from './ImageEditorDialogContainer';
export function ImageEditorDialog(props) {
	const { path, mimeType, restrictions, writeContent, onCrop, title, subtitle, ...rest } = props;
	return _jsx(EnhancedDialog, {
		title: title ?? _jsx(FormattedMessage, { defaultMessage: 'Image Editor' }),
		subtitle: subtitle,
		...rest,
		maxWidth: 'lg',
		children: _jsx(ImageEditorDialogContainer, {
			path: path,
			mimeType: mimeType,
			onCrop: onCrop,
			restrictions: restrictions,
			writeContent: writeContent,
			...rest
		})
	});
}
export default ImageEditorDialog;
