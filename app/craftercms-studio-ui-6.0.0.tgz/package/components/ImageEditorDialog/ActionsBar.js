/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
import Tooltip from '@mui/material/Tooltip';
import { FormattedMessage } from 'react-intl';
import IconButton from '@mui/material/IconButton';
import CropIcon from '@mui/icons-material/Crop';
import Divider from '@mui/material/Divider';
import RotateLeftIcon from '@mui/icons-material/RotateLeft';
import RotateRightIcon from '@mui/icons-material/RotateRight';
import SaturationIcon from '@mui/icons-material/WaterDrop';
import BrightnessIcon from '@mui/icons-material/Brightness7';
import ContrastIcon from '@mui/icons-material/Contrast';
import FlipIcon from '@mui/icons-material/Flip';
import Box from '@mui/material/Box';
const shouldRenderCrop = (tools) => tools && tools.includes('crop');
const shouldRenderAdjustments = (tools) => tools && tools.includes('adjustments');
const shouldRenderRotate = (tools) => tools && tools.includes('rotate');
const shouldRenderFlip = (tools) => tools && tools.includes('flip');
/** Toolbar of actions for the image editor. Contains crop, rotate, flip and adjustments (saturation, brightness,
 * contrast), and it renders only the actions configured in the `tools` prop */
export function ActionsBar(props) {
	const { tools, currentMode, setMode: setEditorMode, onRotate, onFlip } = props;
	return _jsxs(Box, {
		sx: {
			backgroundColor: (theme) => theme.palette.background.paper,
			p: 1,
			display: 'flex',
			gap: 3,
			justifyContent: 'center'
		},
		children: [
			shouldRenderCrop(tools) &&
				_jsx(Tooltip, {
					title: _jsx(FormattedMessage, { defaultMessage: 'Crop' }),
					children: _jsx(IconButton, {
						color: currentMode === 'crop' ? 'primary' : 'default',
						onClick: () => setEditorMode(currentMode !== 'crop' ? 'crop' : null),
						children: _jsx(CropIcon, {})
					})
				}),
			shouldRenderRotate(tools) &&
				_jsxs(_Fragment, {
					children: [
						shouldRenderCrop(tools) &&
							_jsx(Divider, { orientation: 'vertical', flexItem: true, sx: { height: 30, alignSelf: 'center' } }),
						_jsx(Tooltip, {
							title: _jsx(FormattedMessage, { defaultMessage: 'Rotate left' }),
							children: _jsx(IconButton, { onClick: () => onRotate(-90), children: _jsx(RotateLeftIcon, {}) })
						}),
						_jsx(Tooltip, {
							title: _jsx(FormattedMessage, { defaultMessage: 'Rotate right' }),
							children: _jsx(IconButton, { onClick: () => onRotate(90), children: _jsx(RotateRightIcon, {}) })
						})
					]
				}),
			shouldRenderFlip(tools) &&
				_jsxs(_Fragment, {
					children: [
						_jsx(Tooltip, {
							title: _jsx(FormattedMessage, { defaultMessage: 'Flip vertical' }),
							children: _jsx(IconButton, { onClick: () => onFlip(true, false), children: _jsx(FlipIcon, {}) })
						}),
						_jsx(Tooltip, {
							title: _jsx(FormattedMessage, { defaultMessage: 'Flip horizontal' }),
							children: _jsx(IconButton, {
								onClick: () => onFlip(false, true),
								children: _jsx(FlipIcon, { sx: { transform: 'rotate(90deg)' } })
							})
						})
					]
				}),
			shouldRenderAdjustments(tools) &&
				_jsxs(_Fragment, {
					children: [
						(shouldRenderCrop(tools) || shouldRenderRotate(tools) || shouldRenderFlip(tools)) &&
							_jsx(Divider, { orientation: 'vertical', flexItem: true, sx: { height: 30, alignSelf: 'center' } }),
						_jsx(Tooltip, {
							title: _jsx(FormattedMessage, { defaultMessage: 'Saturation' }),
							children: _jsx(IconButton, {
								color: currentMode === 'saturation' ? 'primary' : 'default',
								onClick: () => setEditorMode(currentMode !== 'saturation' ? 'saturation' : null),
								children: _jsx(SaturationIcon, {})
							})
						}),
						_jsx(Tooltip, {
							title: _jsx(FormattedMessage, { defaultMessage: 'Brightness' }),
							children: _jsx(IconButton, {
								color: currentMode === 'brightness' ? 'primary' : 'default',
								onClick: () => setEditorMode(currentMode !== 'brightness' ? 'brightness' : null),
								children: _jsx(BrightnessIcon, {})
							})
						}),
						_jsx(Tooltip, {
							title: _jsx(FormattedMessage, { defaultMessage: 'Contrast' }),
							children: _jsx(IconButton, {
								color: currentMode === 'contrast' ? 'primary' : 'default',
								onClick: () => setEditorMode(currentMode !== 'contrast' ? 'contrast' : null),
								children: _jsx(ContrastIcon, {})
							})
						})
					]
				})
		]
	});
}
export default ActionsBar;
