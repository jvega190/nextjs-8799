/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2025 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { DialogBody } from '../DialogBody';
import { DialogFooter } from '../DialogFooter';
import { useEffect, useRef, useState } from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import SecondaryButton from '../SecondaryButton';
import { FormattedMessage } from 'react-intl';
import PrimaryButton from '../PrimaryButton';
import Grid from '@mui/material/Grid';
import FormControl from '@mui/material/FormControl';
import { useSpreadState } from '../../hooks/useSpreadState';
import { Cropper } from 'react-advanced-cropper';
import 'react-advanced-cropper/dist/style.css';
import useActiveSiteId from '../../hooks/useActiveSiteId';
import { uploadFile } from '../../services/content';
import TextField from '@mui/material/TextField';
import CachedIcon from '@mui/icons-material/Cached';
import { getFileExtension, getFileNameFromPath, removeExtension } from '../../utils/path';
import { pushDialog } from '../../state/actions/dialogStack';
import { useDispatch } from 'react-redux';
import { createComponentId } from '../../utils/system';
import { applyAssetNameRules, isBlobUrl } from '../../utils/content';
import { isEmpty } from '../../utils/string';
import { Slider } from '@mui/material';
import AdjustableBackground from './AdjustableBackground';
import ActionsBar from './ActionsBar';
import Alert from '@mui/material/Alert';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
const sliderModes = ['saturation', 'brightness', 'contrast'];
const initialAdjustments = { brightness: 0, saturation: 0, contrast: 0 };
const maxHeight = 550;
const getBlob = (cropper, fileExtension, mimeType) => {
	if (!cropper) return null;
	return new Promise((resolve) => {
		const croppedCanvas = cropper.getCanvas();
		if (!croppedCanvas) {
			resolve(null);
			return;
		}
		const ext = (fileExtension || '').toLowerCase();
		const mime =
			mimeType ??
			(ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : ext === 'svg' ? 'image/svg+xml' : 'image/jpeg');
		const quality = mime === 'image/jpeg' ? 0.92 : undefined;
		croppedCanvas.toBlob(
			(blob) => {
				if (!blob) return;
				resolve(blob);
			},
			mime,
			quality
		);
	});
};
export function ImageEditorDialogContainer(props) {
	const {
		path,
		mimeType,
		onCrop,
		restrictions,
		writeContent,
		tools = ['crop', 'rotate', 'flip', 'adjustments'],
		onClose
	} = props;
	const cropperRef = useRef(null);
	const siteId = useActiveSiteId();
	const fileExtension = getFileExtension(path);
	const fileNameWithoutExtension = removeExtension(getFileNameFromPath(path));
	const [overwriteState, setOverwriteState] = useSpreadState({
		blobToWrite: null,
		fileName: fileNameWithoutExtension
	});
	const [coordinates, setCoordinates] = useState(null);
	const dispatch = useDispatch();
	const [editorMode, setEditorMode] = useState(tools.includes('crop') ? 'crop' : null);
	const [adjustments, setAdjustments] = useState(initialAdjustments);
	const cropperEnabled = editorMode && editorMode === 'crop';
	const isSliderMode = editorMode && sliderModes.includes(editorMode);
	const isNewFileName = overwriteState.fileName !== fileNameWithoutExtension;
	useEffect(() => {
		if (path && isBlobUrl(path)) {
			return () => URL.revokeObjectURL(path);
		}
	}, [path]);
	const handleSubmit = (newPath) => {
		const cropper = cropperRef.current;
		if (!cropper) return;
		getBlob(cropper, fileExtension, mimeType).then((blob) => {
			if (!blob) return;
			onCrop?.(blob, newPath);
		});
	};
	const handleChange = (cropper) => {
		setCoordinates(cropper.getCoordinates());
	};
	/** Called when the `writeContent` param is true. Uploads the cropped image to the specified path.
	 *
	 * @param writePath The path where the cropped image will be saved.
	 */
	const handleWriteContent = (writePath) => {
		const cropper = cropperRef.current;
		if (!cropper) return;
		const fileName = getFileNameFromPath(writePath);
		const formData = new FormData();
		getBlob(cropper, fileExtension, mimeType).then((blob) => {
			if (!blob) return;
			formData.append('file', blob, fileName);
			formData.append('path', writePath);
			uploadFile(siteId, formData).subscribe({
				next: () => {
					handleSubmit(writePath !== path ? writePath : null);
				},
				error: ({ response }) => {
					dispatch(
						pushDialog({
							component: createComponentId('ErrorDialog'),
							props: { error: response?.response }
						})
					);
				}
			});
		});
	};
	/** Handles renaming the file when the user changes the file name and clicks "Accept". */
	const handleRename = () => {
		const newFileName = `${overwriteState.fileName}.${fileExtension}`;
		const newPath = path.replace(getFileNameFromPath(path), newFileName);
		handleWriteContent(newPath);
	};
	const handleReset = () => {
		setCoordinates({
			height: restrictions?.height ?? restrictions?.maxHeight,
			width: restrictions?.width ?? restrictions?.maxWidth
		});
		setAdjustments(initialAdjustments);
		cropperRef.current?.reset();
	};
	// region Image editing functions
	const rotate = (angle) => {
		if (cropperRef.current) {
			cropperRef.current.rotateImage(angle);
		}
	};
	const flip = (horizontal, vertical) => {
		if (cropperRef.current) {
			cropperRef.current.flipImage(horizontal, vertical);
		}
	};
	const onChangeAdjustment = (value) => {
		if (isSliderMode) {
			setAdjustments((previousValue) => ({
				...previousValue,
				[editorMode]: value / 100
			}));
		}
	};
	// endregion
	return _jsxs(_Fragment, {
		children: [
			_jsx(DialogBody, {
				children: _jsxs(Grid, {
					container: true,
					spacing: 2,
					children: [
						writeContent &&
							_jsx(Grid, {
								size: { xs: 12, md: 6 },
								rowSpacing: 2,
								container: true,
								alignItems: 'start',
								justifyContent: 'space-between',
								children: _jsxs(FormControl, {
									fullWidth: true,
									children: [
										_jsx(TextField, {
											label: _jsx(FormattedMessage, { defaultMessage: 'File name' }),
											size: 'small',
											slotProps: {
												inputLabel: { shrink: true },
												input: {
													endAdornment: _jsxs(Box, {
														component: 'span',
														sx: { color: (theme) => theme.palette.text.disabled },
														children: ['.', fileExtension]
													}),
													sx: {
														maxWidth: { md: 500 },
														...(writeContent &&
															!isNewFileName && {
																borderBottomRightRadius: 0,
																borderBottomLeftRadius: 0,
																borderBottomWidth: 0
															})
													}
												}
											},
											variant: 'outlined',
											value: overwriteState.fileName,
											onChange: (e) => setOverwriteState({ fileName: applyAssetNameRules(e.target.value) })
										}),
										writeContent &&
											!isNewFileName &&
											_jsx(Alert, {
												severity: 'warning',
												sx: {
													maxWidth: { md: 500 },
													py: 0,
													borderTopLeftRadius: 0,
													borderTopRightRadius: 0,
													borderTop: 'none'
												},
												iconMapping: {
													warning: _jsx(WarningAmberRoundedIcon, { sx: { fontSize: '16px', alignSelf: 'center' } })
												},
												children: _jsx(FormattedMessage, {
													defaultMessage: 'File already exists. Rename to avoid overwriting existing.'
												})
											})
									]
								})
							}),
						_jsx(Grid, {
							size: { xs: 12, md: 6 },
							container: true,
							alignItems: 'start',
							children: _jsxs(Box, {
								display: 'flex',
								gap: 2,
								children: [
									_jsx(FormControl, {
										children: _jsx(TextField, {
											label: _jsx(FormattedMessage, { defaultMessage: 'Width' }),
											size: 'small',
											slotProps: { inputLabel: { shrink: true } },
											variant: 'outlined',
											disabled: true,
											value: coordinates?.width ?? ''
										})
									}),
									_jsx(FormControl, {
										children: _jsx(TextField, {
											label: _jsx(FormattedMessage, { defaultMessage: 'Height' }),
											size: 'small',
											slotProps: { inputLabel: { shrink: true } },
											variant: 'outlined',
											disabled: true,
											value: coordinates?.height ?? ''
										})
									}),
									_jsx(FormControl, {
										children: _jsx(Button, {
											onClick: handleReset,
											startIcon: _jsx(CachedIcon, {}),
											children: _jsx(FormattedMessage, { defaultMessage: 'Reset' })
										})
									})
								]
							})
						}),
						_jsxs(Grid, {
							size: { xs: 12 },
							children: [
								_jsx(Box, {
									maxHeight: maxHeight,
									children: _jsx(Cropper, {
										ref: cropperRef,
										src: path,
										minHeight: restrictions?.height ?? restrictions?.minHeight,
										minWidth: restrictions?.width ?? restrictions?.minWidth,
										maxHeight: restrictions?.height ?? restrictions?.maxHeight,
										maxWidth: restrictions?.width ?? restrictions?.maxWidth,
										stencilProps: {
											handlers: cropperEnabled && !(restrictions?.height && restrictions?.width),
											movable: cropperEnabled,
											resizable: cropperEnabled,
											lines: cropperEnabled
										},
										onUpdate: handleChange,
										backgroundComponent: AdjustableBackground,
										backgroundProps: adjustments,
										backgroundWrapperProps: {
											scaleImage: cropperEnabled,
											moveImage: cropperEnabled
										},
										style: { maxHeight: maxHeight }
									})
								}),
								isSliderMode &&
									_jsx(Box, {
										sx: { px: 1, mt: 1 },
										children: _jsx(Slider, {
											size: 'small',
											min: -100,
											max: 100,
											marks: [{ value: 0 }],
											value: isSliderMode ? Math.trunc(adjustments[editorMode] * 100) : 0,
											'aria-label': 'Slider',
											valueLabelDisplay: 'auto',
											onChange: (_, value) => onChangeAdjustment(value)
										})
									}),
								!tools.every((tool) => tool === 'crop') &&
									_jsx(ActionsBar, {
										tools: tools,
										currentMode: editorMode,
										setMode: setEditorMode,
										onRotate: rotate,
										onFlip: flip
									})
							]
						})
					]
				})
			}),
			_jsxs(DialogFooter, {
				children: [
					_jsx(SecondaryButton, {
						onClick: (e) => onClose?.(e, null),
						children: _jsx(FormattedMessage, { defaultMessage: 'Cancel' })
					}),
					!writeContent || (writeContent && isNewFileName)
						? _jsx(PrimaryButton, {
								disabled: isEmpty(overwriteState.fileName),
								onClick: () => {
									if (writeContent) {
										handleRename();
									} else {
										handleSubmit();
									}
								},
								children: _jsx(FormattedMessage, { defaultMessage: 'Accept' })
							})
						: _jsx(PrimaryButton, {
								disabled: !coordinates?.width || !coordinates?.height,
								onClick: () => handleWriteContent(path),
								children: _jsx(FormattedMessage, { defaultMessage: 'Overwrite' })
							})
				]
			})
		]
	});
}
export default ImageEditorDialogContainer;
