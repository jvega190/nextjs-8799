/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import MuiDialogTitle from '@mui/material/DialogTitle';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import palette from '../../styles/palette';
import Box from '@mui/material/Box';
export function DialogTitle(props) {
	const { onClose, title, subtitle, sxs } = props;
	return _jsxs(MuiDialogTitle, {
		sx: { margin: 0, padding: '13px 20px 11px', background: palette.white, ...sxs?.root },
		children: [
			_jsxs(Box, {
				sx: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', ...sxs?.title },
				children: [
					_jsx(Typography, { variant: 'h6', children: title }),
					onClose
						? _jsx(IconButton, {
								'aria-label': 'close',
								onClick: onClose,
								sx: sxs?.closeIcon,
								size: 'large',
								children: _jsx(CloseIcon, {})
							})
						: null
				]
			}),
			subtitle &&
				_jsx(Typography, {
					variant: 'subtitle1',
					sx: { fontSize: '14px', lineHeight: '18px', paddingRight: '35px', ...sxs?.subtitle },
					children: subtitle
				})
		]
	});
}
export default DialogTitle;
