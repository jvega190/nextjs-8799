/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useMemo, useState } from 'react';
import { GlobalAppContextProvider, useGlobalAppState } from '../../GlobalApp';
import useReference from '../../../hooks/useReference';
import { useActiveSiteId } from '../../../hooks/useActiveSiteId';
import SiteTools from '../SiteTools';
import { SiteToolsContext } from '../siteToolsContext';
import useEnhancedDialogContext from '../../EnhancedDialog/useEnhancedDialogContext';
export const EmbeddedSiteToolsContainer = (props) => {
	const [width, setWidth] = useState(240);
	const [activeToolId, setActiveToolId] = useState();
	const [{ openSidebar }] = useGlobalAppState();
	const siteTools = useReference('craftercms.siteTools');
	const tools = siteTools?.tools;
	const site = useActiveSiteId();
	const contextValue = useMemo(
		() => ({ setTool: (id) => setActiveToolId(id.replace(/^\//, '')), activeToolId }),
		[activeToolId]
	);
	const { updateSubmittingOrHasPendingChanges } = useEnhancedDialogContext();
	const onNavItemClick = (id) => {
		setActiveToolId(id);
	};
	const onSubmittingAndOrPendingChange =
		props.onSubmittingAndOrPendingChange ??
		((value) => {
			updateSubmittingOrHasPendingChanges(value);
		});
	return _jsx(SiteToolsContext.Provider, {
		value: contextValue,
		children: _jsx(SiteTools, {
			site: site,
			sidebarWidth: width,
			onWidthChange: setWidth,
			onNavItemClick: onNavItemClick,
			sidebarBelowToolbar: true,
			hideSidebarLogo: true,
			showAppsButton: false,
			hideSidebarSiteSwitcher: true,
			activeToolId: activeToolId,
			openSidebar: openSidebar || !activeToolId,
			tools: tools,
			sx: { height: '100%' },
			onSubmittingAndOrPendingChange: onSubmittingAndOrPendingChange,
			onMinimize: () => props.onMinimize?.(),
			mountMode: 'dialog'
		})
	});
};
export function EmbeddedSiteTools(props) {
	return _jsx(GlobalAppContextProvider, { children: _jsx(EmbeddedSiteToolsContainer, { ...props }) });
}
export default EmbeddedSiteTools;
