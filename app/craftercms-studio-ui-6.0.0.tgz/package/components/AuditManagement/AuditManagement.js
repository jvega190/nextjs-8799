/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import GlobalAppToolbar from '../GlobalAppToolbar';
import { FormattedMessage, useIntl } from 'react-intl';
import { useCallback, useEffect, useState } from 'react';
import { fetchAuditLog, fetchAuditLogEntry } from '../../services/audit';
import AuditGridUI from '../AuditGrid';
import { fetchAll } from '../../services/users';
import { Operations, OperationsMessages } from './operations';
import moment from 'moment-timezone';
import AuditLogEntryParametersDialog from '../AuditLogEntryParametersDialog';
import { nnou } from '../../utils/object';
import Button from '@mui/material/Button';
import AuditGridSkeleton from '../AuditGrid/AuditGridSkeleton';
import { useMount } from '../../hooks/useMount';
import { useSpreadState } from '../../hooks/useSpreadState';
import { useSiteList } from '../../hooks/useSiteList';
import Paper from '@mui/material/Paper';
import { useEnhancedDialogState } from '../../hooks/useEnhancedDialogState';
import { ApiResponseErrorState } from '../ApiResponseErrorState';
import { useDispatch } from 'react-redux';
import { pushErrorDialog } from '../../utils/system';
export function AuditManagement(props) {
	const { site, embedded, showAppsButton } = props;
	const [auditLogs, setAuditLogs] = useState(null);
	const [error, setError] = useState();
	const sites = useSiteList();
	const [users, setUsers] = useState();
	const [options, setOptions] = useSpreadState({
		offset: 0,
		limit: 10,
		sort: 'date',
		order: 'DESC',
		siteId: site
	});
	const [parametersLookup, setParametersLookup] = useSpreadState({});
	const [dialogParams, setDialogParams] = useState([]);
	const { formatMessage } = useIntl();
	const hasActiveFilters = Object.keys(options).some((key) => {
		return (
			!(Boolean(site) ? ['limit', 'offset', 'sort', 'siteId'] : ['limit', 'offset', 'sort']).includes(key) &&
			nnou(options[key])
		);
	});
	const [page, setPage] = useState(0);
	const auditLogEntryParametersDialogState = useEnhancedDialogState();
	const dispatch = useDispatch();
	const refresh = useCallback(() => {
		fetchAuditLog(options).subscribe({
			next: (logs) => {
				setAuditLogs(logs);
			},
			error: ({ response }) => {
				setError(response.response);
			}
		});
	}, [options]);
	useMount(() => {
		fetchAll().subscribe((users) => {
			setUsers(users);
		});
	});
	useEffect(() => {
		refresh();
	}, [refresh]);
	const onPageChange = (pageNumber) => {
		setPage(pageNumber);
		setOptions({ offset: pageNumber * options.limit });
	};
	const onPageSizeChange = (pageSize) => {
		setPage(0);
		setOptions({ offset: 0, limit: pageSize });
	};
	const onFilterChange = ({ id, value }) => {
		setPage(0);
		setOptions({ [id]: value, offset: 0 });
	};
	const onResetFilter = (id) => {
		let filters = {};
		if (Array.isArray(id)) {
			id.forEach((key) => {
				filters[key] = undefined;
			});
		} else {
			filters[id] = undefined;
		}
		setOptions(filters);
	};
	const onResetFilters = () => {
		const { limit, offset, sort, siteId, ...rest } = options;
		Object.keys(rest).forEach((key) => {
			rest[key] = undefined;
		});
		setOptions({ limit, offset, sort, siteId: Boolean(site) ? site : undefined, ...rest });
	};
	const onFetchParameters = (id) => {
		if (parametersLookup[id]?.length) {
			setDialogParams(parametersLookup[id]);
			auditLogEntryParametersDialogState.onOpen();
		} else {
			fetchAuditLogEntry(id, site).subscribe({
				next(response) {
					setParametersLookup({ [id]: response.parameters });
					if (response.parameters.length) {
						setDialogParams(response.parameters);
						auditLogEntryParametersDialogState.onOpen();
					}
				},
				error({ response }) {
					dispatch(pushErrorDialog({ props: { error: response.response } }));
				}
			});
		}
	};
	const onShowParametersDialogClosed = () => {
		setDialogParams([]);
	};
	return _jsxs(Paper, {
		elevation: 0,
		children: [
			_jsx(GlobalAppToolbar, {
				title: !embedded && _jsx(FormattedMessage, { id: 'GlobalMenu.Audit', defaultMessage: 'Audit' }),
				rightContent: _jsx(Button, {
					disabled: !hasActiveFilters,
					variant: 'text',
					color: 'primary',
					onClick: () => onResetFilters(),
					children: _jsx(FormattedMessage, { id: 'auditGrid.clearFilters', defaultMessage: 'Clear filters' })
				}),
				showHamburgerMenuButton: !embedded,
				showAppsButton: showAppsButton
			}),
			error
				? _jsx(ApiResponseErrorState, { error: error })
				: auditLogs
					? _jsx(AuditGridUI, {
							page: page,
							auditLogs: auditLogs,
							sites: sites,
							users: users,
							siteMode: Boolean(site),
							parametersLookup: parametersLookup,
							onFetchParameters: onFetchParameters,
							onPageChange: onPageChange,
							onResetFilters: onResetFilters,
							onResetFilter: onResetFilter,
							onPageSizeChange: onPageSizeChange,
							onFilterChange: onFilterChange,
							filters: options,
							hasActiveFilters: hasActiveFilters,
							timezones: moment.tz.names(),
							operations: Operations.map((id) => ({ id, value: id, name: formatMessage(OperationsMessages[id]) })),
							origins: [
								{ id: 'GIT', name: 'GIT', value: 'GIT' },
								{ id: 'API', name: 'API', value: 'API' }
							]
						})
					: _jsx(AuditGridSkeleton, { siteMode: Boolean(site), numOfItems: auditLogs?.length ?? 10, filters: options }),
			_jsx(AuditLogEntryParametersDialog, {
				open: auditLogEntryParametersDialogState.open,
				onClose: auditLogEntryParametersDialogState.onClose,
				onClosed: onShowParametersDialogClosed,
				parameters: dialogParams,
				hasPendingChanges: auditLogEntryParametersDialogState.hasPendingChanges,
				isMinimized: auditLogEntryParametersDialogState.isMinimized,
				isSubmitting: auditLogEntryParametersDialogState.isSubmitting
			})
		]
	});
}
export default AuditManagement;
