/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import EnhancedDialog from '../EnhancedDialog';
import { useEffect, useRef, useState } from 'react';
import FormsEngine from './FormsEngine';
import { dialogClasses } from '@mui/material/Dialog';
import { FormsEngineDialogContext } from './lib/formsEngineContext';
export function FormsEngineDialog(props) {
	const { formProps, ...rest } = props;
	const [disableEnforceFocus, setDisableEnforceFocus] = useState(false);
	const stableFormsEngineDialogContextRef = useRef(undefined);
	if (!stableFormsEngineDialogContextRef.current) {
		stableFormsEngineDialogContextRef.current = {
			disableEnforceFocus,
			setDisableEnforceFocus
		};
	}
	// Keep context value in sync with state
	useEffect(() => {
		stableFormsEngineDialogContextRef.current.disableEnforceFocus = disableEnforceFocus;
	}, [disableEnforceFocus]);
	return _jsx(EnhancedDialog, {
		sx: {
			[`& > .${dialogClasses.container} > .${dialogClasses.paper}`]: {
				height: '100vh'
			}
		},
		...rest,
		omitHeader: true,
		maxWidth: 'xl',
		title: 'Content Form',
		'data-area-id': 'forms-engine-dialog-root',
		disableEnforceFocus: disableEnforceFocus,
		children: _jsx(FormsEngineDialogContext.Provider, {
			value: stableFormsEngineDialogContextRef.current,
			children: _jsx(FormsEngine, {
				onMinimize: props.onMinimize,
				onFullScreen: props.onFullScreen,
				onCancelFullScreen: props.onCancelFullScreen,
				...formProps,
				isDialog: true
			})
		})
	});
}
export default FormsEngineDialog;
