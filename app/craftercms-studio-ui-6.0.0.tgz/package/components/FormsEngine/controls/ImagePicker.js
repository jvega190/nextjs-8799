/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useEffect, useRef, useState } from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import CardMedia from '@mui/material/CardMedia';
import IconButton from '@mui/material/IconButton';
import { DeleteOutlined, DownloadOutlined, EditOutlined } from '@mui/icons-material';
import { FormsEngineField } from '../components/FormsEngineField';
import useEnv from '../../../hooks/useEnv';
import { FormattedMessage } from 'react-intl';
import { useConsolidatedImagePickerData } from '../dataSourceHooks/useConsolidatedImagePickerData';
import { menuItemClasses } from '@mui/material/MenuItem';
import { listItemIconClasses } from '@mui/material/ListItemIcon';
import Menu from '@mui/material/Menu';
import { useImageInfo } from '../../../hooks/useImageInfo';
import { svgIconClasses } from '@mui/material/SvgIcon';
import Dialog from '@mui/material/Dialog';
import { DialogHeader } from '../../DialogHeader';
import { DialogBody } from '../../DialogBody';
import { processPathMacros } from '../../../utils/path';
import { ensureSingleSlash } from '../../../utils/string';
import { useDispatch } from 'react-redux';
import { useItemContext, useItemMetaContext } from '../lib/formsEngineContext';
import { ContentPicker } from '../components/ContentPicker';
import useActiveSiteId from '../../../hooks/useActiveSiteId';
import Tooltip from '@mui/material/Tooltip';
import { useExtractDataSources } from '../dataSourceHooks/useExtractDataSources';
import {
	createMediaMenuOptions,
	downloadMedia,
	getImageRestrictionMessages,
	showBrowseFilesDialog,
	showImageCropDialog,
	showSearchDialog,
	showSingleFileUploadDialog
} from '../lib/controlHelpers';
import Skeleton from '@mui/material/Skeleton';
import { nnou, nou } from '../../../utils/object';
import { validateImageRestrictions } from '../../../utils/content';
export function ImagePicker(props) {
	const { field, value: valueProp, setValue, contentType, autoFocus, readonly: formReadonly } = props;
	const siteId = useActiveSiteId();
	const { guestBase } = useEnv();
	const contextItem = useItemContext();
	const { id, pathInSite } = useItemMetaContext();
	// region field properties/validations
	const readonly = formReadonly || field.properties?.readonly?.value;
	const defaultValue = field.defaultValue;
	const restrictions = {
		height: field.validations?.height?.value,
		width: field.validations?.width?.value,
		maxHeight: field.validations?.maxHeight?.value,
		maxWidth: field.validations?.maxWidth?.value,
		minHeight: field.validations?.minHeight?.value,
		minWidth: field.validations?.minWidth?.value
	};
	// endregion
	const value = nnou(valueProp) ? valueProp : (defaultValue ?? '');
	const { imageInfo, isFetchingDimensions, isFetchingMetadata, errorDimensions, errorMetadata } = useImageInfo(
		value ? ensureSingleSlash(`${guestBase}${value}`) : ''
	);
	const hasValue = Boolean(value);
	const dataSourceSummary = useConsolidatedImagePickerData(useExtractDataSources(contentType, field, 'imageManager'));
	const { allowedBrowsePaths, allowedUploadPaths, allowedSearchPaths } = dataSourceSummary;
	const addMenuButtonRef = useRef(undefined);
	const [addMenuOpen, setAddMenuOpen] = useState(false);
	const dispatch = useDispatch();
	const [openPickerDialog, setOpenPickerDialog] = useState(false);
	const [pickerType, setPickerType] = useState(null);
	useEffect(() => {
		// If there's a default value and no value has been set yet, set it as the value.
		if (nou(valueProp) && defaultValue != null) {
			setValue(defaultValue);
		}
	}, [defaultValue, setValue, valueProp]);
	const imageRestrictionMessages = getImageRestrictionMessages(restrictions);
	/* TODO: handleDataSourceOptionClick and executeDataSourceOption only handle hardcoded 'browse', 'upload' and 'search' options.
        We need to make them dynamic to support plugins. */
	const handleDataSourceOptionClick = (option) => {
		setAddMenuOpen(false);
		switch (option) {
			case 'browse': {
				if (allowedBrowsePaths.length === 1) {
					executeDataSourceOption('browse', allowedBrowsePaths[0]);
				} else {
					// Open browse picker
					setPickerType('browse');
					setOpenPickerDialog(true);
				}
				break;
			}
			case 'upload': {
				if (allowedUploadPaths.length === 1) {
					executeDataSourceOption('upload', allowedUploadPaths[0]);
				} else {
					// Open upload picker
					setPickerType('upload');
					setOpenPickerDialog(true);
				}
				break;
			}
			case 'search': {
				if (allowedSearchPaths.length === 1) {
					executeDataSourceOption('search', allowedSearchPaths[0]);
				} else {
					// Open search picker
					setPickerType('search');
					setOpenPickerDialog(true);
				}
				break;
			}
		}
	};
	const executeDataSourceOption = (optionType, choice) => {
		const processPath = (path) =>
			processPathMacros({ path, objectId: id, fullParentPath: contextItem?.path ?? pathInSite });
		switch (optionType) {
			case 'browse': {
				showBrowseFilesDialog({
					dispatch,
					path: processPath(choice.path),
					multiSelect: false,
					preselectedPaths: value ? [value] : [],
					initialParameters: {
						sortBy: choice.options?.sortBy,
						sortOrder: choice.options?.sortOrder
					},
					onSuccess(imageData) {
						// Check if the image meets restrictions
						validateImageRestrictions(imageData.path, restrictions).then((meetsRestrictions) => {
							if (!meetsRestrictions) {
								showImageCropDialog({
									dispatch,
									path: imageData.path,
									mimeType: imageData.mimeType,
									restrictions,
									writeContent: true,
									onCrop: (blob, newPath) => {
										setValue(newPath ?? imageData.path);
									}
								});
							} else {
								setValue(imageData.path);
							}
						});
					}
				});
				break;
			}
			case 'search': {
				showSearchDialog({
					dispatch,
					path: ensureSingleSlash(`${processPath(choice.path)}/.+`),
					preselectedPaths: value ? [value] : [],
					initialParameters: {
						sortBy: choice.options?.sortBy,
						sortOrder: choice.options?.sortOrder
					},
					onAcceptSelection(images) {
						validateImageRestrictions(images[0], restrictions).then((meetsRestrictions) => {
							if (!meetsRestrictions) {
								showImageCropDialog({
									dispatch,
									path: images[0],
									restrictions,
									writeContent: true,
									onCrop: (blob, newPath) => {
										setValue(newPath ?? images[0]);
									}
								});
							} else {
								setValue(images[0]);
							}
						});
					}
				});
				break;
			}
			case 'upload': {
				showSingleFileUploadDialog({
					dispatch,
					siteId,
					path: processPath(choice.path),
					fileTypes: ['image/*'],
					onFileAdded: (file, uppy, callback) => {
						const data = file.data;
						const url = URL.createObjectURL(data);
						validateImageRestrictions(url, restrictions).then((meetsRestrictions) => {
							if (!meetsRestrictions) {
								showImageCropDialog({
									dispatch,
									path: url,
									mimeType: file.type,
									restrictions,
									onCrop: (blob) => {
										uppy.setFileState(file.id, {
											source: 'crop',
											name: file.name,
											type: blob.type,
											data: blob
										});
										callback?.();
										URL.revokeObjectURL(url);
									}
								});
							} else {
								callback?.();
								URL.revokeObjectURL(url);
							}
						});
					},
					onUploadComplete(result) {
						if (result.successful.length) {
							const newValue = ensureSingleSlash(`${result.successful[0].meta.path}`);
							setValue(newValue);
						}
					}
				});
				break;
			}
		}
	};
	const handleDataSourcePickerDialogChange = (event, choice) => {
		if (!pickerType) return;
		executeDataSourceOption(pickerType, choice);
		setOpenPickerDialog(false);
	};
	const { menuOptions, availableOptions } = createMediaMenuOptions(
		dataSourceSummary,
		handleDataSourceOptionClick,
		readonly
	);
	const handleRemoveImage = () => {
		setValue(null);
	};
	return _jsxs(_Fragment, {
		children: [
			_jsx(Menu, {
				anchorEl: addMenuButtonRef.current,
				open: addMenuOpen,
				onClose: () => setAddMenuOpen(false),
				sx: {
					[`.${menuItemClasses.root}`]: { pl: 3 }
				},
				children: menuOptions
			}),
			_jsxs(Dialog, {
				open: openPickerDialog,
				onClose: () => setOpenPickerDialog(false),
				fullWidth: true,
				maxWidth: 'sm',
				children: [
					_jsx(DialogHeader, {
						title: _jsx(FormattedMessage, { defaultMessage: 'Choose how to proceed' }),
						onCloseButtonClick: () => setOpenPickerDialog(false)
					}),
					_jsx(DialogBody, {
						children: (() => {
							switch (pickerType) {
								case 'browse':
									return _jsx(ContentPicker, {
										label: _jsx(FormattedMessage, { defaultMessage: 'Browse Settings' }),
										allowedPaths: allowedBrowsePaths,
										onChange: handleDataSourcePickerDialogChange
									});
								case 'upload':
									return _jsx(ContentPicker, {
										label: _jsx(FormattedMessage, { defaultMessage: 'Upload Settings' }),
										allowedPaths: allowedUploadPaths,
										onChange: handleDataSourcePickerDialogChange
									});
								case 'search':
									return _jsx(ContentPicker, {
										label: _jsx(FormattedMessage, { defaultMessage: 'Search Settings' }),
										allowedPaths: allowedSearchPaths,
										onChange: handleDataSourcePickerDialogChange
									});
							}
						})()
					})
				]
			}),
			_jsx(FormsEngineField, {
				field: field,
				children: hasValue
					? _jsxs(Card, {
							sx: { display: 'flex' },
							children: [
								_jsx(CardMedia, {
									component: 'img',
									sx: { width: '40%' },
									image: `${guestBase}${value}`,
									alt: 'Live from space album cover'
								}),
								_jsx(Box, {
									sx: { display: 'flex', flexDirection: 'column' },
									children: _jsxs(CardContent, {
										sx: { flex: '1 0 auto' },
										children: [
											_jsx(Typography, { component: 'div', variant: 'body1', marginBottom: 1, children: value }),
											_jsxs(Typography, {
												variant: 'body2',
												component: 'div',
												color: 'textSecondary',
												marginBottom: 1,
												children: [
													isFetchingMetadata
														? _jsxs(_Fragment, {
																children: [_jsx(Skeleton, { variant: 'text' }), _jsx(Skeleton, { variant: 'text' })]
															})
														: errorMetadata
															? _jsx(Typography, {
																	color: 'error',
																	variant: 'body2',
																	children: _jsx(FormattedMessage, { defaultMessage: 'Error loading image metadata' })
																})
															: _jsxs(_Fragment, {
																	children: [
																		imageInfo?.contentType,
																		_jsx('br', {}),
																		imageInfo?.size ? `${imageInfo.size} Kb` : '',
																		_jsx('br', {})
																	]
																}),
													isFetchingDimensions
														? _jsx(Skeleton, { variant: 'text' })
														: errorDimensions
															? _jsx(Typography, {
																	color: 'error',
																	variant: 'body2',
																	children: _jsx(FormattedMessage, { defaultMessage: 'Error loading image dimensions' })
																})
															: `${imageInfo?.width} x ${imageInfo?.height}`
												]
											}),
											Object.values(restrictions).some((restriction) => restriction) &&
												_jsxs(_Fragment, {
													children: [
														_jsx(Typography, {
															variant: 'caption',
															fontWeight: 'bold',
															children: _jsx(FormattedMessage, { defaultMessage: 'Image Requirements:' })
														}),
														_jsxs(Typography, {
															variant: 'caption',
															component: 'div',
															color: 'textSecondary',
															marginBottom: 1,
															children: [
																_jsx(FormattedMessage, { defaultMessage: 'Width: ' }),
																imageRestrictionMessages.width,
																_jsx('br', {}),
																_jsx(FormattedMessage, { defaultMessage: 'Height:' }),
																imageRestrictionMessages.height
															]
														})
													]
												}),
											_jsxs(Box, {
												children: [
													_jsx(Tooltip, {
														title: _jsx(FormattedMessage, { defaultMessage: 'Replace' }),
														children: _jsx(IconButton, {
															size: 'small',
															ref: addMenuButtonRef,
															disabled: readonly,
															autoFocus: autoFocus,
															onClick: () => {
																if (availableOptions.length === 1) {
																	handleDataSourceOptionClick(availableOptions[0]);
																} else if (availableOptions.length > 1) {
																	setAddMenuOpen(true);
																}
															},
															children: _jsx(EditOutlined, {})
														})
													}),
													_jsx(Tooltip, {
														title: _jsx(FormattedMessage, { defaultMessage: 'Download' }),
														children: _jsx(IconButton, {
															size: 'small',
															onClick: () => {
																if (value) downloadMedia(guestBase, value);
															},
															children: _jsx(DownloadOutlined, {})
														})
													}),
													_jsx(Tooltip, {
														title: _jsx(FormattedMessage, { defaultMessage: 'Delete' }),
														children: _jsx(IconButton, {
															size: 'small',
															onClick: handleRemoveImage,
															disabled: readonly,
															children: _jsx(DeleteOutlined, {})
														})
													})
												]
											})
										]
									})
								})
							]
						})
					: _jsx(Box, {
							sx: {
								p: 1,
								gap: 1,
								py: 0.5,
								display: 'flex',
								flexDirection: 'row',
								flexWrap: 'wrap',
								color: 'primary.main',
								justifyContent: 'center',
								[`.${svgIconClasses.root}`]: {
									color: 'primary.main'
								},
								[`.${menuItemClasses.root}`]: {
									flexDirection: 'column',
									justifyContent: 'center',
									borderRadius: 1
								},
								[`.${listItemIconClasses.root}`]: {
									justifyContent: 'center'
								}
							},
							children: menuOptions
						})
			})
		]
	});
}
export default ImagePicker;
