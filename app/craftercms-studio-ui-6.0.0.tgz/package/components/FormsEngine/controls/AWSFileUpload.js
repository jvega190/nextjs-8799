/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import FormsEngineField from '../components/FormsEngineField';
import { getPropertyValue, isFieldReadOnly } from '../lib/formUtils';
import useActiveSiteId from '../../../hooks/useActiveSiteId';
import { SingleFileUpload } from '../../SingleFileUpload';
import useEnv from '../../../hooks/useEnv';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import FieldBox from '../components/FieldBox';
import { nou } from '../../../utils/object';
import { FormattedMessage, useIntl } from 'react-intl';
import Card from '@mui/material/Card';
import { useDispatch } from 'react-redux';
import { showSystemNotification } from '../../../state/actions/system';
export function AwsFileUpload(props) {
	const { field, value, setValue, readonly: formReadonly } = props;
	const siteId = useActiveSiteId();
	const { authoringBase } = useEnv();
	const url = `${authoringBase}/api/2/aws/s3/upload.json`;
	const fileType = getAwsFileType(value?.url);
	const dispatch = useDispatch();
	const { formatMessage } = useIntl();
	const profileId = getPropertyValue(field.properties, 'profile_id');
	const readonly = isFieldReadOnly(field, formReadonly);
	const handleFileUploaded = (result) => {
		if (result.failed.length) {
			dispatch(
				showSystemNotification({
					message: formatMessage({ defaultMessage: 'An error occurred while uploading the file.' })
				})
			);
		} else {
			const item = result.successful[0]?.response?.body?.item;
			if (!item) {
				// This is to guard against nullish `response.body.item`. Visual feedback is handled by SingleFileUpload component.
				return;
			}
			const awsFile = {
				key: item.name,
				bucket: item.bucketName ? `${item.bucketName}${item.prefix ? `/${item.prefix}` : ''}` : (item.bucket ?? ''),
				url: item.url ?? ''
			};
			setValue(awsFile);
		}
	};
	return _jsxs(FormsEngineField, {
		field: field,
		children: [
			value &&
				_jsxs(Box, {
					display: 'flex',
					flexDirection: 'row',
					justifyContent: 'space-between',
					mt: 1,
					children: [
						_jsx(Typography, { variant: 'body2', children: `s3://${value.bucket}/${value.key}` }),
						_jsx(Typography, { variant: 'body2', color: 'textSecondary', children: value.url })
					]
				}),
			_jsx(FieldBox, {
				sx: { my: 2, px: 1, pt: 1 },
				children: _jsxs('form', {
					id: 'asset_upload_form',
					children: [
						_jsx('input', { type: 'hidden', name: 'siteId', value: siteId }),
						_jsx('input', { type: 'hidden', name: 'profileId', value: profileId }),
						_jsx('input', { type: 'hidden', name: 'path', value: '/' }),
						_jsx(SingleFileUpload, {
							site: siteId,
							path: '/',
							url: url,
							method: 'POST',
							showFileDetails: nou(value),
							showProgressBar: nou(value),
							onComplete: handleFileUploaded,
							disabled: readonly
						})
					]
				})
			}),
			value &&
				_jsx(Box, {
					sx: { display: 'flex', justifyContent: 'center' },
					children: _jsx(Card, {
						sx: { width: fileType === 'asset' ? '100%' : 'auto' },
						children:
							fileType === 'image'
								? _jsx(Box, {
										component: 'img',
										src: value.url,
										alt: value.key,
										sx: {
											maxWidth: '100%',
											maxHeight: 220
										}
									})
								: fileType === 'video'
									? _jsx(Box, {
											component: 'video',
											controls: true,
											muted: true,
											sx: {
												maxWidth: '100%',
												maxHeight: 220
											},
											children: _jsx('source', {
												src: value.url,
												type: `video/${value.url.match(/\.([a-z0-9]+)(?:\?|$)/i)?.[1] ?? 'mp4'}`
											})
										})
									: fileType === 'asset'
										? _jsx(Box, {
												component: 'iframe',
												src: value.url,
												title: formatMessage({ defaultMessage: 'File preview' }),
												sandbox: 'allow-same-origin',
												sx: {
													width: '100%',
													maxHeight: 250,
													border: 'none'
												}
											})
										: _jsx(Typography, {
												children: _jsx(FormattedMessage, { defaultMessage: '(Preview not available)' })
											})
					})
				})
		]
	});
}
function getAwsFileType(fileUrl) {
	if (!fileUrl) return 'unknown';
	if (/\.(jpg|jpeg|png|gif|bmp|ico|svg|webp)(?:\?|$)/i.test(fileUrl)) return 'image';
	if (/\.(mp4|webm|ogv)(?:\?|$)/i.test(fileUrl)) return 'video';
	if (/\.(pdf|html|js|css|txt|json|md|jsx|ts|tsx|yaml|ftl)(?:\?|$)/i.test(fileUrl)) return 'asset';
	return 'unknown';
}
export default AwsFileUpload;
