/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2025 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Box from '@mui/material/Box';
import {
	HexAlphaColorPicker,
	HexColorInput,
	HexColorPicker,
	HslaStringColorPicker,
	HslStringColorPicker,
	RgbaStringColorPicker,
	RgbStringColorPicker
} from 'react-colorful';
import { forwardRef, useEffect, useImperativeHandle, useMemo, useRef, useState } from 'react';
import ButtonBase from '@mui/material/ButtonBase';
import Typography from '@mui/material/Typography';
import Popover from '@mui/material/Popover';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import OutlinedInput from '@mui/material/OutlinedInput';
import FormsEngineField from '../components/FormsEngineField';
import { toTargetFormat } from '../../../utils/color';
const pickers = {
	rgb: { true: RgbaStringColorPicker, false: RgbStringColorPicker },
	hsl: { true: HslaStringColorPicker, false: HslStringColorPicker },
	hex: { true: HexAlphaColorPicker, false: HexColorPicker }
};
const CustomHexColorInput = forwardRef((props, ref) => {
	const divRef = useRef(undefined);
	useImperativeHandle(ref, () => divRef.current.previousSibling);
	return _jsxs(_Fragment, {
		children: [_jsx(HexColorInput, { ...props }), _jsx('div', { ref: divRef, hidden: true })]
	});
});
const hexColorInputSx = {
	input: { border: 0, padding: '8.5px 14px', font: 'inherit', '&:focus': { outline: 'none' } }
};
export function ColorPicker(props) {
	const { field, readonly, value, autoFocus, setValue } = props;
	// const presetColors = ['#cd9323', '#1a53d8', '#9a2151', '#0d6416', '#8d2808'];
	// return (
	// 	<FormsEngineField field={field}>
	// 		<RgbaColorPicker color={value} onChange={setValue} />
	// 	</FormsEngineField>
	// );
	const alpha = field.properties.alpha.value ?? true;
	const format = field.properties.format.value ?? 'hex';
	const buttonRef = useRef(undefined);
	const [colour, setColour] = useState(() => toTargetFormat(format, alpha, value));
	const [open, setOpen] = useState(false);
	const isHex = format === 'hex';
	const ColourPicker = pickers[format][String(alpha)] ?? HexColorPicker;
	const hexColorInputProps = { color: colour, alpha: alpha, prefixed: true };
	const handleOpen = () => setOpen(true);
	const handleClose = () => {
		setValue(colour);
		setOpen(false);
	};
	const throttledSetValue = useMemo(() => throttle(setValue), [setValue]);
	const handleChange = (value) => {
		setColour(value);
		// TODO: Check an issue when format = 'hsl', input change doesn't update properly when doing throttledSetValue
		throttledSetValue(value);
	};
	useEffect(() => {
		setColour(toTargetFormat(format, alpha, value));
	}, [alpha, format, value]);
	return _jsxs(FormsEngineField, {
		field: field,
		children: [
			_jsxs(Box, {
				children: [
					_jsxs(ButtonBase, {
						ref: buttonRef,
						sx: { px: 1 },
						onClick: () => handleOpen(),
						children: [
							_jsx(Box, {
								sx: {
									mr: isHex ? 0 : 1,
									width: '28px',
									height: '28px',
									borderRadius: 2,
									border: '3px solid #fff',
									boxShadow: 2,
									backgroundColor: colour
								}
							}),
							isHex ? undefined : _jsx(Typography, { children: colour })
						]
					}),
					isHex &&
						_jsx(OutlinedInput, {
							size: 'small',
							// @ts-expect-error: OutlinedInput expects (event) => void, but the onChange that actually occurs is the HexColorInput's
							onChange: handleChange,
							slotProps: { input: hexColorInputProps },
							slots: { input: CustomHexColorInput },
							sx: hexColorInputSx
						})
				]
			}),
			_jsx(Popover, {
				open: open,
				onClose: handleClose,
				anchorEl: buttonRef.current,
				anchorOrigin: { horizontal: 'left', vertical: 'bottom' },
				children: _jsxs(Paper, {
					sx: { p: 1 },
					children: [
						_jsx(ColourPicker, { color: colour, onChange: handleChange }),
						_jsx(Button, { fullWidth: true, sx: { mt: 1 }, onClick: handleClose, children: 'Done' })
					]
				})
			})
		]
	});
}
function throttle(func, delay = 500) {
	let lastCall = 0;
	return function (...args) {
		const now = Date.now();
		if (now - lastCall >= delay) {
			lastCall = now;
			return func.apply(func, args);
		}
	};
}
export default ColorPicker;
