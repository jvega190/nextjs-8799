/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useMemo, useState } from 'react';
import { FormsEngineField } from '../components/FormsEngineField';
import Checkbox from '@mui/material/Checkbox';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel, { formControlLabelClasses } from '@mui/material/FormControlLabel';
import { useKVPLoader } from '../dataSourceHooks/useKVPLoader';
import useActiveSiteId from '../../../hooks/useActiveSiteId';
import { useTheme } from '@mui/material/styles';
import { typographyClasses } from '@mui/material/Typography';
import { SearchBar } from '../../SearchBar';
import useDebouncedInput from '../../../hooks/useDebouncedInput';
import { List } from 'react-window';
import Grid from '@mui/material/Grid';
import { FormattedMessage } from 'react-intl';
import { useWindowWidth } from '../../../hooks/useWindowWidth';
import { getPropertyValue, isFieldReadOnly } from '../lib/formUtils';
import Skeleton from '@mui/material/Skeleton';
export function CheckboxGroup(props) {
	const theme = useTheme();
	const { contentType, field, value, setValue, autoFocus, readonly: formReadonly } = props;
	const [searchFieldValue, setSearchFieldValue] = useState('');
	const [keyword, setKeyword] = useState('');
	const windowWidth = useWindowWidth();
	const numColumns = windowWidth >= 900 ? 2 : 1;
	// region field properties/validations
	const readonly = isFieldReadOnly(field, formReadonly);
	const selectAll = getPropertyValue(field.properties, 'selectAll');
	const listDirection = useMemo(() => {
		let listDirection = 'horizontal';
		let directionArray = [];
		try {
			const raw = getPropertyValue(field.properties, 'listDirection');
			const parsed = raw ? JSON.parse(raw) : [];
			directionArray = Array.isArray(parsed) ? parsed : [];
		} catch {
			directionArray = [];
		}
		const verticalValue = Boolean(directionArray.find((item) => item.value === 'vertical')?.selected);
		if (verticalValue) listDirection = 'vertical';
		return listDirection;
	}, [field.properties]);
	// endregion
	const onKeyword$ = useDebouncedInput(() => {
		setKeyword(searchFieldValue);
	});
	const options = useKVPLoader(
		useActiveSiteId(),
		// Checkbox Group supports only 1 datasource.
		useMemo(() => [field.properties.datasource?.value], [field.properties.datasource?.value]),
		contentType.dataSources
	)?.[0]?.items;
	const finalOptions = useMemo(() => {
		if (!options) return undefined;
		let finalOptions = [...options];
		// If the list direction is vertical and there are two columns), we need to reorder the options to be top-down instead of left-right
		if (listDirection === 'vertical' && numColumns === 2) {
			// When there are two columns, we need to reorder the options to be top-down instead of left-right
			// So we need to take the first half and interleave it with the second half.
			const sortedOptions = [];
			const numRows = Math.ceil(finalOptions.length / 2);
			for (let i = 0; i < numRows; i++) {
				sortedOptions.push(finalOptions[i]);
				if (finalOptions[i + numRows]) {
					sortedOptions.push(finalOptions[i + Math.ceil(finalOptions.length / 2)]);
				}
			}
			finalOptions = sortedOptions;
		}
		if (!keyword.trim()) {
			return finalOptions;
		}
		const lowerKeyword = keyword.toLowerCase();
		return finalOptions?.filter((option) => {
			const label = typeof option.value === 'string' ? option.value.toLowerCase() : '';
			return label.includes(lowerKeyword) || option.key?.includes(lowerKeyword);
		});
	}, [options, keyword, listDirection, numColumns]);
	const checkedValuesLookup = useMemo(() => {
		return value.reduce((acc, item) => {
			acc[item.key] = true;
			return acc;
		}, {});
	}, [value]);
	const allInViewSelected = useMemo(() => {
		if (!finalOptions) return false;
		return finalOptions.every((option) => checkedValuesLookup[option.key]);
	}, [finalOptions, checkedValuesLookup]);
	const someInViewSelected = useMemo(() => {
		if (!finalOptions) return false;
		return finalOptions.some((option) => checkedValuesLookup[option.key]);
	}, [finalOptions, checkedValuesLookup]);
	if (!finalOptions) {
		return _jsx(FormGroup, {
			children: _jsx(Grid, {
				container: true,
				spacing: 2,
				sx: { width: '100%' },
				children: Array.from({ length: 2 }).map((_, i) =>
					_jsx(
						Grid,
						{
							size: { sm: 12, md: 6 },
							children: _jsx(FormControlLabel, {
								control: _jsx(Checkbox, { disabled: true }),
								label: _jsx(Skeleton, { variant: 'text', width: 120 })
							})
						},
						i
					)
				)
			})
		});
	}
	const showFilter = options?.length > 2;
	const isVirtualized = finalOptions.length > 100;
	const virtualRows = Math.ceil(finalOptions.length / numColumns);
	const handleChange = (e) => {
		const key = e.target.value;
		const checked = e.target.checked;
		if (checked) {
			setValue([...value, { key, value_smv: options.find((option) => option.key === key)?.value }]);
		} else {
			setValue(value.filter((item) => item.key !== key));
		}
	};
	const checkAll = () => {
		if (value.length === finalOptions.length) {
			setValue([]);
		} else {
			setValue(finalOptions.map((option) => ({ key: option.key, value_smv: option.value })));
		}
	};
	return _jsxs(FormsEngineField, {
		field: field,
		autoFocus: !showFilter && autoFocus,
		children: [
			showFilter &&
				_jsx(SearchBar, {
					disabled: readonly,
					sx: { mb: 1 },
					autoFocus: autoFocus,
					showActionButton: searchFieldValue !== '',
					keyword: searchFieldValue,
					onChange: (value) => {
						setSearchFieldValue(value);
						onKeyword$.next(value);
					}
				}),
			selectAll &&
				_jsx(FormControlLabel, {
					sx: { mb: 1 },
					control: _jsx(Checkbox, {
						disabled: readonly,
						color: 'info',
						indeterminate: someInViewSelected,
						checked: allInViewSelected,
						onChange: checkAll
					}),
					label: _jsx(FormattedMessage, { defaultMessage: 'Select All' })
				}),
			_jsx(FormGroup, {
				sx: {
					p: 1,
					gap: 1,
					maxHeight: isVirtualized ? undefined : 350,
					overflow: 'auto',
					flexWrap: 'wrap',
					flexDirection: 'row',
					borderWidth: 1,
					borderRadius: 1,
					borderStyle: 'solid',
					borderColor: 'divider',
					[`.${formControlLabelClasses.root}`]: {
						height: isVirtualized ? '50px' : undefined,
						flexBasis: `calc(32.5% - ${theme.spacing(1)})`,
						[`.${typographyClasses.root}`]: {
							display: '-webkit-box',
							WebkitLineClamp: '2',
							WebkitBoxOrient: 'vertical',
							overflow: 'hidden',
							whiteSpace: 'normal'
						}
					},
					'.checkbox-group-virtual-list': {},
					'.checkbox-group-virtual-row': { display: 'flex' }
				},
				children: isVirtualized
					? _jsx(List, {
							rowHeight: 50,
							rowCount: virtualRows,
							rowComponent: VirtualRow,
							className: 'checkbox-group-virtual-list',
							rowProps: { options: finalOptions, onChange: handleChange, checkedValuesLookup, numColumns, readonly }
						})
					: _jsx(Grid, {
							container: true,
							spacing: 2,
							sx: { width: '100%' },
							children: finalOptions?.map((option) =>
								_jsx(
									Grid,
									{
										size: { sm: 12, md: 6 },
										children: buildOption(option, handleChange, checkedValuesLookup, readonly)
									},
									option.key
								)
							)
						})
			})
		]
	});
}
const buildOption = (option, onChange, checkedValuesLookup, readonly = false) =>
	_jsx(
		FormControlLabel,
		{
			control: _jsx(Checkbox, {
				disabled: readonly,
				color: 'info',
				checked: checkedValuesLookup[option.key] ?? false,
				onChange: onChange,
				value: option.key
			}),
			label: option.value
		},
		option.key
	);
const VirtualRow = (props) => {
	const { index, style, options, onChange, checkedValuesLookup, numColumns, readonly } = props;
	const adjustedIndex = index * numColumns;
	return _jsx(Grid, {
		container: true,
		className: 'checkbox-group-virtual-row',
		spacing: 2,
		sx: { width: '100%' },
		style: style,
		children: options
			.slice(adjustedIndex, adjustedIndex + numColumns)
			.map((option) =>
				_jsx(
					Grid,
					{ size: { sm: 12, md: 6 }, children: buildOption(option, onChange, checkedValuesLookup, readonly) },
					option.key
				)
			)
	});
};
export default CheckboxGroup;
