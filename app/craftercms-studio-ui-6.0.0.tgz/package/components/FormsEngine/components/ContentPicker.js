/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2025 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Radio from '@mui/material/Radio';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
/** Renders a FormControl with a RadioGroup to select from allowed content paths in the datasource selection dialog in
 * the Forms Engine Controls. */
export function ContentPicker(props) {
	const { label, allowedPaths, onChange } = props;
	const handleChange = (event) => onChange?.(event, allowedPaths[event.target.value]);
	return _jsxs(FormControl, {
		children: [
			_jsx(FormLabel, { id: 'contentTypeLabel', sx: { mb: 1 }, children: label }),
			_jsx(RadioGroup, {
				'aria-labelledby': 'contentTypeLabel',
				name: 'contentType',
				children: allowedPaths?.map((data, index) =>
					_jsx(
						FormControlLabel,
						{
							disableTypography: true,
							value: index,
							control: _jsx(Radio, {}),
							label: _jsxs(Box, {
								display: 'flex',
								flexDirection: 'column',
								py: 1,
								children: [
									_jsx(Typography, { component: 'span', children: data.title }),
									_jsx(Typography, { variant: 'body2', color: 'textSecondary', component: 'span', children: data.path })
								]
							}),
							onChange: handleChange
						},
						index
					)
				)
			})
		]
	});
}
