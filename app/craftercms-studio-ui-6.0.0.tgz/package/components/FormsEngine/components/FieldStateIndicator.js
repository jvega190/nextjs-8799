/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
import Tooltip from '@mui/material/Tooltip';
import { FormattedMessage } from 'react-intl';
import Asterisk from '../../../icons/Asterisk';
import CheckRounded from '@mui/icons-material/CheckRounded';
export function FieldStateIndicator({ isRequired, hasValidator, isValid, isEmpty }) {
	let IndicatorComponent = null;
	let message = null;
	// If there is no requirement and no validator, and the field is empty, do not show any indicator
	if (!isRequired && !hasValidator && isEmpty) return undefined;
	// If required, or if not required but has a validator and is invalid, show asterisk (color depends on isValid)
	if (isRequired || (!isRequired && hasValidator && !isValid)) {
		IndicatorComponent = Asterisk;
		if (isValid) {
			message = _jsx(FormattedMessage, { defaultMessage: 'Complete' });
		} else if (isRequired && isEmpty) {
			message = _jsx(FormattedMessage, { defaultMessage: 'Required' });
		} else {
			message = _jsx(FormattedMessage, { defaultMessage: 'Invalid' });
		}
	} else {
		// Otherwise, show check mark
		IndicatorComponent = CheckRounded;
		message = _jsx(FormattedMessage, { defaultMessage: 'Complete' });
	}
	return _jsx(Tooltip, {
		title: message,
		children: _jsx(IndicatorComponent, { fontSize: 'small', color: isValid ? 'success' : 'error' })
	});
}
export default FieldStateIndicator;
