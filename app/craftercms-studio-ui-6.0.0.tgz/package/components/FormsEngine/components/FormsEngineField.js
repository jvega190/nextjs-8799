/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
import FormControl from '@mui/material/FormControl';
import Box from '@mui/material/Box';
import FieldRequiredStateIndicator from './FieldRequiredStateIndicator';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import MoreVertRounded from '@mui/icons-material/MoreVertRounded';
import Collapse from '@mui/material/Collapse';
import Alert, { alertClasses } from '@mui/material/Alert';
import FormHelperText from '@mui/material/FormHelperText';
import { forwardRef, useEffect, useRef, useState } from 'react';
import { isEmptyValue, isFieldRequired } from '../lib/validators';
import FormLabel from '@mui/material/FormLabel';
import Button from '@mui/material/Button';
import useItemsByPath from '../../../hooks/useItemsByPath';
import { FormattedMessage, useIntl } from 'react-intl';
import { HelpOutlineRounded } from '@mui/icons-material';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Divider from '@mui/material/Divider';
import ListItemText from '@mui/material/ListItemText';
import {
	useFormApiContext,
	useItemMetaContext,
	useStableFormContext,
	useStableGlobalApiContext
} from '../lib/formsEngineContext';
import { useAtomValue } from 'jotai';
import { translateIfMessageDescriptor } from '../../ContentTypeManagement/utils';
import useLoadableAtom from '../lib/useLoadableAtom';
import { XmlKeys } from '../lib/formConsts';
function createLengthBlock({ length, max }) {
	const pieces = [];
	if (length != null) {
		pieces.push(`${length}`);
	}
	if (max != null) {
		pieces.push(`/${max}`);
	}
	return pieces.length
		? _jsx(Typography, { variant: 'body2', color: 'textSecondary', children: pieces.join(''), sx: { mr: 1 } })
		: null;
}
export const FormsEngineField = forwardRef(function (props, ref) {
	const {
		children,
		field,
		max,
		min,
		length,
		action,
		htmlFor,
		labelId,
		autoFocus,
		menu = true,
		menuOptions,
		onMenuOptionClick
	} = props;
	const { sourceMap } = useItemMetaContext();
	const { changedFieldIds, atoms } = useStableFormContext();
	const formApi = useFormApiContext();
	const globalApi = useStableGlobalApiContext();
	const { formatMessage } = useIntl();
	const itemsByPath = useItemsByPath();
	const labelRef = useRef(null);
	const menuButtonRef = useRef(undefined);
	const [openMenu, setOpenMenu] = useState(false);
	const [showHelp, setShowHelp] = useState(false);
	const fieldId = field.id;
	const hasChanges = changedFieldIds.has(field.id);
	const hasHelpText = Boolean(field.helpText);
	const hasDescription = Boolean(field.description);
	const lengthBlock = createLengthBlock({ length, max });
	const isRequired = isFieldRequired(field);
	const validityData = useLoadableAtom(atoms.validationByFieldId[fieldId]);
	const value = useAtomValue(atoms.valueByFieldId[fieldId]);
	const isValid = props.isValid ?? (validityData.state === 'hasData' ? validityData?.data.isValid : true);
	const handleCloseMenu = () => setOpenMenu(false);
	const handleRollback = () => formApi.rollbackField(field.id);
	useEffect(() => {
		// Offer controls the option to focus on the label when the field is rendered.
		if (autoFocus) {
			labelRef.current?.focus();
		}
	}, [autoFocus]);
	return _jsxs(FormControl, {
		ref: ref,
		fullWidth: true,
		error: !isValid,
		variant: 'standard',
		'data-field-id': fieldId,
		required: isRequired,
		sx: { '.MuiFormLabel-asterisk': { display: 'none' }, ...props.sx },
		children: [
			_jsxs(Box, {
				display: 'flex',
				justifyContent: 'space-between',
				alignItems: 'center',
				children: [
					_jsxs(Box, {
						display: 'flex',
						alignItems: 'center',
						children: [
							_jsx(FormLabel, {
								htmlFor: htmlFor,
								id: labelId,
								component: 'label',
								ref: labelRef,
								tabIndex: autoFocus ? 0 : undefined,
								children: field.name
							}),
							isRequired && _jsx(FieldRequiredStateIndicator, { isValid: isValid }),
							hasHelpText &&
								_jsx(IconButton, {
									size: 'small',
									onClick: () => setShowHelp(!showHelp),
									children: _jsx(HelpOutlineRounded, { fontSize: 'small' })
								})
						]
					}),
					_jsxs(Box, {
						display: 'flex',
						alignItems: 'center',
						children: [
							lengthBlock,
							action,
							menu &&
								_jsxs(_Fragment, {
									children: [
										_jsx(IconButton, {
											size: 'small',
											tabIndex: -1,
											ref: menuButtonRef,
											onClick: () => setOpenMenu(true),
											children: _jsx(MoreVertRounded, { fontSize: 'small' })
										}),
										_jsxs(Menu, {
											open: openMenu,
											anchorEl: menuButtonRef.current,
											onClose: handleCloseMenu,
											onClick: handleCloseMenu,
											children: [
												_jsx(MenuItem, {
													children: _jsx(ListItemText, {
														children: _jsx(FormattedMessage, { defaultMessage: 'Field Information' })
													})
												}),
												hasChanges && [
													_jsx(Divider, {}, 'rollback-divider'),
													_jsx(
														MenuItem,
														{
															onClick: handleRollback,
															children: _jsx(ListItemText, {
																children: _jsx(FormattedMessage, { defaultMessage: 'Rollback changes' })
															})
														},
														'rollback-action'
													)
												],
												menuOptions && _jsx(Divider, {}),
												menuOptions?.map((option, index) =>
													option === 'divider'
														? _jsx(Divider, {}, `divider_${index}`)
														: _jsx(
																MenuItem,
																{
																	onClick: (e) => onMenuOptionClick?.(e, option.id, handleCloseMenu),
																	children: _jsx(ListItemText, { children: option.text })
																},
																option.id
															)
												)
											]
										})
									]
								})
						]
					})
				]
			}),
			hasHelpText &&
				_jsx(Collapse, {
					in: showHelp,
					children: _jsx(Alert, {
						severity: 'info',
						variant: 'outlined',
						sx: { border: 'none' },
						children: _jsx(Typography, {
							variant: 'body2',
							component: 'section',
							color: 'textSecondary',
							dangerouslySetInnerHTML: { __html: field.helpText },
							sx: { 'p:first-of-type:last-of-type': { margin: 0 } }
						})
					})
				}),
			sourceMap?.[fieldId] &&
				fieldId !== XmlKeys['fileName'] &&
				_jsx(Alert, {
					variant: 'standard',
					severity: 'info',
					action: _jsxs(_Fragment, {
						children: [
							_jsx(Button, {
								color: 'inherit',
								size: 'small',
								sx: { px: 0.5, minWidth: 0 },
								onClick: () => {
									globalApi.pushForm({
										readonly: true,
										update: { path: sourceMap[fieldId] }
									});
								},
								children: 'View'
							}),
							_jsx(IconButton, {
								href: '/',
								size: 'small',
								color: 'inherit',
								target: '_blank',
								component: 'a',
								title: formatMessage({ defaultMessage: 'Learn more about content inheritance' }),
								children: _jsx(HelpOutlineRounded, { fontSize: 'small' })
							})
						]
					}),
					sx: {
						px: 1,
						mb: 0.625,
						borderRadius: 5,
						alignItems: 'center',
						[`.${alertClasses.message}`]: { display: 'flex', alignItems: 'center' },
						[`.${alertClasses.action}`]: { mr: 0 },
						[`.${alertClasses.icon}`]: { mr: 1 }
					},
					children: isEmptyValue(field, value)
						? _jsx(FormattedMessage, {
								defaultMessage: 'Value is inherited from {label}',
								values: { label: itemsByPath[sourceMap[fieldId]]?.label ?? sourceMap[fieldId] }
							})
						: _jsx(FormattedMessage, {
								defaultMessage: 'Inherited value from {label} is overriden',
								values: { label: itemsByPath[sourceMap[fieldId]]?.label ?? sourceMap[fieldId] }
							})
				}),
			children,
			hasDescription && _jsx(FormHelperText, { children: field.description }),
			!isValid &&
				validityData.state === 'hasData' &&
				validityData.data?.messages?.map((messageData, key) =>
					_jsx(FormHelperText, { children: translateValidityMessage(messageData, formatMessage) }, key)
				)
		]
	});
});
/**
 * Translates a validity message for a form field.
 *
 * @param messageData {FieldValidityMessage} - The validity message data, which can be a single message
 * or a tuple containing a message and its associated values.
 * @param formatMessage {IntlFormatters['formatMessage']} - The function used to format internationalized messages.
 * @returns {string} - The translated validity message.
 */
function translateValidityMessage(messageData, formatMessage) {
	const message = Array.isArray(messageData) ? messageData[0] : messageData;
	const values = Array.isArray(messageData) ? messageData[1] : undefined;
	return translateIfMessageDescriptor(message, formatMessage, values);
}
export default FormsEngineField;
