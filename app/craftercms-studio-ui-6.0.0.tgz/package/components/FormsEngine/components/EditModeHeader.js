/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2025 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useContext } from 'react';
import { useTheme } from '@mui/material/styles';
import { ItemContext, ItemMetaContext, StableFormContext } from '../lib/formsEngineContext';
import { useAtomValue, useStore as useJotaiStore } from 'jotai/index';
import useLocale from '../../../hooks/useLocale';
import { getFieldAtomValue } from '../lib/formUtils';
import { prettyPrintPerson } from '../../../utils/object';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import ItemTypeIcon from '../../ItemTypeIcon';
import Typography from '@mui/material/Typography';
import Chip, { chipClasses } from '@mui/material/Chip';
import { FormattedMessage, useIntl } from 'react-intl';
import { EditOffOutlined, EditOutlined } from '@mui/icons-material';
import CalendarTodayRounded from '@mui/icons-material/CalendarTodayRounded';
import ItemPublishingTargetIcon from '../../ItemPublishingTargetIcon';
import { getItemPublishingTargetText, getItemStateText } from '../../ItemDisplay/utils';
import ItemStateIcon from '../../ItemStateIcon';
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import { copyToClipboard } from '../../../utils/system';
import ContentCopyRounded from '@mui/icons-material/ContentCopyRounded';
import MenuOpenIcon from '@mui/icons-material/MenuOpenRounded';
import { XmlKeys } from '../lib/formConsts';
import { useAtom } from 'jotai';
import Collapse from '@mui/material/Collapse';
export function EditModeHeader({ isEmbedded, collapse = false }) {
	const { atoms } = useContext(StableFormContext);
	const { id: objectId } = useContext(ItemMetaContext);
	const item = useContext(ItemContext);
	const store = useJotaiStore();
	const readonly = useAtomValue(atoms.readonly);
	const localeConf = useLocale();
	const isLargeContainer = useAtomValue(atoms.isLargeContainer);
	const { formatMessage } = useIntl();
	const itemLabel = isEmbedded ? getFieldAtomValue(atoms.valueByFieldId[XmlKeys.internalName], store) : item.label;
	const typeIconItem = isEmbedded ? { systemType: 'component', mimeType: 'application/xml' } : item;
	const formattedCreator = prettyPrintPerson(item.creator);
	const formattedCreationDate = new Intl.DateTimeFormat(localeConf.localeCode, {
		dateStyle: 'short'
	}).format(new Date(item.dateCreated));
	const formattedModifier = prettyPrintPerson(item.modifier);
	const formattedModifiedDate = new Intl.DateTimeFormat(localeConf.localeCode, {
		dateStyle: 'short'
	}).format(new Date(item.dateModified));
	// TODO: Tabs will be done at a later phase.
	// const [activeTab, setActiveTab] = useAtom(activeTabAtom);
	// const handleTabChange: TabsProps['onChange'] = (e, value) => setActiveTab(value);
	const handleCopyToClipboard = () => {
		copyToClipboard(item.path);
	};
	return _jsxs(_Fragment, {
		children: [
			_jsxs(Container, {
				className: 'space-y',
				sx: { py: 1 },
				children: [
					_jsxs(Box, {
						display: 'flex',
						alignItems: 'center',
						className: 'space-x',
						children: [
							isLargeContainer && collapse && _jsx(CollapseToCButton, {}),
							_jsx(ItemTypeIcon, { item: typeIconItem, sx: { color: 'info.main' } }),
							_jsx(Typography, { children: itemLabel }),
							readonly &&
								_jsx(Chip, {
									sx: { [`.${chipClasses.label}`]: { display: 'flex', alignItems: 'center' } },
									color: 'warning',
									variant: 'outlined',
									label: _jsxs(_Fragment, {
										children: [
											_jsx(FormattedMessage, { defaultMessage: 'Readonly' }),
											_jsx(EditOffOutlined, { fontSize: 'small', sx: { ml: 1 } })
										]
									})
								}),
							collapse &&
								_jsx(Tooltip, {
									title: _jsx(FormattedMessage, { defaultMessage: 'Copy path to clipboard' }),
									children: _jsx(IconButton, {
										size: 'small',
										onClick: handleCopyToClipboard,
										sx: { padding: '1px', ml: 1 },
										children: _jsx(ContentCopyRounded, { fontSize: 'inherit', sx: { color: 'text.secondary' } })
									})
								})
						]
					}),
					_jsx(Collapse, {
						in: !collapse,
						children: _jsxs(Box, {
							display: 'flex',
							alignItems: 'end',
							justifyContent: 'space-between',
							children: [
								_jsx(Box, {
									className: 'space-y',
									sx: { flexBasis: '50%' },
									children: _jsxs('div', {
										children: [
											_jsxs(Typography, {
												variant: 'body2',
												color: 'textSecondary',
												display: 'flex',
												alignItems: 'center',
												sx: { flexWrap: 'wrap', em: { fontWeight: 600 } },
												children: [
													_jsxs(Box, {
														component: 'span',
														display: 'flex',
														alignItems: 'center',
														marginRight: 1,
														children: [
															_jsx(CalendarTodayRounded, { sx: { mr: 0.25 }, fontSize: 'inherit' }),
															_jsx('span', {
																children: _jsx(FormattedMessage, {
																	defaultMessage: 'Created {when} by <who>who</who>',
																	values: {
																		who: () =>
																			_jsx(
																				'em',
																				{ title: formattedCreator.tooltip, children: formattedCreator.display },
																				'0'
																			),
																		when: formattedCreationDate
																	}
																})
															})
														]
													}),
													_jsxs(Box, {
														component: 'span',
														display: 'flex',
														alignItems: 'center',
														children: [
															_jsx(EditOutlined, { sx: { mr: 0.25 }, fontSize: 'inherit' }),
															_jsx('span', {
																children: _jsx(FormattedMessage, {
																	defaultMessage: 'Updated {when} by <who>who</who>',
																	values: {
																		who: () =>
																			_jsx(
																				'em',
																				{ title: formattedModifier.tooltip, children: formattedModifier.display },
																				'0'
																			),
																		when: formattedModifiedDate
																	}
																})
															})
														]
													})
												]
											}),
											_jsxs(Typography, {
												variant: 'body2',
												color: 'textSecondary',
												display: 'flex',
												alignItems: 'center',
												sx: { flexWrap: 'wrap' },
												children: [
													_jsxs(Box, {
														component: 'span',
														display: 'flex',
														alignItems: 'center',
														marginRight: 1,
														children: [
															_jsx(ItemPublishingTargetIcon, {
																fontSize: 'inherit',
																sxs: { root: { marginRight: 0.25 } },
																item: item
															}),
															' ',
															getItemPublishingTargetText(item.stateMap, formatMessage)
														]
													}),
													_jsxs(Box, {
														component: 'span',
														display: 'flex',
														alignItems: 'center',
														children: [
															_jsx(ItemStateIcon, { fontSize: 'inherit', sxs: { root: { mr: 0.25 } }, item: item }),
															' ',
															getItemStateText(item.stateMap, formatMessage, { user: item.lockOwner?.username })
														]
													})
												]
											})
										]
									})
								}),
								_jsxs(Box, {
									className: 'space-y',
									display: 'flex',
									flexDirection: 'column',
									alignItems: 'end',
									sx: { maxWidth: '50%' },
									children: [
										_jsxs(Typography, {
											component: 'span',
											variant: 'body2',
											color: 'textSecondary',
											display: 'flex',
											alignItems: 'center',
											sx: { overflow: 'hidden', maxWidth: '100%' },
											children: [
												_jsx(Box, {
													component: 'span',
													title: item.path,
													sx: { whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' },
													children: item.path
												}),
												_jsx(Tooltip, {
													title: _jsx(FormattedMessage, { defaultMessage: 'Copy path to clipboard' }),
													children: _jsx(IconButton, {
														size: 'small',
														onClick: handleCopyToClipboard,
														sx: { padding: '1px', ml: 1 },
														children: _jsx(ContentCopyRounded, { fontSize: 'inherit', sx: { color: 'text.secondary' } })
													})
												})
											]
										}),
										_jsxs(Typography, {
											component: 'span',
											variant: 'body2',
											color: 'textSecondary',
											display: 'flex',
											alignItems: 'center',
											sx: { overflow: 'hidden', maxWidth: '100%' },
											children: [
												_jsx(Box, {
													component: 'span',
													title: objectId,
													sx: { whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' },
													children: objectId
												}),
												_jsx(Tooltip, {
													title: _jsx(FormattedMessage, { defaultMessage: 'Copy ID to clipboard' }),
													children: _jsx(IconButton, {
														size: 'small',
														sx: { padding: '1px', ml: 1 },
														onClick: () =>
															copyToClipboard(getFieldAtomValue(atoms.valueByFieldId[XmlKeys.modelId], store)),
														children: _jsx(ContentCopyRounded, { fontSize: 'inherit', sx: { color: 'text.secondary' } })
													})
												})
											]
										})
									]
								})
							]
						})
					})
				]
			}),
			_jsx(Collapse, {
				in: !collapse,
				children: _jsx(Container, {
					maxWidth: 'xl',
					sx: { display: 'flex' },
					children: isLargeContainer && _jsx(CollapseToCButton, {})
				})
			})
		]
	});
}
function CollapseToCButton() {
	const theme = useTheme();
	const { atoms } = useContext(StableFormContext);
	const [collapseToC, setCollapseToC] = useAtom(atoms.collapseToC);
	const useCollapsedToC = useAtomValue(atoms.useCollapsedToC);
	return _jsx(Tooltip, {
		title: _jsx(FormattedMessage, { defaultMessage: 'Collapse table of contents' }),
		children: _jsx(IconButton, {
			size: 'small',
			onClick: () => setCollapseToC(!collapseToC),
			sx: {
				// TODO: Tabs will be done at a later phase.
				// visibility: activeTab === 0 ? undefined : 'hidden',
				mr: 0.5
			},
			children: _jsx(MenuOpenIcon, {
				sx: {
					// Add transform to rotate 180deg when collapsed
					transform: useCollapsedToC ? 'rotate(180deg)' : 'none',
					// Animate the rotation
					transition: theme.transitions.create('transform', {
						duration: theme.transitions.duration.shortest
					})
				}
			})
		})
	});
}
export default EditModeHeader;
