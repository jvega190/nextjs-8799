/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Box from '@mui/material/Box';
import FormLabel from '@mui/material/FormLabel';
import Skeleton from '@mui/material/Skeleton';
export function ControlSkeleton({ label }) {
	return _jsxs(_Fragment, {
		children: [
			_jsxs(Box, {
				display: 'flex',
				justifyContent: 'space-between',
				alignItems: 'center',
				height: 30,
				children: [
					_jsxs(Box, {
						display: 'flex',
						alignItems: 'center',
						className: 'space-x',
						children: [
							label
								? _jsx(FormLabel, { component: 'div', children: label })
								: _jsx(Skeleton, { variant: 'text', width: 100 }),
							_jsx(Skeleton, { variant: 'circular' })
						]
					}),
					_jsxs(Box, {
						display: 'flex',
						alignItems: 'center',
						className: 'space-x',
						children: [
							_jsx(Skeleton, { variant: 'text', width: 30 }),
							_jsx(Skeleton, { variant: 'circular', width: 15, height: 15 }),
							_jsx(Skeleton, { variant: 'circular', width: 15, height: 15 })
						]
					})
				]
			}),
			_jsx(Skeleton, { variant: 'rounded', width: '100%', height: 50 }),
			_jsx(Skeleton, { variant: 'text', width: 200, height: 15 })
		]
	});
}
