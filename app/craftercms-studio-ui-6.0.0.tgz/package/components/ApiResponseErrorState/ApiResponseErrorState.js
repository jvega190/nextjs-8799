/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
import Button from '@mui/material/Button';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import { useIntl } from 'react-intl';
import ErrorState from '../ErrorState/ErrorState';
import { capitalize } from '../../utils/string';
export function createErrorStatePropsFromApiResponse(apiResponse, formatMessage, validationErrors) {
	const {
		code,
		message = '',
		remedialAction,
		documentationUrl
	} = apiResponse ?? {
		code: '',
		message: formatMessage({
			defaultMessage: 'The server is unreachable or your are offline.'
		})
	};
	return {
		title: [
			formatMessage({
				id: 'words.error',
				defaultMessage: 'Error'
			}),
			code
		]
			.filter(Boolean)
			.join(' '),
		message:
			message +
			(message.endsWith('.') || !remedialAction ? '' : '.') +
			(remedialAction ? ` ${remedialAction}` : '') +
			(remedialAction && message ? (remedialAction.endsWith('.') ? '' : '.') : ''),
		children: _jsxs(_Fragment, {
			children: [
				validationErrors?.map(({ field, message }, index) =>
					_jsx('div', { children: capitalize(message) }, `${field}_${index}`)
				),
				documentationUrl &&
					_jsxs(Button, {
						href: documentationUrl,
						target: '_blank',
						rel: 'noreferrer',
						variant: 'text',
						children: [
							formatMessage({
								id: 'common.moreInfo',
								defaultMessage: 'More info'
							}),
							' ',
							_jsx(OpenInNewIcon, {})
						]
					})
			]
		})
	};
}
export function ApiResponseErrorState(props) {
	const { error, validationErrors } = props;
	const { formatMessage } = useIntl();
	return _jsx(ErrorState, {
		...props,
		...createErrorStatePropsFromApiResponse(error, formatMessage, validationErrors)
	});
}
export default ApiResponseErrorState;
