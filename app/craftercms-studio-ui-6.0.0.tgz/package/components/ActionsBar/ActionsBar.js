/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useIntl } from 'react-intl';
import Checkbox from '@mui/material/Checkbox';
import { getPossibleTranslation } from '../../utils/i18n';
import Button from '@mui/material/Button';
import Skeleton from '@mui/material/Skeleton';
import { rand } from '../PathNavigator/utils';
import Box from '@mui/material/Box';
export function ActionsBar(props) {
	const { formatMessage } = useIntl();
	const {
		options,
		noSelectionContent,
		onOptionClicked,
		isIndeterminate,
		onCheckboxChange,
		showCheckbox = true,
		isChecked,
		isLoading = false,
		numOfSkeletonItems = 5,
		buttonProps,
		sxs,
		disabled = false
	} = props;
	return _jsx(Box, {
		className: props.classes?.root,
		sx: { bgcolor: 'background.paper', ...sxs?.root },
		children: _jsxs(Box, {
			sx: { bgcolor: 'action.selected', ...sxs?.container },
			children: [
				showCheckbox &&
					_jsx(Checkbox, {
						disabled: disabled,
						sx: { width: 48, ...sxs?.checkbox },
						color: 'primary',
						indeterminate: isIndeterminate,
						checked: isChecked,
						className: props.classes?.checkbox,
						onChange: onCheckboxChange
					}),
				!isLoading && !isIndeterminate && !isChecked && noSelectionContent,
				isLoading
					? new Array(numOfSkeletonItems)
							.fill(null)
							.map((nothing, index) =>
								_jsx(
									Button,
									{
										color: 'primary',
										className: props.classes?.button,
										sx: sxs?.button,
										disabled: disabled,
										...buttonProps,
										children: _jsx(Skeleton, { animation: 'pulse', height: '12px', width: `${rand(40, 60)}px` })
									},
									index
								)
							)
					: options?.map((option) =>
							_jsx(
								Button,
								{
									color: 'primary',
									variant: 'text',
									className: props.classes?.button,
									sx: sxs?.button,
									disabled: disabled,
									...buttonProps,
									onClick: () => onOptionClicked(option.id),
									children: getPossibleTranslation(option.label, formatMessage)
								},
								option.id
							)
						)
			]
		})
	});
}
export default ActionsBar;
