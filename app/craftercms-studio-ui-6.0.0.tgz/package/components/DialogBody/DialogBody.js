/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import MuiDialogContent from '@mui/material/DialogContent';
import { styled } from '@mui/material/styles';
import { UNDEFINED } from '../../utils/constants';
export const DialogBody = styled(MuiDialogContent, {
	shouldForwardProp: (prop) => prop !== 'minHeight'
})(({ theme, minHeight = false }) => ({
	display: 'flex',
	flex: '1 1 auto',
	position: 'relative',
	flexDirection: 'column',
	padding: theme.spacing(2),
	backgroundColor: theme.palette.background.default,
	minHeight: minHeight ? '50vh' : UNDEFINED,
	'.MuiDialogTitle-root + &': {
		paddingTop: theme.spacing(2)
	}
}));
export default DialogBody;
