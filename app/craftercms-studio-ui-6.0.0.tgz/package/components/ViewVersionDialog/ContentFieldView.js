/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
import Box from '@mui/material/Box';
import { nnou } from '../../utils/object';
import { countLines } from '../../utils/string';
import { initialFieldViewState, useVersionsDialogContext } from '../CompareVersionsDialog/VersionsDialogContext';
import DefaultView from './FieldTypesViews/DefaultView';
import ImageView from './FieldTypesViews/ImageView';
import VideoView from './FieldTypesViews/VideoView';
import TimeView from './FieldTypesViews/TimeView';
import DateTimeView from './FieldTypesViews/DateTimeView';
import BooleanView from './FieldTypesViews/BooleanView';
import NodeSelector from './FieldTypesViews/NodeSelector';
import RepeatGroupView from './FieldTypesViews/RepeatGroupView';
import NumberView from './FieldTypesViews/NumberView';
import Typography from '@mui/material/Typography';
import { FormattedMessage } from 'react-intl';
import CheckboxGroupView from './FieldTypesViews/CheckboxGroupView';
import TextView from './FieldTypesViews/TextView';
import { getContentInstanceXmlValueFromProp } from '../../utils/content';
import FileNameView from './FieldTypesViews/FileNameView';
export const typesViewMap = {
	'file-name': FileNameView,
	'auto-filename': FileNameView,
	textarea: TextView,
	rte: TextView,
	input: TextView,
	'node-selector': NodeSelector,
	'checkbox-group': CheckboxGroupView,
	repeat: RepeatGroupView,
	'image-picker': ImageView,
	'video-picker': VideoView,
	time: TimeView,
	'date-time': DateTimeView,
	checkbox: BooleanView,
	'page-nav-order': BooleanView,
	'numeric-input': NumberView,
	dropdown: TextView
};
export function ContentFieldView(props) {
	const { content, field, xml = '', dynamicHeight } = props;
	const fieldXml = getContentInstanceXmlValueFromProp(xml, field.id);
	const [{ fieldsViewState }] = useVersionsDialogContext();
	const viewState = fieldsViewState[field.id] ?? initialFieldViewState;
	const { compareXml: viewXml, monacoOptions } = viewState;
	const monacoEditorHeight = !dynamicHeight ? '100%' : countLines(fieldXml ?? '') < 15 ? '200px' : '600px';
	const ViewComponent = typesViewMap[field.type] ?? DefaultView;
	const viewComponentProps = {
		xml: fieldXml,
		field,
		editorProps: {
			options: monacoOptions,
			height: monacoEditorHeight
		}
	};
	const noContentSet = ViewComponent !== BooleanView && !content;
	return _jsx(Box, {
		sx: { flexGrow: 1 },
		children: viewXml
			? _jsx(TextView, { xml: fieldXml, editorProps: viewComponentProps.editorProps })
			: nnou(ViewComponent)
				? noContentSet
					? _jsx(Box, {
							sx: { textAlign: 'center' },
							children: _jsx(Typography, {
								color: 'textSecondary',
								children: _jsx(FormattedMessage, { defaultMessage: 'No content set' })
							})
						})
					: _jsx(ViewComponent, { ...viewComponentProps })
				: null
	});
}
export default ContentFieldView;
