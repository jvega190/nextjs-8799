/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { fromString } from '../../../utils/xml';
import { parseElementByContentType } from '../../../utils/content';
import useContentTypes from '../../../hooks/useContentTypes';
export function ImageView(props) {
	const { xml, field, content: contentProp, sxs } = props;
	const contentTypes = useContentTypes();
	const content =
		contentProp ??
		(xml
			? (() => {
					try {
						return parseElementByContentType(fromString(xml).querySelector(field.id), field, contentTypes, {});
					} catch (error) {
						console.error(`Error parsing XML for field ${field.id}:`, error);
						return '';
					}
				})()
			: '');
	return _jsxs(_Fragment, {
		children: [
			_jsx(Box, { component: 'img', src: content, alt: '', sx: { maxWidth: '100%', ...sxs?.image } }),
			xml && _jsx(Typography, { variant: 'subtitle2', sx: { ...sxs?.label }, children: content })
		]
	});
}
export default ImageView;
