/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Box from '@mui/material/Box';
import Tooltip from '@mui/material/Tooltip';
import Typography from '@mui/material/Typography';
import { asLocalizedDateTime } from '../../../utils/datetime';
import useLocale from '../../../hooks/useLocale';
import { fromString } from '../../../utils/xml';
import useContentTypes from '../../../hooks/useContentTypes';
import { parseElementByContentType } from '../../../utils/content';
import { FormattedMessage } from 'react-intl';
export function DateTimeView(props) {
	const { xml, field } = props;
	const contentTypes = useContentTypes();
	const content = xml
		? parseElementByContentType(fromString(xml).querySelector(field.id), field, contentTypes, {})
		: '';
	const locale = useLocale();
	const isDateValid = !isNaN(Date.parse(content));
	return _jsx(Box, {
		sx: { textAlign: 'center' },
		children: _jsx(Tooltip, {
			title: content,
			children: _jsx(Typography, {
				children:
					content &&
					(isDateValid
						? asLocalizedDateTime(new Date(content).getTime(), locale.localeCode, locale.dateTimeFormatOptions)
						: _jsx(FormattedMessage, { defaultMessage: 'Invalid date format.' }))
			})
		})
	});
}
export default DateTimeView;
