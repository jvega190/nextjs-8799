/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
import AceEditor from '../AceEditor/AceEditor';
import DialogBody from '../DialogBody/DialogBody';
import DialogHeader from '../DialogHeader/DialogHeader';
import { FormattedMessage } from 'react-intl';
import DialogFooter from '../DialogFooter/DialogFooter';
import ConfirmDropdown from '../ConfirmDropdown';
import { useUnmount } from '../../hooks/useUnmount';
export function ConfigurationSamplePreviewDialogContainer(props) {
	const { content, onClose, onClosed, onUseSampleClick } = props;
	useUnmount(onClosed);
	return _jsxs(_Fragment, {
		children: [
			_jsx(DialogHeader, {
				title: _jsx(FormattedMessage, { id: 'configurationSamplePreviewDialog.title', defaultMessage: 'Sample File' }),
				onCloseButtonClick: onClose
			}),
			_jsx(DialogBody, {
				style: { height: '60vh', padding: 0 },
				children: _jsx(AceEditor, {
					sxs: {
						editorRoot: {
							margin: '0',
							border: 0,
							width: '100%',
							height: '100%'
						}
					},
					value: content,
					mode: 'ace/mode/yaml',
					theme: 'ace/theme/textmate',
					autoFocus: true,
					readOnly: true
				})
			}),
			_jsx(DialogFooter, {
				children: _jsx(ConfirmDropdown, {
					text: _jsx(FormattedMessage, {
						id: 'configurationSamplePreviewDialog.useSampleContent',
						defaultMessage: 'Use Sample Content'
					}),
					cancelText: _jsx(FormattedMessage, {
						id: 'configurationSamplePreviewDialog.replaceContent',
						defaultMessage: 'Replace current content'
					}),
					confirmText: _jsx(FormattedMessage, {
						id: 'configurationSamplePreviewDialog.appendContent',
						defaultMessage: 'Append after current content'
					}),
					onConfirm: () => onUseSampleClick('append'),
					onCancel: () => onUseSampleClick('replace')
				})
			})
		]
	});
}
export default ConfigurationSamplePreviewDialogContainer;
