/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
import EnhancedDialog from '../EnhancedDialog';
import { FormattedMessage } from 'react-intl';
import BrokenReferencesDialogContainer from './BrokenReferencesDialogContainer';
export function BrokenReferencesDialog(props) {
	const { path, references, error, onContinue, ...rest } = props;
	return _jsx(EnhancedDialog, {
		title: _jsx(FormattedMessage, { defaultMessage: 'Broken References Warning' }),
		subtitle: _jsx(FormattedMessage, {
			defaultMessage: 'Proceeding would cause items listed below to have broken references'
		}),
		...rest,
		maxWidth: 'sm',
		children: _jsx(BrokenReferencesDialogContainer, {
			path: path,
			references: references,
			onContinue: onContinue,
			error: error
		})
	});
}
export default BrokenReferencesDialog;
