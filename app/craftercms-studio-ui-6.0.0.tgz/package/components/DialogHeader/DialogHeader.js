/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import CloseIconRounded from '@mui/icons-material/CloseRounded';
import MinimizeIconRounded from '@mui/icons-material/RemoveRounded';
import ArrowBack from '@mui/icons-material/ArrowBackIosRounded';
import Tooltip from '@mui/material/Tooltip';
import { defineMessages, useIntl } from 'react-intl';
import Action from '../DialogHeaderAction/DialogHeaderAction';
import OpenInFullIcon from '@mui/icons-material/OpenInFullRounded';
import Box from '@mui/material/Box';
const translations = defineMessages({
	back: {
		id: 'words.back',
		defaultMessage: 'Back'
	},
	dismiss: {
		id: 'words.close',
		defaultMessage: 'Close'
	},
	minimize: {
		id: 'words.minimize',
		defaultMessage: 'Minimize'
	},
	fullScreen: {
		id: 'dialogHeader.toggleFullScreen',
		defaultMessage: 'Toggle full screen'
	}
});
export function DialogHeader(props) {
	// region
	const { formatMessage } = useIntl();
	const {
		id,
		onCloseButtonClick,
		onMinimizeButtonClick,
		onFullScreenButtonClick,
		disabled = false,
		onBack,
		title,
		children,
		subtitle,
		leftActions,
		rightActions,
		closeIcon: CloseIcon = CloseIconRounded,
		minimizeIcon: MinimizeIcon = MinimizeIconRounded,
		fullScreenIcon: FullScreenIcon = OpenInFullIcon,
		backIcon: BackIcon = ArrowBack,
		titleTypographyProps = {
			variant: 'h6',
			component: 'h2'
		},
		subtitleTypographyProps = {
			variant: 'subtitle1',
			component: 'p'
		},
		className,
		sxs
	} = props;
	// endregion
	return _jsxs(Box, {
		id: id,
		className: [className, props.classes?.root].filter(Boolean).join(' '),
		sx: {
			margin: 0,
			display: 'flex',
			flex: '0 0 auto',
			flexWrap: 'wrap',
			borderBottom: (theme) => `1px solid ${theme.palette.divider}`,
			padding: (theme) => theme.spacing(1),
			background: (theme) => theme.palette.background.paper,
			...(theme) => theme.mixins.toolbar,
			...sxs?.root
		},
		children: [
			_jsxs(Box, {
				component: 'section',
				className: props.classes?.titleWrapper,
				sx: { display: 'flex', width: '100%', alignItems: 'center', ...sxs?.titleWrapper },
				children: [
					(leftActions || onBack) &&
						_jsxs(Box, {
							className: props.classes?.leftActions,
							sx: { whiteSpace: 'nowrap', ...sxs?.leftActions },
							children: [
								onBack &&
									_jsx(Tooltip, {
										title: disabled ? '' : formatMessage(translations.back),
										children: _jsx(IconButton, {
											'aria-label': formatMessage(translations.back),
											onClick: onBack,
											className: props.classes?.backIcon,
											sx: sxs?.backIcon,
											size: 'large',
											disabled: disabled,
											children: _jsx(BackIcon, {})
										})
									}),
								leftActions?.map(({ icon, 'aria-label': tooltip, ...rest }, i) =>
									_jsx(Action, { icon: icon, tooltip: tooltip, disabled: disabled, ...rest }, i)
								)
							]
						}),
					_jsx(Typography, {
						...titleTypographyProps,
						className: props.classes?.title,
						sx: {
							padding: (theme) => `0 ${theme.spacing(1)}`,
							overflow: 'hidden',
							whiteSpace: 'nowrap',
							textOverflow: 'ellipsis',
							...sxs?.title
						},
						children: title
					}),
					(rightActions || onCloseButtonClick || onMinimizeButtonClick || onFullScreenButtonClick) &&
						_jsxs(Box, {
							className: props.classes?.rightActions,
							sx: { marginLeft: 'auto', whiteSpace: 'nowrap', ...sxs?.rightActions },
							children: [
								rightActions?.map(({ icon, 'aria-label': tooltip, ...rest }, i) =>
									_jsx(Action, { icon: icon, tooltip: tooltip, disabled: disabled, ...rest }, i)
								),
								onMinimizeButtonClick &&
									_jsx(Tooltip, {
										title: disabled ? '' : formatMessage(translations.minimize),
										children: _jsx(IconButton, {
											size: 'medium',
											'aria-label': formatMessage(translations.minimize),
											onClick: onMinimizeButtonClick,
											disabled: disabled,
											children: _jsx(MinimizeIcon, {})
										})
									}),
								onFullScreenButtonClick &&
									_jsx(Tooltip, {
										title: disabled ? '' : formatMessage(translations.fullScreen),
										children: _jsx(IconButton, {
											size: 'medium',
											'aria-label': formatMessage(translations.fullScreen),
											onClick: onFullScreenButtonClick,
											disabled: disabled,
											children: _jsx(FullScreenIcon, { fontSize: 'small' })
										})
									}),
								onCloseButtonClick &&
									_jsx(Tooltip, {
										title: disabled ? '' : formatMessage(translations.dismiss),
										children: _jsx(IconButton, {
											'aria-label': formatMessage(translations.dismiss),
											onClick: (event) => onCloseButtonClick(event, 'closeButton'),
											disabled: disabled,
											size: 'medium',
											children: _jsx(CloseIcon, {})
										})
									})
							]
						})
				]
			}),
			(subtitle || children) &&
				_jsxs(Box, {
					component: 'section',
					className: props.classes?.subtitleWrapper,
					sx: { padding: (theme) => theme.spacing(1), paddingTop: 0, ...sxs?.subtitleWrapper },
					children: [
						subtitle &&
							_jsx(Typography, {
								...subtitleTypographyProps,
								className: props.classes?.subtitle,
								sx: { fontSize: '14px', lineHeight: '18px', ...sxs?.subtitle },
								children: subtitle
							}),
						children
					]
				})
		]
	});
}
export default DialogHeader;
