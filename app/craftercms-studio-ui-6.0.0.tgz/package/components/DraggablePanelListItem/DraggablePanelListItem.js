/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useState } from 'react';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import DragIndicatorRounded from '@mui/icons-material/DragIndicatorRounded';
import ListItemText from '@mui/material/ListItemText';
import IconButton from '@mui/material/IconButton';
import MoreVertRounded from '@mui/icons-material/MoreVertRounded';
import { darken, useTheme } from '@mui/material/styles';
import ListItemButton from '@mui/material/ListItemButton';
import { getAvatarWithIconColors } from '../../utils/contentType';
import ListItem from '@mui/material/ListItem';
export function DraggablePanelListItem(props) {
	const {
		onMenu,
		primaryText,
		avatarSrc,
		avatarColorBase,
		secondaryText,
		onDragStart,
		onDragEnd,
		isBeingDragged = false
	} = props;
	const hasMenu = Boolean(onMenu);
	const theme = useTheme();
	const { backgroundColor, textColor } = getAvatarWithIconColors(avatarColorBase ?? primaryText, theme, darken);
	const [over, setOver] = useState(false);
	return _jsxs(
		ListItemButton,
		{
			role: 'option',
			component: ListItem,
			disableRipple: true,
			draggable: true,
			onDragStart: onDragStart,
			onDragEnd: onDragEnd,
			onMouseEnter: () => setOver(true),
			onMouseLeave: () => setOver(false),
			sx: {
				pl: 1.5,
				pr: hasMenu ? 6 : undefined,
				border: `1px solid ${isBeingDragged ? backgroundColor : 'transparent'}`,
				borderRadius: isBeingDragged ? 2 : 0,
				cursor: isBeingDragged ? 'grabbing' : 'grab'
			},
			secondaryAction: hasMenu
				? _jsx(IconButton, { edge: 'end', onClick: onMenu, size: 'small', children: _jsx(MoreVertRounded, {}) })
				: null,
			children: [
				_jsx(ListItemAvatar, {
					sx: { minWidth: 0 },
					children: _jsx(Avatar, {
						alt: '',
						src: avatarSrc,
						sx: {
							mr: 1.5,
							width: 30,
							height: 30,
							backgroundColor: over || avatarSrc ? 'transparent' : backgroundColor,
							transition: 'background-color 0.25s ease-in-out'
						},
						children: _jsx(DragIndicatorRounded, {
							fontSize: 'small',
							sx: {
								color: over ? backgroundColor : textColor,
								transition: 'color 0.25s ease-in-out'
							}
						})
					})
				}),
				_jsx(ListItemText, { primary: primaryText, secondary: secondaryText })
			]
		},
		secondaryText
	);
}
export default DraggablePanelListItem;
