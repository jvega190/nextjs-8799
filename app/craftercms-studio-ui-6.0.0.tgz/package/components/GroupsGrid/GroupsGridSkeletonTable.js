/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import Typography from '@mui/material/Typography';
import { FormattedMessage } from 'react-intl';
import TableBody from '@mui/material/TableBody';
import Skeleton from '@mui/material/Skeleton';
import { rand } from '../PathNavigator/utils';
import React from 'react';
import GlobalAppGridCell from '../GlobalAppGridCell/GlobalAppGridCell';
import GlobalAppGridRow from '../GlobalAppGridRow';
export const GroupsGridSkeletonTable = React.memo((props) => {
	const { numOfItems = 5 } = props;
	const items = new Array(numOfItems).fill(null);
	return _jsx(TableContainer, {
		children: _jsxs(Table, {
			sx: { tableLayout: 'fixed' },
			children: [
				_jsx(TableHead, {
					children: _jsxs(GlobalAppGridRow, {
						className: 'hoverDisabled',
						children: [
							_jsx(GlobalAppGridCell, {
								align: 'left',
								className: 'width25',
								children: _jsx(Typography, {
									variant: 'subtitle2',
									children: _jsx(FormattedMessage, { id: 'words.name', defaultMessage: 'Name' })
								})
							}),
							_jsx(GlobalAppGridCell, {
								align: 'left',
								children: _jsx(Typography, {
									variant: 'subtitle2',
									children: _jsx(FormattedMessage, { id: 'words.description', defaultMessage: 'Description' })
								})
							})
						]
					})
				}),
				_jsx(TableBody, {
					children: items?.map((width, index) =>
						_jsxs(
							GlobalAppGridRow,
							{
								children: [
									_jsx(GlobalAppGridCell, {
										align: 'left',
										className: 'width25',
										children: _jsx(Skeleton, { variant: 'text', width: `${rand(70, 90)}%` })
									}),
									_jsx(GlobalAppGridCell, {
										align: 'left',
										children: _jsx(Skeleton, { variant: 'text', width: `${rand(70, 90)}%` })
									})
								]
							},
							index
						)
					)
				})
			]
		})
	});
});
