/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
import AceEditor from '../AceEditor/AceEditor';
import ConflictedPathDiffDialogSplitView from './ConflictedPathDiffDialogSplitView';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import { FormattedMessage } from 'react-intl';
import Box from '@mui/material/Box';
const tabsHeight = 450;
export function ConflictedPathDiffDialogUI(props) {
	const { fileDiff, tab } = props;
	return _jsxs(Box, {
		sx: {
			height: tabsHeight,
			overflowX: 'auto',
			'& .ace_editor': {
				margin: 0
			}
		},
		children: [
			tab === 0 && _jsx(AceEditor, { mode: 'ace/mode/diff', autoFocus: false, readOnly: true, value: fileDiff.diff }),
			tab === 1 &&
				_jsxs(_Fragment, {
					children: [
						_jsxs(Grid, {
							container: true,
							sx: {
								width: 'calc(100% - 30px)',
								textAlign: 'center',
								backgroundColor: (theme) => theme.palette.background.paper
							},
							children: [
								_jsx(Grid, {
									size: 6,
									children: _jsx(Typography, {
										variant: 'body1',
										children: _jsx(FormattedMessage, { id: 'words.local', defaultMessage: 'Local' })
									})
								}),
								_jsx(Grid, {
									size: 6,
									children: _jsx(Typography, {
										variant: 'body1',
										children: _jsx(FormattedMessage, { id: 'words.remote', defaultMessage: 'Remote' })
									})
								})
							]
						}),
						_jsx(ConflictedPathDiffDialogSplitView, {
							diff: fileDiff,
							sx: {
								width: '100%',
								height: 'calc(100% - 24px)',
								'&.unChanged': {
									height: 'auto'
								}
							}
						})
					]
				})
		]
	});
}
export default ConflictedPathDiffDialogUI;
