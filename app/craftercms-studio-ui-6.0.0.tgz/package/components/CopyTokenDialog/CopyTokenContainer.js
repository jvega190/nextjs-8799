/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useRef } from 'react';
import { FormattedMessage } from 'react-intl';
import DialogBody from '../DialogBody/DialogBody';
import InputBase from '@mui/material/InputBase';
import DialogFooter from '../DialogFooter/DialogFooter';
import SecondaryButton from '../SecondaryButton';
import PrimaryButton from '../PrimaryButton';
import { copyToClipboard } from '../../utils/system';
import useMount from '../../hooks/useMount';
import Alert from '@mui/material/Alert';
export function CopyTokenContainer(props) {
	const { onClose, token, onCopy } = props;
	// TODO: Ref not in use. Remove?
	const inputRef = useRef(undefined);
	const copyToken = () => {
		copyToClipboard(token.token).then(() => onCopy());
	};
	useMount(() => {
		if (token) {
			copyToken();
		}
	});
	return _jsxs(_Fragment, {
		children: [
			_jsxs(DialogBody, {
				children: [
					_jsx(Alert, {
						variant: 'outlined',
						severity: 'success',
						children: _jsx(FormattedMessage, {
							id: 'copyTokenDialog.helperText',
							defaultMessage:
								'Token created successfully. Please copy the token and store it securely as you won\u2019t be able to see it\u2019s value again.'
						})
					}),
					_jsx(InputBase, {
						inputRef: inputRef,
						autoFocus: true,
						value: token?.token ?? '',
						readOnly: true,
						sx: {
							marginTop: '16px',
							marginBottom: '8px'
						},
						onClick: (e) => {
							e.target.select();
							copyToken();
						}
					})
				]
			}),
			_jsxs(DialogFooter, {
				sx: { display: 'flex', alignItems: 'center', justifyContent: 'space-between' },
				children: [
					_jsx(SecondaryButton, {
						onClick: () => copyToken(),
						children: _jsx(FormattedMessage, { id: 'words.copy', defaultMessage: 'Copy' })
					}),
					_jsx(PrimaryButton, {
						onClick: (e) => onClose(e, null),
						children: _jsx(FormattedMessage, { id: 'words.done', defaultMessage: 'Done' })
					})
				]
			})
		]
	});
}
export default CopyTokenContainer;
