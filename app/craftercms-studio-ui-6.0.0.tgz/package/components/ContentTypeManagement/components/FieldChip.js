/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2025 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import ButtonBase from '@mui/material/ButtonBase';
import { alpha } from '@mui/system/colorManipulator';
import Typography from '@mui/material/Typography';
import { capitalize } from '../../../utils/string';
import { FormattedMessage, useIntl } from 'react-intl';
import useIsDarkModeTheme from '../../../hooks/useIsDarkModeTheme';
import Asterisk from '../../../icons/Asterisk';
import controlDescriptors from '../descriptors/controls';
import dataSourceDescriptors from '../descriptors/dataSources';
import { applyTranslations } from '../utils';
import Button from '@mui/material/Button';
function composeFieldPath(fieldPath, fieldId) {
	return fieldPath ? `${fieldPath}.${fieldId}` : fieldId;
}
const descriptors = { ...controlDescriptors, ...dataSourceDescriptors };
export function FieldChip(props) {
	const { field, fieldPathsWithErrors, fieldPath, selectedFieldIdPath, onFieldSelected, onInsertField } = props;
	const theme = useTheme();
	const isDark = useIsDarkModeTheme();
	const isRepeat = field.type === 'repeat';
	const currentFieldPath = composeFieldPath(fieldPath, field.id);
	const isSelected = currentFieldPath === selectedFieldIdPath;
	const error = Boolean(fieldPathsWithErrors[currentFieldPath]); // TODO: make this into an atom
	const Root = isRepeat ? Box : ButtonBase;
	const Title = isRepeat ? ButtonBase : 'div';
	const onClick = (e) => onFieldSelected?.(currentFieldPath, field, e);
	const selectorButtonStyles = {
		'&:active': { boxShadow: theme.shadows[1] },
		'&:hover': {
			bgcolor: alpha(
				theme.palette.action.selected,
				theme.palette.action.selectedOpacity + theme.palette.action.hoverOpacity
			)
		}
	};
	const selectorButtonSelectedStyles = {
		bgcolor: 'action.selected',
		'&:hover': { bgcolor: 'action.selected' }
	};
	const { formatMessage } = useIntl();
	return _jsxs(Root, {
		disabled: isSelected,
		sx: [
			{
				mb: 1,
				width: '100%',
				alignItems: 'start',
				flexDirection: 'column',
				bgcolor: isDark ? 'grey.800' : 'grey.200',
				borderRadius: 10,
				overflow: 'hidden',
				borderWidth: '1px',
				borderStyle: 'solid',
				borderColor: 'transparent'
			},
			isRepeat ? { borderRadius: 2 } : selectorButtonStyles,
			isSelected && selectorButtonSelectedStyles,
			error && { borderWidth: '1px', borderStyle: 'solid', borderColor: 'error.main' }
		],
		// @ts-expect-error: Handled. Only when it is a button will it receive the onClick.
		onClick: isRepeat ? undefined : onClick,
		children: [
			_jsxs(Box, {
				component: Title,
				// @ts-expect-error: Handled. Only when it is a button will it receive the onClick.
				onClick: isRepeat ? onClick : undefined,
				disabled: isSelected,
				sx: [
					{
						px: 1.5,
						py: 0.5,
						width: '100%',
						display: 'flex',
						flexWrap: 'wrap',
						alignItems: 'center',
						justifyContent: 'space-between'
					},
					isRepeat && selectorButtonStyles,
					error && { color: 'error.main' }
				],
				children: [
					_jsxs(Box, {
						display: 'flex',
						alignItems: 'center',
						children: [
							field.NEW
								? _jsx(Typography, {
										component: 'strong',
										sx: { mr: 0.5, fontWeight: 600 },
										children: _jsx(FormattedMessage, { defaultMessage: `Draft ({type})`, values: { type: field.type } })
									})
								: _jsxs(_Fragment, {
										children: [
											_jsx(Typography, { component: 'strong', sx: { mr: 0.5, fontWeight: 600 }, children: field.name }),
											_jsxs(Typography, { component: 'span', variant: 'body2', children: ['(', field.id, ')'] })
										]
									}),
							error && _jsx(Asterisk, { fontSize: 'small' })
						]
					}),
					_jsx(Typography, {
						variant: 'body2',
						children: descriptors[field.type]
							? applyTranslations(descriptors[field.type], formatMessage).name
							: capitalize(field.type).replaceAll('-', ' ')
					})
				]
			}),
			isRepeat &&
				_jsxs(Box, {
					p: 1,
					pt: 0,
					children: [
						Object.entries(field.fields).map(([fieldId, subField]) =>
							_jsx(
								FieldChip,
								{
									field: subField,
									fieldPathsWithErrors: fieldPathsWithErrors,
									selectedFieldIdPath: selectedFieldIdPath,
									fieldPath: currentFieldPath,
									onFieldSelected: onFieldSelected,
									onInsertField: onInsertField
								},
								fieldId
							)
						),
						_jsx(Button, {
							onClick: () => onInsertField(currentFieldPath),
							children: _jsx(FormattedMessage, { defaultMessage: 'Add Field' })
						})
					]
				})
		]
	});
}
export default FieldChip;
