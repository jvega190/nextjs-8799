/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import { useMemo, useRef, useState } from 'react';
import Select from '@mui/material/Select';
import TextField from '@mui/material/TextField';
import { DialogBody } from '../../DialogBody';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import { FormattedMessage, useIntl } from 'react-intl';
import MenuItem from '@mui/material/MenuItem';
import InputAdornment from '@mui/material/InputAdornment';
import { DialogFooter } from '../../DialogFooter';
import SecondaryButton from '../../SecondaryButton';
import PrimaryButton from '../../PrimaryButton';
import { EnhancedDialog } from '../../EnhancedDialog';
import { camelize } from '../../../utils/string';
import useEnhancedDialogContext from '../../EnhancedDialog/useEnhancedDialogContext';
import useContentTypes from '../../../hooks/useContentTypes';
import { fetchContentTypes } from '../../../services/contentTypes';
import useActiveSiteId from '../../../hooks/useActiveSiteId';
import { createLookupTable } from '../../../utils/object';
import { useDispatch } from 'react-redux';
import { fetchContentTypesComplete } from '../../../state/actions/preview';
import { pushErrorDialog } from '../../../utils/system';
import useArchetypesList from '../../../hooks/useArchetypesList';
import { getPossibleTranslation } from '../../../utils/i18n';
export function CreateTypeDialog(props) {
	// Make sure to extract all non-dialog props.
	const { onAccept, ...dialogProps } = props;
	return _jsx(EnhancedDialog, {
		maxWidth: 'xs',
		fullWidth: true,
		title: _jsx(FormattedMessage, { defaultMessage: 'Create Content Type' }),
		...dialogProps,
		children: _jsx(CreateTypeDialogBody, { onAccept: onAccept })
	});
}
const prefixes = {
	page: '/page/',
	component: '/component/'
};
function CreateTypeDialogBody(props) {
	const { onAccept } = props;
	const siteId = useActiveSiteId();
	const [type, setType] = useState('page');
	const [name, setName] = useState('');
	const [id, setId] = useState('');
	const prefix = useRef(undefined);
	prefix.current = getTypeIdPathPrefixForType(type);
	const { onClose, updateSubmittingOrHasPendingChanges } = useEnhancedDialogContext();
	const contentTypes = useContentTypes();
	const [nameExists, setNameExists] = useState(false);
	const [idExists, setIdExists] = useState(false);
	const isValid = useMemo(() => {
		return validate({ id, name, type, contentTypes, setNameExists, setIdExists });
	}, [id, name, type, contentTypes]);
	const enableSubmit = Boolean(isValid) && Boolean(name) && Boolean(id) && Boolean(type);
	const [fetchingContentTypes, setFetchingContentTypes] = useState(false);
	const dispatch = useDispatch();
	const [idManuallyChanged, setIdManuallyChanged] = useState(false);
	const archetypes = useArchetypesList();
	const { formatMessage } = useIntl();
	const validateAndSubmit = () => {
		setFetchingContentTypes(true);
		updateSubmittingOrHasPendingChanges({ isSubmitting: true });
		fetchContentTypes(siteId).subscribe({
			next: (typesList) => {
				setFetchingContentTypes(false);
				updateSubmittingOrHasPendingChanges({ isSubmitting: true });
				// Update content types list
				dispatch(fetchContentTypesComplete(typesList));
				const valid = validate({
					id,
					name,
					type,
					contentTypes: createLookupTable(typesList),
					setNameExists,
					setIdExists
				});
				if (!valid) return;
				onAccept?.({ type, name, id: `${getTypeIdPathPrefixForType(type) ?? ''}${id}` });
			},
			error: ({ response }) => {
				dispatch(pushErrorDialog({ props: { error: response.response } }));
				setFetchingContentTypes(false);
				updateSubmittingOrHasPendingChanges({ isSubmitting: false });
			}
		});
	};
	const handleChange = (e) => {
		const archetype = e.target.value;
		updateSubmittingOrHasPendingChanges({ hasPendingChanges: true });
		setType(archetype);
	};
	const handleNameChange = (name) => {
		setName(name);
		if (!idManuallyChanged) {
			setId(suggestTypeId(name));
		}
		updateSubmittingOrHasPendingChanges({ hasPendingChanges: true });
	};
	const handleIdChange = (id) => {
		setId(id);
		setIdManuallyChanged(id !== '');
		updateSubmittingOrHasPendingChanges({ hasPendingChanges: true });
	};
	const handleFormSubmit = (e) => {
		e.preventDefault();
		validateAndSubmit();
	};
	return _jsxs('form', {
		onSubmit: handleFormSubmit,
		children: [
			_jsxs(DialogBody, {
				children: [
					_jsxs(FormControl, {
						fullWidth: true,
						children: [
							_jsx(InputLabel, {
								id: 'archetypeSelectLabel',
								children: _jsx(FormattedMessage, { defaultMessage: 'Archetype' })
							}),
							_jsx(Select, {
								id: 'archetypeSelect',
								value: type,
								labelId: 'archetypeSelectLabel',
								label: _jsx(FormattedMessage, { defaultMessage: 'Archetype' }),
								onChange: handleChange,
								autoFocus: true,
								children: archetypes?.map((archetype) =>
									_jsx(
										MenuItem,
										{ value: archetype.id, children: getPossibleTranslation(archetype.name, formatMessage) },
										archetype.id
									)
								)
							})
						]
					}),
					_jsx(TextField, {
						margin: 'normal',
						value: name,
						label: _jsx(FormattedMessage, { defaultMessage: 'Label' }),
						onChange: (e) => handleNameChange(e.target.value),
						error: nameExists,
						helperText: nameExists && _jsx(FormattedMessage, { defaultMessage: 'Label already exists' })
					}),
					_jsx(TextField, {
						margin: 'dense',
						value: id,
						label: _jsx(FormattedMessage, { defaultMessage: 'Identifier' }),
						slotProps: {
							input: {
								startAdornment: _jsx(InputAdornment, { position: 'start', sx: { mr: 0 }, children: prefix.current })
							}
						},
						onChange: (e) => handleIdChange(e.target.value),
						error: idExists,
						helperText: idExists && _jsx(FormattedMessage, { defaultMessage: 'Identifier already exists' })
					})
				]
			}),
			_jsxs(DialogFooter, {
				children: [
					_jsx(SecondaryButton, {
						onClick: (e) => onClose?.(e, null),
						children: _jsx(FormattedMessage, { defaultMessage: 'Cancel' })
					}),
					_jsx(PrimaryButton, {
						type: 'submit',
						loading: fetchingContentTypes,
						disabled: !enableSubmit,
						children: _jsx(FormattedMessage, { defaultMessage: 'Accept' })
					})
				]
			})
		]
	});
}
function validate({ id, name, type, contentTypes, setNameExists, setIdExists }) {
	if (!id || !name || !type) return false;
	const idExists = Boolean(contentTypes[`${getTypeIdPathPrefixForType(type)}${id}`]);
	const nameExists = Object.values(contentTypes).some((contentType) => contentType.name === name);
	setIdExists(idExists);
	setNameExists(nameExists);
	// Validation will fail if either id or name already exists
	return !(idExists || nameExists);
}
function transformId(value) {
	return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}
function suggestTypeId(label) {
	// Replace spaces with hyphens so camelize() can produce camelCase.
	let sanitized = label.replace(/\s/g, '-').replace(/[^-A-Za-z0-9]/g, '');
	// Ensure the first character is a letter or underscore
	if (sanitized !== '' && !/^[_A-Za-z]/.test(sanitized)) {
		sanitized = `_${sanitized}`;
	}
	let camelized = camelize(sanitized);
	camelized = camelized.charAt(0).toLowerCase() + camelized.substring(1);
	return transformId(camelized);
}
function getTypeIdPathPrefixForType(type) {
	return prefixes[type] ?? `/${type}/`;
}
export default CreateTypeDialog;
