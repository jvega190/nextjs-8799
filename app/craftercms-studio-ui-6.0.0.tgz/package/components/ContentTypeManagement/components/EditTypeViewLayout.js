/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2025 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Box from '@mui/material/Box';
import Tooltip from '@mui/material/Tooltip';
import { FormattedMessage } from 'react-intl';
import IconButton from '@mui/material/IconButton';
import ArrowBackRounded from '@mui/icons-material/ArrowBackRounded';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import MoreVertRounded from '@mui/icons-material/MoreVertRounded';
import { forwardRef, useRef, useState } from 'react';
import Layout from './Layout';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
const actionsMap = {
	exit: 'exit',
	save: 'save',
	viewXml: 'viewXml',
	diff: 'diff',
	history: 'history',
	rollback: 'rollback'
};
export const EditTypeViewLayout = forwardRef((props, ref) => {
	const [open, setOpen] = useState(false);
	const anchorElRef = useRef(undefined);
	const handleOpenMenuButton = () => setOpen(true);
	const handleClose = () => setOpen(false);
	const handleMenuItemClick = (e) => {
		setOpen(false);
		const action = e.currentTarget.getAttribute('data-action-id');
		props.onActionClick?.(e, action);
	};
	return _jsx(Layout, {
		...props,
		ref: ref,
		toolbarContent: _jsxs(_Fragment, {
			children: [
				_jsxs(Box, {
					display: 'flex',
					alignItems: 'center',
					children: [
						_jsx(Tooltip, {
							title: _jsx(FormattedMessage, { defaultMessage: 'Done' }),
							children: _jsx(IconButton, {
								'data-action-id': actionsMap.exit,
								onClick: handleMenuItemClick,
								sx: { mr: 1 },
								children: _jsx(ArrowBackRounded, {})
							})
						}),
						_jsx(Typography, {
							variant: 'h5',
							component: 'h1',
							noWrap: true,
							children: props.isNew
								? _jsx(FormattedMessage, { defaultMessage: 'New Content Type' })
								: _jsx(FormattedMessage, { defaultMessage: 'Edit Content Type' })
						})
					]
				}),
				_jsxs(Box, {
					display: 'flex',
					alignItems: 'center',
					children: [
						_jsx(Button, {
							variant: 'contained',
							sx: { mr: 1 },
							'data-action-id': actionsMap.save,
							onClick: handleMenuItemClick,
							disabled: props.disableSave,
							children: _jsx(FormattedMessage, { defaultMessage: 'Save' })
						}),
						_jsx(IconButton, { ref: anchorElRef, onClick: handleOpenMenuButton, children: _jsx(MoreVertRounded, {}) }),
						_jsxs(Menu, {
							open: open,
							anchorEl: anchorElRef.current,
							onClose: handleClose,
							slotProps: { list: { 'aria-labelledby': '' } },
							children: [
								_jsx(MenuItem, {
									onClick: handleMenuItemClick,
									'data-action-id': actionsMap.viewXml,
									children: _jsx(FormattedMessage, { defaultMessage: 'View XML' })
								}),
								_jsx(MenuItem, {
									onClick: handleMenuItemClick,
									'data-action-id': actionsMap.diff,
									children: _jsx(FormattedMessage, { defaultMessage: 'Diff' })
								}),
								!props.isNew &&
									_jsx(MenuItem, {
										onClick: handleMenuItemClick,
										'data-action-id': actionsMap.history,
										children: _jsx(FormattedMessage, { defaultMessage: 'History' })
									}),
								_jsx(MenuItem, {
									onClick: handleMenuItemClick,
									'data-action-id': actionsMap.rollback,
									children: _jsx(FormattedMessage, { defaultMessage: 'Rollback' })
								})
							]
						})
					]
				})
			]
		})
	});
});
export default EditTypeViewLayout;
