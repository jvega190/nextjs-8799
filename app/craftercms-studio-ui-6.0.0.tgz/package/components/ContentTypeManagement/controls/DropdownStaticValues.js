/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2025 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useId } from 'react';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormsEngineField from '../../FormsEngine/components/FormsEngineField';
/**
 * Enables the selection of a key/value pair from a predefined list of options.
 */
export function DropdownStaticValues(props) {
	const { field, value: options, setValue, readonly, autoFocus } = props;
	const htmlId = useId();
	const selectedOption = options.find((option) => option.selected);
	const handleChange = (event) => {
		const selectedValue = event.target.value;
		const newOptions = options.map((option) => ({
			...option,
			selected: option.value === selectedValue
		}));
		setValue(newOptions);
	};
	return _jsx(FormsEngineField, {
		field: field,
		labelId: htmlId,
		children: _jsx(Select, {
			value: selectedOption?.value ?? '',
			labelId: htmlId,
			onChange: handleChange,
			disabled: readonly,
			autoFocus: autoFocus,
			children: options.map((option) => _jsx(MenuItem, { value: option.value, children: option.label }, option.value))
		})
	});
}
export default DropdownStaticValues;
