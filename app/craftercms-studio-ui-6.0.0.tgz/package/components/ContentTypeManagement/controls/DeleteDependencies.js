/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2026 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useId } from 'react';
import FormsEngineField from '../../FormsEngine/components/FormsEngineField';
import { FormattedMessage, useIntl } from 'react-intl';
import TextField from '@mui/material/TextField';
import Card from '@mui/material/Card';
import { Switch } from '@mui/material';
import FormControlLabel from '@mui/material/FormControlLabel';
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import AddCircleOutlineRoundedIcon from '@mui/icons-material/AddCircleOutlineRounded';
import Box from '@mui/material/Box';
import RemoveCircleOutlineRoundedIcon from '@mui/icons-material/RemoveCircleOutlineRounded';
export function DeleteDependencies(props) {
	const { field, value, setValue } = props;
	const deleteDependencies = value?.['delete-dependency'] ?? [];
	const htmlId = useId();
	const { formatMessage } = useIntl();
	const handleChange = (e, prop, index) => {
		const nextArr = deleteDependencies.slice();
		nextArr[index] = {
			...deleteDependencies[index],
			[prop]: prop === 'pattern' ? e.currentTarget.value : e.target.checked
		};
		setValue({ 'delete-dependency': nextArr });
	};
	const addDependency = () => {
		setValue({
			'delete-dependency': [...deleteDependencies, { pattern: '', 'remove-empty-folder': false }]
		});
	};
	const removeDependency = (index) => {
		const nextArr = deleteDependencies.filter((_, i) => i !== index);
		setValue({ 'delete-dependency': nextArr });
	};
	return _jsxs(FormsEngineField, {
		htmlFor: htmlId,
		field: field,
		children: [
			deleteDependencies?.map((dependency, index) =>
				_jsxs(
					Card,
					{
						variant: 'outlined',
						sx: { display: 'flex', flexDirection: 'row', my: 1, p: 1.5, gap: 1 },
						children: [
							_jsxs(Box, {
								sx: { gap: 1, display: 'flex', flexDirection: 'column', flex: 1 },
								children: [
									_jsx(TextField, {
										fullWidth: true,
										label: _jsx(FormattedMessage, { defaultMessage: 'Pattern' }),
										value: dependency.pattern,
										variant: 'outlined',
										onChange: (e) => handleChange(e, 'pattern', index)
									}),
									_jsx(FormControlLabel, {
										control: _jsx(Switch, {
											checked: dependency['remove-empty-folder'] ?? false,
											onChange: (e) => handleChange(e, 'remove-empty-folder', index)
										}),
										label: _jsx(FormattedMessage, { defaultMessage: 'Remove empty folder' })
									})
								]
							}),
							_jsx(Box, {
								display: 'flex',
								alignItems: 'center',
								children: _jsx(Tooltip, {
									title: _jsx(FormattedMessage, { defaultMessage: 'Remove Reference' }),
									children: _jsx(IconButton, {
										'aria-label': formatMessage({ defaultMessage: 'Remove Reference' }),
										onClick: () => removeDependency(index),
										children: _jsx(RemoveCircleOutlineRoundedIcon, {})
									})
								})
							})
						]
					},
					index
				)
			),
			_jsx(Box, {
				display: 'flex',
				justifyContent: 'center',
				children: _jsx(Tooltip, {
					title: _jsx(FormattedMessage, { defaultMessage: 'Add Reference' }),
					children: _jsx(IconButton, {
						'aria-label': formatMessage({ defaultMessage: 'Add Reference' }),
						onClick: () => addDependency(),
						children: _jsx(AddCircleOutlineRoundedIcon, {})
					})
				})
			})
		]
	});
}
export default DeleteDependencies;
