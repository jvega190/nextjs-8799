/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useMemo, useState } from 'react';
import FormsEngineField from '../../FormsEngine/components/FormsEngineField';
import useContentTypes from '../../../hooks/useContentTypes';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemButton from '@mui/material/ListItemButton';
import CheckBoxRoundedIcon from '@mui/icons-material/CheckBoxRounded';
import CheckBoxOutlineBlankRoundedIcon from '@mui/icons-material/CheckBoxOutlineBlankRounded';
import { asArray, createPresenceTable } from '../../../utils/array';
import { EmptyState } from '../../EmptyState';
import { FormattedMessage } from 'react-intl';
import { reversePluckProps } from '../../../utils/object';
import { SearchBar } from '../../SearchBar';
import { getPropertyValue } from '../../FormsEngine/lib/formUtils';
/**
 * Enables the selection of multiple content types using a checkbox group layout.
 */
export function ContentTypesSelector(props) {
	const { field, value, setValue } = props;
	const maxLength = field.validations?.maxLength?.value;
	const type = getPropertyValue(field.properties, 'type', 'component');
	const contentTypes = useContentTypes();
	const [selectedLookup, setSelectedLookup] = useState(createPresenceTable(asArray(value)));
	const [searchTerm, setSearchTerm] = useState('');
	const components = useMemo(
		() =>
			Object.values(contentTypes).filter((contentType) => {
				return (
					contentType.type === type &&
					(contentType.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
						contentType.name.toLowerCase().includes(searchTerm.toLowerCase()))
				);
			}),
		[contentTypes, searchTerm, type]
	);
	const handleToggle = (selectionValue) => () => {
		let newSelectedLookup = {};
		// We use '*' meaning that all components are selected
		if (selectionValue === '*') {
			const isSelected = value === '*';
			if (!isSelected) {
				newSelectedLookup[selectionValue] = true;
			}
		} else {
			const isSelected = selectedLookup[selectionValue];
			// ensure that when selecting individual content types, '*' won't be in the selectedLookup
			newSelectedLookup = { ...reversePluckProps(selectedLookup, '*'), [selectionValue]: !isSelected };
		}
		setSelectedLookup(newSelectedLookup);
		const selectedArray = Object.entries(newSelectedLookup)
			.filter(([, value]) => value)
			.map(([key]) => key);
		setValue(selectedArray);
	};
	const handleSearchChange = (value) => {
		setSearchTerm(value);
	};
	return _jsxs(FormsEngineField, {
		field: field,
		max: maxLength,
		children: [
			_jsx(SearchBar, { keyword: searchTerm, onChange: handleSearchChange, autoFocus: true }),
			_jsx(List, {
				children:
					components.length === 0
						? _jsx(EmptyState, { title: _jsx(FormattedMessage, { defaultMessage: 'No content types available' }) })
						: _jsxs(_Fragment, {
								children: [
									_jsx(ListItem, {
										sx: { bgcolor: 'background.paper', p: 0 },
										children: _jsxs(ListItemButton, {
											role: 'checkbox',
											'aria-checked': Boolean(selectedLookup['*']),
											onClick: handleToggle('*'),
											dense: true,
											children: [
												_jsx(ListItemIcon, {
													sx: { py: 1 },
													children: selectedLookup['*']
														? _jsx(CheckBoxRoundedIcon, { color: 'primary' })
														: _jsx(CheckBoxOutlineBlankRoundedIcon, {})
												}),
												_jsx(ListItemText, {
													primary:
														type === 'page'
															? _jsx(FormattedMessage, { defaultMessage: 'Allow any page' })
															: _jsx(FormattedMessage, { defaultMessage: 'Allow any component' })
												})
											]
										})
									}),
									components.map((contentType) =>
										_jsx(
											ListItem,
											{
												sx: { bgcolor: 'background.paper', p: 0 },
												children: _jsxs(ListItemButton, {
													onClick: handleToggle(contentType.id),
													dense: true,
													disabled: value === '*',
													children: [
														_jsx(ListItemIcon, {
															sx: { py: 1 },
															children: selectedLookup[contentType.id]
																? _jsx(CheckBoxRoundedIcon, { color: 'primary' })
																: _jsx(CheckBoxOutlineBlankRoundedIcon, {})
														}),
														_jsx(ListItemText, { primary: contentType.name })
													]
												})
											},
											contentType.id
										)
									)
								]
							})
			})
		]
	});
}
export default ContentTypesSelector;
