/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2026 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useId } from 'react';
import FormsEngineField from '../../FormsEngine/components/FormsEngineField';
import { FormattedMessage } from 'react-intl';
import TextField from '@mui/material/TextField';
import Card from '@mui/material/Card';
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import AddCircleOutlineRoundedIcon from '@mui/icons-material/AddCircleOutlineRounded';
import Box from '@mui/material/Box';
import RemoveCircleOutlineRoundedIcon from '@mui/icons-material/RemoveCircleOutlineRounded';
export function CopyDependencies(props) {
	const { field, value, setValue } = props;
	const copyDependencies = value?.['copy-dependency'] ?? [];
	const htmlId = useId();
	const handleChange = (e, prop, index) => {
		const nextArr = copyDependencies.slice();
		nextArr[index] = {
			...copyDependencies[index],
			[prop]: e.currentTarget.value
		};
		setValue({ 'copy-dependency': nextArr });
	};
	const addDependency = () => {
		setValue({ 'copy-dependency': [...copyDependencies, { pattern: '', target: '' }] });
	};
	const removeDependency = (index) => {
		const nextArr = copyDependencies.filter((_, i) => i !== index);
		setValue({ 'copy-dependency': nextArr });
	};
	return _jsxs(FormsEngineField, {
		htmlFor: htmlId,
		field: field,
		children: [
			copyDependencies?.map((dependency, index) =>
				_jsxs(
					Card,
					{
						variant: 'outlined',
						sx: { display: 'flex', flexDirection: 'row', my: 1, p: 1.5, gap: 1 },
						children: [
							_jsxs(Box, {
								sx: { gap: 2, display: 'flex', flexDirection: 'column', flex: 1 },
								children: [
									_jsx(TextField, {
										fullWidth: true,
										label: _jsx(FormattedMessage, { defaultMessage: 'Pattern' }),
										value: dependency.pattern,
										variant: 'outlined',
										onChange: (e) => handleChange(e, 'pattern', index)
									}),
									_jsx(TextField, {
										fullWidth: true,
										label: _jsx(FormattedMessage, { defaultMessage: 'Target' }),
										value: dependency.target,
										variant: 'outlined',
										onChange: (e) => handleChange(e, 'target', index)
									})
								]
							}),
							_jsx(Box, {
								display: 'flex',
								alignItems: 'center',
								children: _jsx(Tooltip, {
									title: _jsx(FormattedMessage, { defaultMessage: 'Remove Reference' }),
									children: _jsx(IconButton, {
										onClick: () => removeDependency(index),
										children: _jsx(RemoveCircleOutlineRoundedIcon, {})
									})
								})
							})
						]
					},
					index
				)
			),
			_jsx(Box, {
				display: 'flex',
				justifyContent: 'center',
				children: _jsx(Tooltip, {
					title: _jsx(FormattedMessage, { defaultMessage: 'Add Reference' }),
					children: _jsx(IconButton, {
						onClick: () => addDependency(),
						children: _jsx(AddCircleOutlineRoundedIcon, {})
					})
				})
			})
		]
	});
}
export default CopyDependencies;
