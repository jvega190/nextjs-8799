/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2025 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useMemo } from 'react';
import FormsEngineField from '../../FormsEngine/components/FormsEngineField';
import FormControlLabel from '@mui/material/FormControlLabel';
import RadioGroup from '@mui/material/RadioGroup';
import Radio from '@mui/material/Radio';
import { EmptyState } from '../../EmptyState';
/**
 * Allows the selection of a single data source compatible with the field type, using a radio group layout.
 */
export function DataSourceSingleSelector(props) {
	const { field, value, setValue, contentType } = props;
	const type = field.validations.type?.value;
	const filteredDataSources = useMemo(() => {
		return (contentType.dataSources ?? []).filter((ds) => ds.interface === type);
	}, [contentType?.dataSources, type]);
	const handleChange = (e) => setValue(e.currentTarget.value);
	return _jsx(FormsEngineField, {
		field: field,
		children: _jsx(RadioGroup, {
			value: value ?? '',
			onChange: handleChange,
			children: filteredDataSources.length
				? filteredDataSources.map((ds) =>
						_jsx(FormControlLabel, { value: ds.id, control: _jsx(Radio, {}), label: ds.title }, ds.id)
					)
				: _jsx(EmptyState, { title: 'No Data Sources available', sxs: { image: { display: 'none' } } })
		})
	});
}
export default DataSourceSingleSelector;
