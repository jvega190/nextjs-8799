/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Box from '@mui/material/Box';
import { forwardRef, useEffect, useState } from 'react';
import { defineMessages, FormattedMessage, useIntl } from 'react-intl';
import GlobalAppToolbar from '../GlobalAppToolbar';
import { Checkbox, FormControlLabel, Typography } from '@mui/material';
import Paper, { paperClasses } from '@mui/material/Paper';
import Avatar from '@mui/material/Avatar';
import Container from '@mui/material/Container';
import { dispatchLanguageChange, getCurrentLocale, setStoredLanguage } from '../../utils/i18n';
import { fetchProductLanguages } from '../../services/configuration';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import Skeleton from '@mui/material/Skeleton';
import PasswordTextField from '../PasswordTextField/PasswordTextField';
import PrimaryButton from '../PrimaryButton';
import { setMyPassword } from '../../services/users';
import { useDispatch } from 'react-redux';
import { showSystemNotification } from '../../state/actions/system';
import { useActiveUser } from '../../hooks/useActiveUser';
import { PasswordStrengthDisplayPopper } from '../PasswordStrengthDisplayPopper';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import useSiteLookup from '../../hooks/useSiteLookup';
import Button from '@mui/material/Button';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import { preferencesGroups } from './utils';
import { NumberField } from '@base-ui-components/react/number-field';
import OutlinedInput from '@mui/material/OutlinedInput';
import AddRounded from '@mui/icons-material/AddRounded';
import MinusRounded from '@mui/icons-material/RemoveRounded';
import { pushErrorDialog } from '../../utils/system';
import {
	getStoredEnableAnimations,
	getStoredSnackbarDuration,
	setStoredEnableAnimations,
	setStoredSnackbarDuration
} from '../../utils/state';
const decrementButtonSx = {
	borderTopRightRadius: 0,
	borderBottomRightRadius: 0,
	boxShadow: 'none',
	borderRight: 'none'
};
const incrementButtonSx = {
	borderTopLeftRadius: 0,
	borderBottomLeftRadius: 0,
	boxShadow: 'none',
	borderLeft: 'none'
};
// MUI OutlinedInput's ref points to the wrapper elements, not to the input. Base UI needs the input directly.
const OutlinedInputWithRef = forwardRef((props, ref) => {
	const { sx, ...other } = props;
	return _jsx(OutlinedInput, {
		...other,
		fullWidth: true,
		inputRef: ref,
		sx: { borderRadius: 0, py: '0px', input: { textAlign: 'center' }, ...sx }
	});
});
OutlinedInputWithRef.displayName = 'OutlinedInputWithRef';
const translations = defineMessages({
	languageUpdated: {
		id: 'accountManagement.languageUpdated',
		defaultMessage: 'Language preference changed'
	},
	passwordChanged: {
		id: 'accountManagement.passwordChanged',
		defaultMessage: 'Password changed successfully'
	}
});
export const DEFAULT_SNACKBAR_DURATION = 5000;
export function AccountManagement(props) {
	const { passwordRequirementsMinComplexity = 4 } = props;
	const user = useActiveUser();
	const [language, setLanguage] = useState(() => getCurrentLocale());
	const [languages, setLanguages] = useState();
	const [currentPassword, setCurrentPassword] = useState('');
	const [newPassword, setNewPassword] = useState('');
	const [verifiedPassword, setVerifiedPassword] = useState('');
	const [validPassword, setValidPassword] = useState(false);
	const dispatch = useDispatch();
	const { formatMessage } = useIntl();
	const [anchorEl, setAnchorEl] = useState(null);
	const sitesLookup = useSiteLookup();
	const sitesIds = Object.keys(sitesLookup);
	const [selectedSite, setSelectedSite] = useState('all');
	const [snackDuration, setSnackDuration] = useState(
		getStoredSnackbarDuration(user.username) ?? DEFAULT_SNACKBAR_DURATION
	);
	const [initialSnackDuration, setInitialSnackDuration] = useState(snackDuration);
	const [enableAnimations, setEnableAnimations] = useState(getStoredEnableAnimations(user.username) ?? true);
	const [initialEnableAnimations, setInitialEnableAnimations] = useState(enableAnimations);
	// Retrieve Platform Languages.
	useEffect(() => {
		fetchProductLanguages().subscribe(setLanguages);
	}, []);
	const onLanguageChanged = (language) => {
		setLanguage(language);
		setStoredLanguage(language, user.username);
		dispatchLanguageChange(language);
		dispatch(
			showSystemNotification({
				message: formatMessage(translations.languageUpdated)
			})
		);
	};
	const onSave = () => {
		setMyPassword(user.username, currentPassword, newPassword).subscribe({
			next() {
				dispatch(
					showSystemNotification({
						message: formatMessage(translations.passwordChanged)
					})
				);
				setCurrentPassword('');
				setVerifiedPassword('');
				setNewPassword('');
			},
			error({ response: { response } }) {
				dispatch(pushErrorDialog({ props: { error: response } }));
			}
		});
	};
	const onClearPreference = (group, showNotification = true) => {
		if (selectedSite === 'all') {
			sitesIds.forEach((siteId) => {
				group.onClear({
					siteId,
					siteUuid: sitesLookup[siteId].uuid,
					username: user.username
				});
			});
		} else {
			group.onClear({
				siteId: selectedSite,
				siteUuid: sitesLookup[selectedSite].uuid,
				username: user.username
			});
		}
		if (showNotification) {
			dispatch(showSystemNotification({ message: formatMessage({ defaultMessage: 'Preferences cleared' }) }));
		}
	};
	const onClearEverything = () => {
		preferencesGroups.forEach((group) => onClearPreference(group, false));
		dispatch(showSystemNotification({ message: formatMessage({ defaultMessage: 'Preferences cleared' }) }));
	};
	const onSaveAccessibility = () => {
		if (snackDuration === null) return;
		dispatch(
			showSystemNotification({
				message: formatMessage({ defaultMessage: 'Accessibility settings saved' }),
				options: {
					autoHideDuration: snackDuration
				}
			})
		);
		setStoredSnackbarDuration(user.username, snackDuration);
		setInitialSnackDuration(snackDuration);
		setStoredEnableAnimations(user.username, enableAnimations);
		setInitialEnableAnimations(enableAnimations);
	};
	return _jsxs(Paper, {
		elevation: 0,
		sx: { mb: 2 },
		children: [
			_jsx(GlobalAppToolbar, { title: _jsx(FormattedMessage, { id: 'words.account', defaultMessage: 'Account' }) }),
			_jsxs(Container, {
				maxWidth: 'md',
				sx: {
					mb: 2,
					pb: 2,
					[`& > .${paperClasses.root}`]: {
						padding: '20px',
						margin: '20px 0',
						background: (theme) => theme.palette.background.default,
						'& .mt20': {
							marginTop: '20px'
						}
					}
				},
				children: [
					_jsx(Paper, {
						className: 'mt20',
						children: _jsxs(Box, {
							display: 'flex',
							alignItems: 'center',
							children: [
								_jsxs(Avatar, {
									sx: { marginRight: '30px', width: '90px', height: '90px' },
									children: [user.firstName.charAt(0), user.lastName?.charAt(0) ?? '']
								}),
								_jsxs('section', {
									children: [
										_jsxs(Typography, { children: [user.firstName, ' ', user.lastName] }),
										_jsx(Typography, { children: user.email })
									]
								})
							]
						})
					}),
					_jsxs(Paper, {
						children: [
							_jsx(Typography, {
								variant: 'h5',
								children: _jsx(FormattedMessage, {
									id: 'accountManagement.changeLanguage',
									defaultMessage: 'Change Language'
								})
							}),
							_jsx(Box, {
								marginTop: '16px',
								children: languages
									? _jsx(TextField, {
											fullWidth: true,
											select: true,
											label: _jsx(FormattedMessage, { id: 'words.language', defaultMessage: 'Language' }),
											value: language,
											onChange: (event) => onLanguageChanged(event.target.value),
											children: languages?.map((option) =>
												_jsx(MenuItem, { value: option.id, children: option.label }, option.id)
											)
										})
									: _jsx(Skeleton, { width: '100%', height: '80px' })
							})
						]
					}),
					_jsxs(Paper, {
						children: [
							_jsx(Typography, {
								variant: 'h5',
								children: _jsx(FormattedMessage, {
									id: 'accountManagement.changePassword',
									defaultMessage: 'Change Password'
								})
							}),
							_jsx(FormHelperText, {
								children: _jsx(FormattedMessage, {
									id: 'accountManagement.changeHelperText',
									defaultMessage: "Once your password has been successfully updated, you'll be required to login again."
								})
							}),
							_jsxs(Box, {
								display: 'flex',
								flexDirection: 'column',
								children: [
									_jsx(PasswordTextField, {
										margin: 'normal',
										label: _jsx(FormattedMessage, {
											id: 'accountManagement.currentPassword',
											defaultMessage: 'Current Password'
										}),
										required: true,
										fullWidth: true,
										value: currentPassword,
										onChange: (e) => {
											setCurrentPassword(e.target.value);
										}
									}),
									_jsx(PasswordTextField, {
										margin: 'normal',
										label: _jsx(FormattedMessage, {
											id: 'accountManagement.newPassword',
											defaultMessage: 'New Password'
										}),
										required: true,
										fullWidth: true,
										value: newPassword,
										onChange: (e) => {
											setNewPassword(e.target.value);
										},
										error: Boolean(newPassword) && !validPassword,
										helperText:
											newPassword &&
											!validPassword &&
											_jsx(FormattedMessage, {
												id: 'accountManagement.passwordInvalid',
												defaultMessage: 'Password is invalid.'
											}),
										onFocus: (e) => setAnchorEl(e.target),
										onBlur: () => setAnchorEl(null),
										inputProps: { autoComplete: 'new-password' }
									}),
									_jsx(PasswordTextField, {
										margin: 'normal',
										label: _jsx(FormattedMessage, {
											id: 'accountManagement.confirmPassword',
											defaultMessage: 'Confirm Password'
										}),
										required: true,
										fullWidth: true,
										value: verifiedPassword,
										onChange: (e) => {
											setVerifiedPassword(e.target.value);
										},
										error: newPassword !== verifiedPassword,
										helperText:
											newPassword !== verifiedPassword &&
											_jsx(FormattedMessage, {
												id: 'accountManagement.passwordMatch',
												defaultMessage: 'Must match the previous password.'
											})
									}),
									_jsx(PrimaryButton, {
										disabled: !validPassword || newPassword !== verifiedPassword || currentPassword === '',
										sx: { marginLeft: 'auto' },
										onClick: () => onSave(),
										children: _jsx(FormattedMessage, { id: 'words.save', defaultMessage: 'Save' })
									})
								]
							})
						]
					}),
					_jsxs(Paper, {
						children: [
							_jsx(Typography, {
								variant: 'h5',
								mb: 3,
								children: _jsx(FormattedMessage, { defaultMessage: 'Stored Preferences' })
							}),
							_jsx(Typography, {
								mb: 3,
								variant: 'body2',
								children: _jsx(FormattedMessage, {
									defaultMessage: 'Clear your user preferences and reset to defaults per project or for all projects.'
								})
							}),
							_jsxs(Box, {
								display: 'flex',
								justifyContent: 'space-between',
								mb: 3,
								children: [
									_jsxs(FormControl, {
										sx: { minWidth: 200 },
										children: [
											_jsx(InputLabel, { children: _jsx(FormattedMessage, { defaultMessage: 'Project' }) }),
											_jsxs(Select, {
												value: selectedSite,
												label: _jsx(FormattedMessage, { defaultMessage: 'Project' }),
												onChange: (event) => {
													setSelectedSite(event.target.value);
												},
												children: [
													_jsx(MenuItem, {
														value: 'all',
														children: _jsx(FormattedMessage, { defaultMessage: 'All Projects' })
													}),
													sitesIds.map((siteId) =>
														_jsx(MenuItem, { value: siteId, children: sitesLookup[siteId].name }, siteId)
													)
												]
											})
										]
									}),
									_jsxs(Button, {
										variant: 'outlined',
										color: 'warning',
										size: 'large',
										onClick: onClearEverything,
										children: [
											_jsx(FormattedMessage, { defaultMessage: 'Clear everything' }),
											' ',
											selectedSite === 'all' && _jsx(FormattedMessage, { defaultMessage: '(All Projects)' })
										]
									})
								]
							}),
							_jsx(TableContainer, {
								component: Paper,
								children: _jsx(Table, {
									size: 'small',
									children: _jsx(TableBody, {
										children: preferencesGroups.map((group, index) =>
											_jsxs(
												TableRow,
												{
													sx: { '&:last-child td, &:last-child th': { border: 0 } },
													children: [
														_jsx(TableCell, { component: 'th', scope: 'row', children: group.label }),
														_jsx(TableCell, {
															align: 'right',
															children: _jsx(Button, {
																variant: 'text',
																onClick: () => onClearPreference(group),
																children: _jsx(FormattedMessage, { defaultMessage: 'Clear' })
															})
														})
													]
												},
												index
											)
										)
									})
								})
							})
						]
					}),
					_jsxs(Paper, {
						children: [
							_jsx(Typography, {
								variant: 'h5',
								children: _jsx(FormattedMessage, { defaultMessage: 'Accessibility' })
							}),
							_jsxs(Box, {
								display: 'flex',
								flexDirection: 'column',
								children: [
									_jsxs(FormControl, {
										sx: { mt: 2, mb: 1 },
										children: [
											_jsxs(Box, {
												display: 'flex',
												alignItems: 'center',
												justifyContent: 'space-between',
												mb: 1,
												children: [
													_jsx(InputLabel, {
														htmlFor: 'snackDuration',
														shrink: true,
														sx: { position: 'static', transform: 'none', mb: 0 },
														children: _jsx(FormattedMessage, {
															defaultMessage: 'On-screen notification display time (in seconds)'
														})
													}),
													_jsx(Button, {
														variant: 'text',
														size: 'small',
														disabled: snackDuration === DEFAULT_SNACKBAR_DURATION,
														onClick: () => setSnackDuration(DEFAULT_SNACKBAR_DURATION),
														children: _jsx(FormattedMessage, { defaultMessage: 'Reset to default' })
													})
												]
											}),
											_jsx(NumberField.Root, {
												id: 'snackDuration',
												value: snackDuration / 1000,
												onValueChange: (value) => setSnackDuration(value * 1000),
												min: 0,
												max: 60,
												step: 1,
												format: { maximumFractionDigits: 0 },
												children: _jsxs(NumberField.Group, {
													render: _jsx(Box, { display: 'flex' }),
													children: [
														_jsx(NumberField.Decrement, {
															render: _jsx(Button, { variant: 'outlined', sx: decrementButtonSx }),
															children: _jsx(MinusRounded, {})
														}),
														_jsx(NumberField.Input, { render: _jsx(OutlinedInputWithRef, {}) }),
														_jsx(NumberField.Increment, {
															render: _jsx(Button, { variant: 'outlined', sx: incrementButtonSx }),
															children: _jsx(AddRounded, {})
														})
													]
												})
											}),
											_jsx(FormHelperText, {
												sx: { mt: 1, ml: 0 },
												children: _jsx(FormattedMessage, {
													defaultMessage:
														'How long notifications stay visible at on the screen before closing automatically. These appear when you save, publish, or complete other actions. You can dismiss them anytime using their close button.'
												})
											})
										]
									}),
									_jsx(FormControl, {
										sx: { my: 2 },
										children: _jsx(FormControlLabel, {
											control: _jsx(Checkbox, {
												checked: enableAnimations,
												onChange: (e) => setEnableAnimations(e.target.checked)
											}),
											label: _jsx(FormattedMessage, { defaultMessage: 'Enable animations' })
										})
									}),
									_jsx(PrimaryButton, {
										disabled:
											snackDuration === null ||
											(initialSnackDuration === snackDuration && initialEnableAnimations === enableAnimations),
										sx: { marginLeft: 'auto' },
										onClick: () => onSaveAccessibility(),
										children: _jsx(FormattedMessage, { id: 'words.save', defaultMessage: 'Save' })
									})
								]
							})
						]
					})
				]
			}),
			_jsx(PasswordStrengthDisplayPopper, {
				open: Boolean(anchorEl),
				anchorEl: anchorEl,
				placement: 'top',
				value: newPassword,
				passwordRequirementsMinComplexity: passwordRequirementsMinComplexity,
				onValidStateChanged: setValidPassword
			})
		]
	});
}
export default AccountManagement;
