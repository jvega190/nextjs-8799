/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
import { FormattedMessage } from 'react-intl';
import { SelectionList } from './SelectionList';
import { nnou } from '../../utils/object';
import Box from '@mui/material/Box';
export function DependencySelection(props) {
	const {
		items,
		selectedItems,
		dependencies,
		onItemClicked,
		onSelectAllClicked,
		onSelectAllSoftClicked,
		disabled = false
	} = props;
	return _jsx(_Fragment, {
		children: _jsxs(Box, {
			sx: (theme) => ({
				background: theme.palette.background.paper,
				border: `1px solid ${theme.palette.divider}`,
				minHeight: '374px',
				opacity: disabled ? 0.7 : 1
			}),
			children: [
				_jsx(SelectionList, {
					title: _jsx(FormattedMessage, { id: 'publishDialog.itemsToPublish', defaultMessage: 'Items To Publish' }),
					items: items,
					onItemClicked: onItemClicked,
					onSelectAllClicked: onSelectAllClicked,
					displayItemTitle: true,
					selectedItems: selectedItems,
					disabled: disabled
				}),
				nnou(dependencies) &&
					_jsxs(_Fragment, {
						children: [
							_jsx(SelectionList, {
								title: _jsx(FormattedMessage, { defaultMessage: 'References of mandatory submission' }),
								subtitle: _jsx(FormattedMessage, {
									id: 'publishDialog.submissionMandatory',
									defaultMessage: 'Submission Mandatory'
								}),
								emptyMessage: _jsx(FormattedMessage, { defaultMessage: 'No references of mandatory submission' }),
								paths: dependencies.hardDependencies ?? [],
								displayItemTitle: false,
								disabled: disabled
							}),
							_jsx(SelectionList, {
								title: _jsx(FormattedMessage, { defaultMessage: 'References of optional submission' }),
								subtitle: _jsx(FormattedMessage, {
									id: 'publishDialog.submissionOptional',
									defaultMessage: 'Submission Optional'
								}),
								emptyMessage: _jsx(FormattedMessage, { defaultMessage: 'No references of optional submission' }),
								paths: dependencies.softDependencies ?? [],
								onItemClicked: onItemClicked,
								onSelectAllClicked: onSelectAllSoftClicked,
								displayItemTitle: false,
								selectedItems: selectedItems,
								disabled: disabled
							})
						]
					})
			]
		})
	});
}
export default DependencySelection;
