/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import React from 'react';
import Typography from '@mui/material/Typography';
import LauncherOpenerButton from '../LauncherOpenerButton';
import LogoAndMenuBundleButton from '../LogoAndMenuBundleButton';
import { defineMessages, useIntl } from 'react-intl';
import ViewToolbar from '../ViewToolbar/ViewToolbar';
import { useGlobalAppState } from '../GlobalApp';
import Box from '@mui/material/Box';
import { typographyClasses } from '@mui/material';
const translations = defineMessages({
	toggleSidebar: {
		id: 'globalAppToolbar.toggleSidebar',
		defaultMessage: 'Toggle Sidebar'
	}
});
export const GlobalAppToolbar = React.memo(function (props) {
	const {
		title,
		subtitle,
		leftContent,
		rightContent,
		showHamburgerMenuButton = true,
		showAppsButton = true,
		startContent,
		sxs
	} = props;
	const { formatMessage } = useIntl();
	const [{ openSidebar }, setState] = useGlobalAppState();
	return _jsxs(ViewToolbar, {
		elevation: props.elevation,
		classes: props.classes,
		sxs: {
			appBar: sxs?.appBar,
			toolbar: sxs?.toolbar
		},
		children: [
			showHamburgerMenuButton &&
				Boolean(setState) &&
				_jsx(LogoAndMenuBundleButton, {
					showCrafterIcon: showAppsButton,
					'aria-label': formatMessage(translations.toggleSidebar),
					onClick: () => setState({ openSidebar: !openSidebar })
				}),
			startContent,
			Boolean(title || subtitle) &&
				_jsxs(Box, {
					component: 'section',
					className: props.classes?.headings,
					sx: {
						marginLeft: '10px',
						display: 'flex',
						flexDirection: 'column',
						alignItems: 'flex-start!important',
						overflow: 'hidden',
						[`& .${typographyClasses.root}`]: {
							overflow: 'hidden',
							textOverflow: 'ellipsis',
							whiteSpace: 'nowrap'
						},
						...sxs?.headings
					},
					children: [
						title &&
							_jsx(Typography, {
								variant: 'h5',
								component: 'h1',
								className: props.classes?.ellipsis,
								sx: {
									overflow: 'hidden',
									textOverflow: 'ellipsis',
									whiteSpace: 'nowrap',
									...sxs?.ellipsis
								},
								children: title
							}),
						subtitle &&
							_jsx(Typography, {
								variant: 'body2',
								component: 'h2',
								color: 'textSecondary',
								className: props.classes?.subtitle,
								sx: sxs?.subtitle,
								children: subtitle
							})
					]
				}),
			_jsx(Box, {
				component: 'section',
				className: props.classes?.leftContent,
				sx: {
					marginLeft: '25px',
					display: 'flex',
					alignItems: 'center',
					whiteSpace: 'nowrap',
					...sxs?.leftContent
				},
				children: leftContent
			}),
			_jsx(Box, {
				component: 'section',
				className: props.classes?.rightContent,
				sx: {
					marginLeft: 'auto',
					display: 'flex',
					alignItems: 'center',
					whiteSpace: 'nowrap',
					...sxs?.rightContent
				},
				children: rightContent
			}),
			showAppsButton && _jsx(LauncherOpenerButton, {})
		]
	});
});
export default GlobalAppToolbar;
