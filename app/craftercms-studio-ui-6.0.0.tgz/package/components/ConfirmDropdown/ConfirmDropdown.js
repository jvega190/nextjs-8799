/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import ArrowDown from '@mui/icons-material/ArrowDropDownRounded';
import Button from '@mui/material/Button';
import React, { useMemo } from 'react';
import Menu, { menuClasses } from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import Tooltip from '@mui/material/Tooltip';
import { useIntl } from 'react-intl';
function getStyles(sx) {
	return {
		button: {
			...sx?.button
		},
		menuPaper: {
			maxWidth: '250px',
			...sx?.menuPaper
		},
		helperText: {
			py: 1,
			px: 2,
			...sx?.helperText
		}
	};
}
export function ConfirmDropdown(props) {
	const [anchorEl, setAnchorEl] = React.useState(null);
	const sx = getStyles(props.sx);
	const {
		onConfirm,
		onCancel,
		text,
		cancelText,
		confirmText,
		confirmHelperText,
		disabled = false,
		buttonVariant = 'outlined',
		icon: Icon,
		iconColor,
		iconTooltip,
		size = 'medium',
		buttonProps = {}
	} = props;
	const { formatMessage } = useIntl();
	const handleClose = () => {
		setAnchorEl(null);
	};
	const handleConfirm = () => {
		handleClose();
		onConfirm();
	};
	const handleCancel = () => {
		handleClose();
		onCancel?.();
	};
	// Not memorizing causes the menu to get misplaced upon opening.
	const iconButton = useMemo(
		() =>
			Icon
				? _jsx(IconButton, {
						color: iconColor,
						onClick: (e) => setAnchorEl(e.currentTarget),
						size: size,
						disabled: disabled,
						'aria-label': formatMessage({ defaultMessage: 'Confirm' }),
						children: _jsx(Icon, {})
					})
				: null,
		[Icon, disabled, iconColor, size]
	);
	return _jsxs(_Fragment, {
		children: [
			Icon
				? iconTooltip
					? _jsx(Tooltip, { title: disabled ? '' : iconTooltip, children: iconButton })
					: iconButton
				: _jsx(Button, {
						variant: buttonVariant,
						...buttonProps,
						className: props.classes?.button,
						sx: sx.button,
						onClick: (e) => setAnchorEl(e.currentTarget),
						disabled: disabled,
						endIcon: _jsx(ArrowDown, {}),
						children: text
					}),
			_jsxs(Menu, {
				anchorEl: anchorEl,
				classes: { paper: props.classes?.menuPaper },
				sx: {
					[`& .${menuClasses['paper']}`]: {
						...sx.menuPaper
					}
				},
				open: Boolean(anchorEl),
				onClose: handleClose,
				anchorOrigin: {
					vertical: 'bottom',
					horizontal: 'right'
				},
				transformOrigin: {
					vertical: 'top',
					horizontal: 'right'
				},
				children: [
					confirmHelperText &&
						_jsx(Typography, {
							variant: 'body1',
							sx: sx.helperText,
							className: props.classes?.helperText,
							children: confirmHelperText
						}),
					_jsx(MenuItem, { onClick: handleCancel, children: cancelText }),
					_jsx(MenuItem, { onClick: handleConfirm, children: confirmText })
				]
			})
		]
	});
}
export default ConfirmDropdown;
