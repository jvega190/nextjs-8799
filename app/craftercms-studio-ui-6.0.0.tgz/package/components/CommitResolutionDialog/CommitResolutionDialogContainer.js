/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useState } from 'react';
import DialogHeader from '../DialogHeader/DialogHeader';
import DialogBody from '../DialogBody/DialogBody';
import DialogFooter from '../DialogFooter/DialogFooter';
import { FormattedMessage } from 'react-intl';
import TextField from '@mui/material/TextField';
import { commitResolution } from '../../services/repositories';
import SecondaryButton from '../SecondaryButton';
import PrimaryButton from '../PrimaryButton';
import { isBlank } from '../../utils/string';
import { useActiveSiteId } from '../../hooks/useActiveSiteId';
export function CommitResolutionDialogContainer(props) {
	const { onClose, onCommitRequestSent, setDisableQuickDismiss, onCommitSuccess, onCommitError } = props;
	const siteId = useActiveSiteId();
	const [message, setMessage] = useState('');
	const onChange = (e) => {
		e.persist();
		setMessage(e.target.value);
		setDisableQuickDismiss(Boolean(e.target.value));
	};
	const onSubmit = (e) => {
		e.preventDefault();
		if (!isBlank(message)) {
			onCommitRequestSent?.();
			commitResolution(siteId, message).subscribe({
				next(status) {
					onCommitSuccess?.(status);
				},
				error({ response }) {
					onCommitError?.(response);
				}
			});
		}
	};
	return _jsxs('form', {
		onSubmit: onSubmit,
		children: [
			_jsx(DialogHeader, {
				title: _jsx(FormattedMessage, { id: 'repositories.commitResolution', defaultMessage: 'Commit Resolution' }),
				onCloseButtonClick: onClose
			}),
			_jsx(DialogBody, {
				children: _jsx(TextField, {
					autoFocus: true,
					label: _jsx(FormattedMessage, {
						id: 'repositories.messageLabel',
						defaultMessage: 'Conflict resolution message'
					}),
					multiline: true,
					fullWidth: true,
					rows: 4,
					placeholder: 'Please supply a message for the repository history log.',
					variant: 'outlined',
					value: message,
					onChange: onChange,
					helperText: _jsx(FormattedMessage, {
						id: 'repositories.commitResolutionHelper',
						defaultMessage:
							"After committing this resolution. you should 'push' the changes to remote(s) to sync up the new state that you have just defined."
					})
				})
			}),
			_jsxs(DialogFooter, {
				children: [
					_jsx(SecondaryButton, {
						onClick: onClose,
						children: _jsx(FormattedMessage, { id: 'words.cancel', defaultMessage: 'Cancel' })
					}),
					_jsx(PrimaryButton, {
						type: 'submit',
						disabled: isBlank(message),
						children: _jsx(FormattedMessage, {
							id: 'repositories.commitResolution',
							defaultMessage: 'Commit Resolution'
						})
					})
				]
			})
		]
	});
}
export default CommitResolutionDialogContainer;
