/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useState } from 'react';
import { DialogBody } from '../DialogBody';
import { DialogFooter } from '../DialogFooter';
import SecondaryButton from '../SecondaryButton';
import PrimaryButton from '../PrimaryButton';
import ListItemText from '@mui/material/ListItemText';
import List from '@mui/material/List';
import Paper from '@mui/material/Paper';
import { Divider } from '@mui/material';
import TextFieldWithMax from '../TextFieldWithMax';
import { FormattedMessage, useIntl } from 'react-intl';
import { isBlank } from '../../utils/string';
import { useDispatch } from 'react-redux';
import { cancelPackages } from '../../services/workflow';
import useActiveSiteId from '../../hooks/useActiveSiteId';
import { showSystemNotification } from '../../state/actions/system';
import { pushErrorDialog } from '../../utils/system';
import { useEnhancedDialogContext } from '../EnhancedDialog';
import ListItemButton from '@mui/material/ListItemButton';
import IconButton from '@mui/material/IconButton';
import ChevronRightRoundedIcon from '@mui/icons-material/ChevronRightRounded';
import Tooltip from '@mui/material/Tooltip';
import { pushDialog } from '../../state/actions/dialogStack';
export function BulkCancelPackageDialogContainer(props) {
	const { packages, onSuccess, onClose, isSubmitting } = props;
	const [comment, setComment] = useState();
	const siteId = useActiveSiteId();
	const submitDisabled = isBlank(comment);
	const packageIds = packages?.map((pkg) => pkg.id);
	const dispatch = useDispatch();
	const { formatMessage } = useIntl();
	const { updateSubmittingOrHasPendingChanges } = useEnhancedDialogContext();
	const handleSubmit = () => {
		updateSubmittingOrHasPendingChanges({ isSubmitting: true });
		cancelPackages(siteId, {
			packageIds,
			comment
		}).subscribe({
			next() {
				updateSubmittingOrHasPendingChanges({ isSubmitting: false });
				dispatch(
					showSystemNotification({ message: formatMessage({ defaultMessage: 'Packages cancelled successfully.' }) })
				);
				onSuccess?.();
			},
			error({ response }) {
				updateSubmittingOrHasPendingChanges({ isSubmitting: false });
				dispatch(pushErrorDialog({ props: { error: response.response } }));
			}
		});
	};
	const showPackageDetails = (packageId) => {
		dispatch(
			pushDialog({
				component: 'craftercms.components.PackageDetailsDialog',
				props: { packageId }
			})
		);
	};
	return _jsxs(_Fragment, {
		children: [
			_jsxs(DialogBody, {
				children: [
					_jsx(Paper, {
						sx: { background: (theme) => theme.palette.background.paper },
						children: _jsx(List, {
							sx: { p: 0 },
							children: packages?.map((pkg) =>
								_jsxs(
									ListItemButton,
									{
										onClick: () => showPackageDetails(pkg.id),
										children: [
											_jsx(ListItemText, {
												primary: `${pkg.id} - ${pkg.title}`,
												secondary: pkg.submitterComment,
												secondaryTypographyProps: { noWrap: true, title: pkg.title }
											}),
											_jsx(Tooltip, {
												title: _jsx(FormattedMessage, { defaultMessage: 'View package details' }),
												children: _jsx(IconButton, { children: _jsx(ChevronRightRoundedIcon, {}) })
											})
										]
									},
									pkg.id
								)
							)
						})
					}),
					_jsx(Divider, {}),
					_jsx(TextFieldWithMax, {
						value: comment,
						label: _jsx(FormattedMessage, { defaultMessage: 'Cancellation comment' }),
						fullWidth: true,
						onChange: (e) => setComment(e.target.value),
						multiline: true,
						required: true,
						sx: { mt: 2 }
					})
				]
			}),
			_jsxs(DialogFooter, {
				children: [
					_jsx(SecondaryButton, {
						disabled: isSubmitting,
						onClick: (e) => onClose(e, null),
						children: _jsx(FormattedMessage, { defaultMessage: 'No' })
					}),
					_jsx(PrimaryButton, {
						disabled: submitDisabled,
						loading: isSubmitting,
						onClick: handleSubmit,
						children: _jsx(FormattedMessage, { defaultMessage: 'Yes' })
					})
				]
			})
		]
	});
}
export default BulkCancelPackageDialogContainer;
