/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Button from '@mui/material/Button';
import ChevronLeftRoundedIcon from '@mui/icons-material/ChevronLeftRounded';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import TextSnippetOutlinedIcon from '@mui/icons-material/TextSnippetOutlined';
import CodeOutlinedIcon from '@mui/icons-material/CodeOutlined';
import NavigateNextRoundedIcon from '@mui/icons-material/NavigateNextRounded';
import Tooltip from '@mui/material/Tooltip';
import { FormattedMessage } from 'react-intl';
import NotesRoundedIcon from '@mui/icons-material/NotesRounded';
import { useHotkeys } from 'react-hotkeys-hook';
import CompareArrowsIcon from '@mui/icons-material/CompareArrowsRounded';
import { initialFieldViewState, useVersionsDialogContext } from './VersionsDialogContext';
import { typesViewMap } from '../ViewVersionDialog/ContentFieldView';
import TextView from '../ViewVersionDialog/FieldTypesViews/TextView';
import TextDiffView from './FieldsTypesDiffViews/TextDiffView';
import { typesDiffMap } from './utils';
export function FieldVersionToolbar(props) {
	const {
		field,
		contentTypeFields,
		onSelectField,
		actions,
		showFieldsNavigation = true,
		disableKeyboardNavigation = false,
		isDiff = true,
		justContent
	} = props;
	const fieldType = field.type;
	const [{ fieldsViewState }, contextApiRef] = useVersionsDialogContext();
	const currentFieldIndex = contentTypeFields.findIndex((f) => f.id === field.id);
	const nextField = contentTypeFields[currentFieldIndex + 1] || contentTypeFields[0];
	const previousField = contentTypeFields[currentFieldIndex - 1] || contentTypeFields[contentTypeFields.length - 1];
	const viewState = fieldsViewState[field.id] ?? initialFieldViewState;
	const { compareXml, cleanText, monacoOptions, compareMode, compareModeDisabled } = viewState;
	const showDivider =
		(!compareXml && fieldType === 'repeat') ||
		compareXml ||
		typesDiffMap[fieldType] === TextView ||
		typesDiffMap[fieldType] === TextDiffView ||
		Boolean(actions);
	const isMappedFieldType = isDiff ? Boolean(typesDiffMap[fieldType]) : Boolean(typesViewMap[fieldType]);
	const onSelectNextField = (fieldId) => {
		const index = contentTypeFields.findIndex((f) => f.id === fieldId);
		const nextField = contentTypeFields[index + 1] || contentTypeFields[0];
		onSelectField?.(nextField);
	};
	const onSelectPreviousField = (fieldId) => {
		const index = contentTypeFields.findIndex((f) => f.id === fieldId);
		const previousField = contentTypeFields[index - 1] || contentTypeFields[contentTypeFields.length - 1];
		onSelectField?.(previousField);
	};
	// Keyboard navigation - Left and Up to select previous field, Right and Down to select next field
	useHotkeys('ArrowLeft,ArrowRight,ArrowUp,ArrowDown', (event) => {
		if (disableKeyboardNavigation) {
			return;
		} else {
			switch (event.key) {
				case 'ArrowLeft':
				case 'ArrowUp':
					onSelectPreviousField(field.id);
					break;
				case 'ArrowRight':
				case 'ArrowDown':
					onSelectNextField(field.id);
					break;
			}
		}
	});
	return _jsxs(Box, {
		sx: { display: 'flex', alignItems: 'center', mb: justContent ? 0 : 2 },
		children: [
			showFieldsNavigation &&
				contentTypeFields.length > 1 &&
				_jsx(Button, {
					sx: { mx: 1 },
					startIcon: _jsx(ChevronLeftRoundedIcon, {}),
					onClick: () => onSelectPreviousField(field.id),
					title: previousField.name,
					children: _jsx(Typography, {
						variant: 'subtitle2',
						noWrap: true,
						sx: { maxWidth: 160 },
						children: previousField.name
					})
				}),
			_jsxs(Paper, {
				variant: 'outlined',
				sx: {
					display: 'flex',
					alignItems: 'center',
					justifyContent: 'space-between',
					flexGrow: 1,
					py: 1,
					px: 2,
					...(justContent && {
						background: 'none',
						border: 'none',
						p: 0
					})
				},
				children: [
					_jsx(Box, {
						component: 'span',
						sx: { display: 'inline-flex', alignItems: 'center' },
						children: _jsx(Typography, { sx: { fontWeight: 'bold' }, children: field.name })
					}),
					_jsxs(Box, {
						sx: { display: 'flex', alignItems: 'center', mr: justContent && 1 },
						onClick: (e) => e.stopPropagation(),
						children: [
							actions,
							!compareXml &&
								fieldType === 'repeat' &&
								_jsx(Button, {
									onClick: () =>
										contextApiRef.current.setFieldViewState(field.id, {
											compareMode: !compareMode
										}),
									startIcon: _jsx(CompareArrowsIcon, {}),
									disabled: compareModeDisabled,
									children: _jsx(FormattedMessage, { defaultMessage: 'Compare' })
								}),
							(compareXml || typesDiffMap[fieldType] === TextDiffView || typesViewMap[fieldType] === TextView) &&
								_jsxs(_Fragment, {
									children: [
										isDiff &&
											_jsxs(_Fragment, {
												children: [
													_jsx(Button, {
														onClick: () => {
															contextApiRef.current.setFieldViewEditorOptionsState(field.id, {
																ignoreTrimWhitespace: !monacoOptions.ignoreTrimWhitespace
															});
														},
														children: viewState?.monacoOptions.ignoreTrimWhitespace
															? _jsx(FormattedMessage, { defaultMessage: 'Show whitespace' })
															: _jsx(FormattedMessage, { defaultMessage: 'Hide whitespace' })
													}),
													_jsx(Button, {
														onClick: () => {
															contextApiRef.current.setFieldViewEditorOptionsState(field.id, {
																renderSideBySide: !monacoOptions.renderSideBySide
															});
														},
														children: monacoOptions.renderSideBySide
															? _jsx(FormattedMessage, { defaultMessage: 'Unified view' })
															: _jsx(FormattedMessage, { defaultMessage: 'Split view' })
													})
												]
											}),
										_jsx(Button, {
											onClick: () => {
												contextApiRef.current.setFieldViewEditorOptionsState(field.id, {
													diffWordWrap: monacoOptions.diffWordWrap === 'on' ? 'off' : 'on',
													wordWrap: monacoOptions.wordWrap === 'on' ? 'off' : 'on'
												});
											},
											children:
												(isDiff ? monacoOptions.diffWordWrap : monacoOptions.wordWrap) === 'on'
													? _jsx(FormattedMessage, { defaultMessage: 'No Wrap' })
													: _jsx(FormattedMessage, { defaultMessage: 'Wrap' })
										})
									]
								}),
							showDivider &&
								_jsx(Divider, {
									orientation: 'vertical',
									sx: { display: 'inline-flex', height: '25px', ml: 2, mr: 2 }
								}),
							fieldType === 'html' &&
								_jsx(Tooltip, {
									title: _jsx(FormattedMessage, { defaultMessage: 'Show clean text' }),
									children: _jsx(IconButton, {
										size: 'small',
										onClick: () =>
											contextApiRef.current.setFieldViewState?.(field.id, { cleanText: true, compareXml: false }),
										color: cleanText && !compareXml ? 'primary' : 'default',
										children: _jsx(NotesRoundedIcon, {})
									})
								}),
							isMappedFieldType &&
								_jsxs(_Fragment, {
									children: [
										_jsx(Tooltip, {
											title: _jsx(FormattedMessage, { defaultMessage: 'Compare' }),
											children: _jsx(IconButton, {
												size: 'small',
												onClick: () =>
													contextApiRef.current.setFieldViewState?.(field.id, { cleanText: false, compareXml: false }),
												color: !cleanText && !compareXml ? 'primary' : 'default',
												children: _jsx(TextSnippetOutlinedIcon, {})
											})
										}),
										_jsx(Tooltip, {
											title: _jsx(FormattedMessage, { defaultMessage: 'Compare XML' }),
											children: _jsx(IconButton, {
												size: 'small',
												onClick: () => contextApiRef.current.setFieldViewState?.(field.id, { compareXml: true }),
												color: compareXml ? 'primary' : 'default',
												children: _jsx(CodeOutlinedIcon, {})
											})
										})
									]
								})
						]
					})
				]
			}),
			showFieldsNavigation &&
				contentTypeFields.length > 1 &&
				_jsx(Button, {
					sx: { mx: 1 },
					endIcon: _jsx(NavigateNextRoundedIcon, {}),
					onClick: () => onSelectNextField(field.id),
					title: nextField.name,
					children: _jsx(Typography, {
						variant: 'subtitle2',
						noWrap: true,
						sx: { maxWidth: 160 },
						children: nextField.name
					})
				})
		]
	});
}
export default FieldVersionToolbar;
