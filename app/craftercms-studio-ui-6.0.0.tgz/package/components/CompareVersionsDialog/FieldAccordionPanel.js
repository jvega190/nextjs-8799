/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useEffect, useState } from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary, { accordionSummaryClasses } from '@mui/material/AccordionSummary';
import ExpandMoreIcon from '@mui/icons-material/ExpandMoreRounded';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import AccordionDetails from '@mui/material/AccordionDetails';
export function FieldAccordionPanel(props) {
	const { fieldRef, selected, summary, details } = props;
	const [expanded, setExpanded] = useState(true);
	useEffect(() => {
		if (selected) {
			setExpanded(true);
		}
	}, [selected]);
	return _jsxs(Accordion, {
		ref: fieldRef,
		expanded: expanded,
		onChange: () => setExpanded(!expanded),
		slotProps: { transition: { mountOnEnter: true } },
		sx: {
			margin: 0,
			border: 0,
			boxShadow: 'none',
			background: 'none',
			'&.Mui-expanded': {
				margin: 0,
				borderBottom: (theme) => `1px solid ${theme.palette.divider}`
			}
		},
		children: [
			_jsx(AccordionSummary, {
				expandIcon: _jsx(ExpandMoreIcon, {}),
				sx: { [`.${accordionSummaryClasses.content}`]: { justifyContent: 'space-between', alignItems: 'center' } },
				children: summary
					? _jsx(Box, { width: '100%', children: summary })
					: _jsxs(Typography, {
							children: [
								_jsxs(Box, { component: 'span', sx: { fontWeight: 600 }, children: [props.field.name, ' '] }),
								'(',
								props.field.id,
								')'
							]
						})
			}),
			_jsx(AccordionDetails, { sx: { py: 2 }, children: details })
		]
	});
}
