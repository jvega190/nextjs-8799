/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
export function DiffViewLayout(props) {
	const {
		aXml,
		bXml,
		field,
		renderContent,
		noContent = _jsx(Box, { children: _jsx(Typography, { color: 'textSecondary', children: 'no content set' }) })
	} = props;
	const verticalLayout = field.type === 'image' || field.type === 'video-picker';
	return _jsxs(Box, {
		sx: {
			display: 'flex',
			height: '100%',
			alignItems: verticalLayout ? 'center' : 'flex-start',
			justifyContent: 'space-around',
			flexDirection: verticalLayout ? 'column' : 'row',
			'> div': {
				flexGrow: verticalLayout && 1
			}
		},
		children: [
			aXml ? renderContent(aXml) : noContent,
			verticalLayout && _jsx(Divider, { sx: { width: '100%', mt: 1, mb: 1 } }),
			bXml ? renderContent(bXml) : noContent
		]
	});
}
export default DiffViewLayout;
