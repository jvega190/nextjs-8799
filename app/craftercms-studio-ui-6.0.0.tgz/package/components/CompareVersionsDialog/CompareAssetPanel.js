/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useMemo } from 'react';
import { isImage } from '../PathNavigator/utils';
import TextDiffView from './FieldsTypesDiffViews/TextDiffView';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import ImageView from '../ViewVersionDialog/FieldTypesViews/ImageView';
import VideoView from '../ViewVersionDialog/FieldTypesViews/VideoView';
import { PDFView } from '../ViewVersionDialog/AssetTypesViews/PDFView';
import { FormattedMessage } from 'react-intl';
import { isPdfDocument, isVideo } from '../../utils/content';
const typesDiffMap = {
	image: ImageView,
	video: VideoView,
	text: TextDiffView,
	pdf: PDFView
};
function AssetDiffView(props) {
	const {
		aContent,
		bContent,
		type,
		renderContent,
		noContent = _jsx(Box, {
			children: _jsx(Typography, {
				color: 'textSecondary',
				children: _jsx(FormattedMessage, { defaultMessage: 'No content set' })
			})
		})
	} = props;
	const verticalLayout = type === 'image' || type === 'video';
	return _jsxs(Box, {
		sx: {
			display: 'flex',
			height: '100%',
			p: 2,
			alignItems: verticalLayout ? 'center' : 'flex-start',
			justifyContent: 'space-around',
			flexDirection: verticalLayout ? 'column' : 'row',
			'> div': {
				flexGrow: verticalLayout && 1
			}
		},
		children: [
			aContent ? renderContent(aContent) : noContent,
			verticalLayout && _jsx(Divider, { sx: { width: '100%', mt: 1, mb: 1 } }),
			bContent ? renderContent(bContent) : noContent
		]
	});
}
export function CompareAssetPanel(props) {
	const { a, b, item } = props;
	const assetType = useMemo(() => {
		if (isImage(item)) {
			return 'image';
		} else if (isVideo(item)) {
			return 'video';
		} else if (isPdfDocument(item.mimeType)) {
			return 'pdf';
		} else {
			return 'text';
		}
	}, [item]);
	const ViewComponent = typesDiffMap[assetType];
	const isVerticalLayout = assetType === 'image' || assetType === 'video';
	const viewComponentProps = {
		...(isVerticalLayout ? { sxs: { image: { maxHeight: '100%' } } } : {})
	};
	if (assetType === 'text') {
		return _jsx(TextDiffView, { aXml: a, bXml: b });
	} else {
		return _jsx(AssetDiffView, {
			aContent: a,
			bContent: b,
			type: assetType,
			renderContent: (content) =>
				_jsx(Box, {
					sx: { height: isVerticalLayout ? 'calc(50% - 9px)' : '100%', width: '50%', textAlign: 'center' },
					children: _jsx(ViewComponent, { content: content, ...viewComponentProps })
				})
		});
	}
}
export default CompareAssetPanel;
