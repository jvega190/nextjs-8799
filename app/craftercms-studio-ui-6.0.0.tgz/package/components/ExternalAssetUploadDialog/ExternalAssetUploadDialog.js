/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2026 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { EnhancedDialog, useEnhancedDialogContext } from '../EnhancedDialog';
import { FormattedMessage } from 'react-intl';
import { useCallback } from 'react';
import { DialogBody } from '../DialogBody';
import useActiveSiteId from '../../hooks/useActiveSiteId';
import { SingleFileUpload } from '../SingleFileUpload';
import useEnv from '../../hooks/useEnv';
import { s3UploadUri, webDAVUploadUri } from '../../utils/constants';
function ExternalAssetUploadDialogBody(props) {
	const {
		path,
		profileId,
		profileType = 'aws',
		fileTypes,
		onUploadStart,
		onUploadComplete,
		onUploadError,
		onFileAdded
	} = props;
	const { updateSubmittingOrHasPendingChanges } = useEnhancedDialogContext();
	const siteId = useActiveSiteId();
	const { authoringBase } = useEnv();
	const url = `${authoringBase}${profileType === 'aws' ? s3UploadUri : webDAVUploadUri}`;
	const onStart = useCallback(() => {
		onUploadStart?.();
		updateSubmittingOrHasPendingChanges({ isSubmitting: true });
	}, [onUploadStart, updateSubmittingOrHasPendingChanges]);
	const onError = useCallback(
		({ file, error, response }) => {
			updateSubmittingOrHasPendingChanges({ isSubmitting: false });
			onUploadError?.({ file, error, response });
		},
		[onUploadError, updateSubmittingOrHasPendingChanges]
	);
	const onComplete = useCallback(
		(result) => {
			updateSubmittingOrHasPendingChanges({ isSubmitting: false });
			onUploadComplete?.(result);
		},
		[onUploadComplete, updateSubmittingOrHasPendingChanges]
	);
	return _jsx(_Fragment, {
		children: _jsx(DialogBody, {
			sx: { p: 4 },
			children: _jsxs('form', {
				id: 'asset_upload_form',
				children: [
					_jsx('input', { type: 'hidden', name: 'siteId', value: siteId }),
					_jsx('input', { type: 'hidden', name: 'profileId', value: profileId }),
					_jsx('input', { type: 'hidden', name: 'path', value: path }),
					_jsx(SingleFileUpload, {
						site: siteId,
						path: path,
						url: url,
						method: 'POST',
						fileTypes: fileTypes,
						onUploadStart: onStart,
						onComplete: onComplete,
						onError: onError,
						onFileAdded: onFileAdded
					})
				]
			})
		})
	});
}
export function ExternalAssetUploadDialog(props) {
	const {
		path,
		profileId,
		profileType,
		fileTypes,
		onClose,
		onUploadStart,
		onUploadComplete,
		onUploadError,
		onFileAdded,
		...rest
	} = props;
	return _jsx(EnhancedDialog, {
		title: _jsx(FormattedMessage, { id: 'words.upload', defaultMessage: 'Upload' }),
		maxWidth: 'xs',
		onClose: onClose,
		...rest,
		children: _jsx(ExternalAssetUploadDialogBody, {
			path: path,
			profileId: profileId,
			profileType: profileType,
			fileTypes: fileTypes,
			onClose: onClose,
			onUploadStart: onUploadStart,
			onUploadComplete: onUploadComplete,
			onUploadError: onUploadError,
			onFileAdded: onFileAdded
		})
	});
}
export default ExternalAssetUploadDialog;
