/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Typography from '@mui/material/Typography';
import { FormattedMessage } from 'react-intl';
import ErrorOutlineOutlinedIcon from '@mui/icons-material/ErrorOutlineOutlined';
import { rand } from '../PathNavigator/utils';
import Skeleton from '@mui/material/Skeleton';
import { SystemIcon } from '../SystemIcon';
import Box from '@mui/material/Box';
export function ContextMenu(props) {
	const {
		options,
		classes: propClasses,
		sxs,
		onMenuItemClicked,
		emptyState,
		isLoading = false,
		numOfLoaderItems = 5,
		...menuProps
	} = props;
	return _jsx(Menu, {
		...menuProps,
		classes: propClasses,
		children: isLoading
			? _jsx(Box, {
					className: propClasses?.loadingRoot,
					sx: {
						width: '135px',
						padding: '0 15px',
						...sxs?.loadingRoot
					},
					children: new Array(numOfLoaderItems)
						.fill(null)
						.map((value, i) =>
							_jsx(
								Typography,
								{
									variant: 'body2',
									style: { width: `${rand(85, 100)}%`, padding: '6px 0' },
									children: _jsx(Skeleton, { animation: 'wave', width: '100%' })
								},
								i
							)
						)
				})
			: options.flatMap((i) => i).length === 0
				? _jsxs(Box, {
						className: propClasses?.emptyRoot,
						sx: {
							display: 'block',
							padding: '10px',
							textAlign: 'center',
							...sxs?.emptyRoot
						},
						children: [
							_jsx(ErrorOutlineOutlinedIcon, { fontSize: 'small' }),
							_jsx(Typography, {
								variant: 'caption',
								display: 'block',
								children:
									emptyState?.message ||
									_jsx(FormattedMessage, {
										id: 'contextMenu.emptyOptionsMessage',
										defaultMessage: 'No options available to display.'
									})
							})
						]
					})
				: options.map((section, i) =>
						section.map((option, y) =>
							_jsxs(
								MenuItem,
								{
									dense: true,
									divider: i !== options.length - 1 && y === section.length - 1,
									onClick: (e) => onMenuItemClicked(option.id, e),
									className: propClasses?.menuItem,
									sx: sxs?.menuItem,
									children: [
										_jsx(Typography, { variant: 'body2', children: option.label }),
										option.icon && _jsx(SystemIcon, { icon: option.icon, sx: { ml: 1 } })
									]
								},
								option.id
							)
						)
					)
	});
}
export default ContextMenu;
