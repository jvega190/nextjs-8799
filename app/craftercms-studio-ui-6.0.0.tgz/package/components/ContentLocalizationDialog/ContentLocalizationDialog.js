/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useState } from 'react';
import Dialog from '@mui/material/Dialog';
import { defineMessages, FormattedMessage, useIntl } from 'react-intl';
import Typography from '@mui/material/Typography';
import Checkbox from '@mui/material/Checkbox';
import IconButton from '@mui/material/IconButton';
import MoreVertIcon from '@mui/icons-material/MoreVertRounded';
import ContextMenu from '../ContextMenu';
import { markForTranslation } from '../../services/translation';
import { useDispatch } from 'react-redux';
import palette from '../../styles/palette';
import DialogBody from '../DialogBody/DialogBody';
import DialogHeader from '../DialogHeader';
import SingleItemSelector from '../SingleItemSelector';
import ActionsBar from '../ActionsBar';
import { useActiveSiteId } from '../../hooks/useActiveSiteId';
import { useUnmount } from '../../hooks/useUnmount';
import Box from '@mui/material/Box';
import { pushErrorDialog } from '../../utils/system';
const translations = defineMessages({
	mark: {
		id: 'contentLocalization.mark',
		defaultMessage: 'Mark for translation'
	},
	approveTranslation: {
		id: 'contentLocalization.approve',
		defaultMessage: 'Approve translation'
	},
	deleteTranslation: {
		id: 'contentLocalization.delete',
		defaultMessage: 'Delete translation'
	},
	locales: {
		id: 'words.locales',
		defaultMessage: 'Locales'
	},
	status: {
		id: 'words.status',
		defaultMessage: 'Status'
	},
	edit: {
		id: 'words.edit',
		defaultMessage: 'Edit'
	},
	schedule: {
		id: 'words.schedule',
		defaultMessage: 'Schedule'
	},
	delete: {
		id: 'words.delete',
		defaultMessage: 'Delete'
	},
	approve: {
		id: 'words.approve',
		defaultMessage: 'Approve'
	},
	review: {
		id: 'words.review',
		defaultMessage: 'Review'
	}
});
const localizationMap = {
	en: 'English, US (en)',
	en_gb: 'English, UK (en_gb)',
	es: 'Spanish, Spain (es)',
	fr: 'French (fr)',
	de: 'German (de)'
};
const menuSections = [
	{
		id: 'edit',
		label: translations.edit
	},
	{
		id: 'review',
		label: translations.review
	},
	{
		id: 'mark',
		label: translations.mark
	},
	{
		id: 'approve',
		label: translations.approve
	},
	{
		id: 'delete',
		label: translations.delete
	}
];
const menuOptions = [
	{
		id: 'edit',
		label: translations.edit
	},
	{
		id: 'schedule',
		label: translations.schedule
	},
	{
		id: 'delete',
		label: translations.delete
	},
	{
		id: 'approve',
		label: translations.approve
	}
];
export function ContentLocalizationDialog(props) {
	const { open, onClose } = props;
	return _jsx(Dialog, {
		open: open,
		onClose: onClose,
		fullWidth: true,
		children: _jsx(ContentLocalizationDialogUI, { ...props })
	});
}
function ContentLocalizationDialogUI(props) {
	const { formatMessage } = useIntl();
	const dispatch = useDispatch();
	const { onClose, locales, item, rootPath, onItemChange } = props;
	const [selected, setSelected] = useState([]);
	const [openSelector, setOpenSelector] = useState(false);
	const site = useActiveSiteId();
	const [menu, setMenu] = useState({
		activeItem: null,
		anchorEl: null
	});
	const onOpenCustomMenu = (locale, anchorEl) => {
		setMenu({
			activeItem: locale,
			anchorEl
		});
	};
	const onCloseCustomMenu = () => {
		setMenu({
			activeItem: null,
			anchorEl: null
		});
	};
	const onMenuItemClicked = (option) => {
		switch (option) {
			case 'mark': {
				markForTranslation(site, menu.activeItem.path, menu.activeItem.localeCode).subscribe(
					() => {
						setMenu({
							activeItem: null,
							anchorEl: null
						});
					},
					({ response }) => {
						dispatch(pushErrorDialog({ props: { error: response } }));
					}
				);
				break;
			}
			default:
				break;
		}
	};
	const handleSelect = (checked, id) => {
		const _selected = [...selected];
		if (checked) {
			if (!_selected.includes(id)) {
				_selected.push(id);
			}
		} else {
			let index = _selected.indexOf(id);
			if (index >= 0) {
				_selected.splice(index, 1);
			}
		}
		setSelected(_selected);
	};
	const toggleSelectAll = () => {
		if (locales.length === selected.length) {
			setSelected([]);
		} else {
			setSelected(locales.map((locale) => locale.id));
		}
	};
	const onOptionClicked = (option) => {
		// TODO: Widget menu option clicked
	};
	useUnmount(props.onClosed);
	return _jsxs(_Fragment, {
		children: [
			_jsx(DialogHeader, {
				title: _jsx(FormattedMessage, { id: 'contentLocalization.title', defaultMessage: 'Content Localization' }),
				onCloseButtonClick: onClose
			}),
			_jsxs(DialogBody, {
				children: [
					_jsx(SingleItemSelector, {
						label: _jsx(FormattedMessage, { id: 'words.item', defaultMessage: 'Item' }),
						sxs: { root: { marginBottom: '10px' } },
						open: openSelector,
						onClose: () => setOpenSelector(false),
						onDropdownClick: () => setOpenSelector(!openSelector),
						rootPath: rootPath,
						selectedItem: item,
						onItemClicked: (item) => {
							onItemChange(item);
							setOpenSelector(false);
						}
					}),
					_jsxs(Box, {
						component: 'section',
						sx: {
							background: palette.white,
							border: '1px solid rgba(0, 0, 0, .125)',
							minHeight: '30vh',
							'& header': {
								marginBottom: '5px'
							}
						},
						children: [
							selected.length > 0
								? _jsx(ActionsBar, {
										isIndeterminate: selected.length > 0 && selected.length < locales.length,
										onOptionClicked: onOptionClicked,
										options: menuOptions,
										isChecked: selected.length === locales.length,
										onCheckboxChange: toggleSelectAll
									})
								: _jsxs(Box, {
										component: 'header',
										sx: { display: 'flex', alignItems: 'center' },
										children: [
											_jsx(Checkbox, {
												color: 'primary',
												sx: { color: (theme) => theme.palette.primary.main },
												onChange: toggleSelectAll
											}),
											_jsxs(_Fragment, {
												children: [
													_jsx(Typography, {
														variant: 'subtitle2',
														sx: { fontWeight: 'bold', paddingRight: '20px', width: '30%' },
														children: formatMessage(translations.locales)
													}),
													_jsx(Typography, {
														variant: 'subtitle2',
														sx: { fontWeight: 'bold', paddingRight: '20px' },
														children: formatMessage(translations.status)
													})
												]
											})
										]
									}),
							locales?.map((locale) =>
								_jsxs(
									Box,
									{
										sx: { display: 'flex', alignItems: 'center' },
										children: [
											_jsx(Checkbox, {
												color: 'primary',
												sx: { color: (theme) => theme.palette.primary.main },
												checked: selected?.includes(locale.id),
												onChange: (event) => handleSelect(event.currentTarget.checked, locale.id)
											}),
											_jsx(Typography, {
												variant: 'subtitle2',
												sx: { paddingRight: '20px', width: '30%' },
												children: localizationMap[locale.localeCode]
											}),
											_jsx(Typography, { variant: 'subtitle2', sx: { paddingRight: '20px' }, children: locale.status }),
											_jsx(IconButton, {
												'aria-label': 'options',
												sx: { marginLeft: 'auto', padding: '9px' },
												onClick: (e) => onOpenCustomMenu(locale, e.currentTarget),
												size: 'large',
												children: _jsx(MoreVertIcon, {})
											})
										]
									},
									locale.id
								)
							)
						]
					})
				]
			}),
			_jsx(ContextMenu, {
				anchorEl: menu.anchorEl,
				open: Boolean(menu.anchorEl),
				sx: { width: '182px' },
				onClose: onCloseCustomMenu,
				options: [menuSections],
				onMenuItemClicked: onMenuItemClicked
			})
		]
	});
}
export default ContentLocalizationDialog;
