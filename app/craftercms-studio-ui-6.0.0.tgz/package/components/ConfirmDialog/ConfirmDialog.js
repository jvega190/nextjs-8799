/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
import { AlertDialog } from '../AlertDialog';
import PrimaryButton from '../PrimaryButton';
import { useIntl } from 'react-intl';
import SecondaryButton from '../SecondaryButton';
import translations from './translations';
export function ConfirmDialog(props) {
	const { onOk, onCancel, disableOkButton, disableCancelButton, okButtonText, cancelButtonText, ...rest } = props;
	const { formatMessage } = useIntl();
	return _jsx(
		AlertDialog,
		// The backdrop or escape should trigger the onCancel (this action is likely the one that won't cause data
		// loss or undesired changes). If this action is not provided, then disable backdrop and escape close.
		{
			// The backdrop or escape should trigger the onCancel (this action is likely the one that won't cause data
			// loss or undesired changes). If this action is not provided, then disable backdrop and escape close.
			disableBackdropClick: !onCancel,
			disableEscapeKeyDown: !onCancel,
			...rest,
			buttons: _jsxs(_Fragment, {
				children: [
					onOk &&
						_jsx(PrimaryButton, {
							onClick: onOk,
							autoFocus: true,
							fullWidth: true,
							size: 'large',
							disabled: disableOkButton,
							children: okButtonText ?? formatMessage(translations.accept)
						}),
					onCancel &&
						_jsx(SecondaryButton, {
							onClick: onCancel,
							fullWidth: true,
							size: 'large',
							disabled: disableCancelButton,
							children: cancelButtonText ?? formatMessage(translations.cancel)
						})
				]
			})
		}
	);
}
export default ConfirmDialog;
