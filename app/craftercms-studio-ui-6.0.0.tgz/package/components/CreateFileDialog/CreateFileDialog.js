/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
import { CreateFileDialogContainer } from './CreateFileDialogContainer';
import EnhancedDialog from '../EnhancedDialog/EnhancedDialog';
import { FormattedMessage } from 'react-intl';
export function CreateFileDialog(props) {
	const { type, path, allowBraces, onCreated, ...rest } = props;
	return _jsx(EnhancedDialog, {
		title:
			type === 'controller'
				? _jsx(FormattedMessage, { id: 'createFileDialog.controller', defaultMessage: 'New Controller' })
				: _jsx(FormattedMessage, { id: 'createFileDialog.template', defaultMessage: 'New Template' }),
		maxWidth: 'xs',
		...rest,
		children: _jsx(CreateFileDialogContainer, {
			path: path,
			onCreated: onCreated,
			type: type,
			allowBraces: allowBraces
		})
	});
}
export default CreateFileDialog;
