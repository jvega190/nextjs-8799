/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import RadioGroup from '@mui/material/RadioGroup';
import { defineMessages, useIntl } from 'react-intl';
import FormControl from '@mui/material/FormControl';
import FormControlLabel from '@mui/material/FormControlLabel';
import Radio from '@mui/material/Radio';
import { capitalize } from '@mui/material';
import Typography from '@mui/material/Typography';
const messages = defineMessages({
	content: {
		id: 'words.content',
		defaultMessage: 'Content'
	},
	assets: {
		id: 'words.assets',
		defaultMessage: 'Assets'
	},
	templates: {
		id: 'words.templates',
		defaultMessage: 'Templates'
	},
	scripts: {
		id: 'words.scripts',
		defaultMessage: 'Scripts'
	}
});
const defaultBasePaths = [
	{
		id: 'content',
		path: '/site'
	},
	{
		id: 'assets',
		path: '/static-assets'
	},
	{
		id: 'templates',
		path: '/templates'
	},
	{
		id: 'scripts',
		path: '/scripts'
	}
];
export function BasePathSelector(props) {
	const { basePaths = defaultBasePaths, value = '', onChange, sx } = props;
	const { formatMessage } = useIntl();
	return _jsx(FormControl, {
		sx: sx,
		children: _jsx(RadioGroup, {
			value: value,
			onChange: onChange,
			children: basePaths.map((basePath) =>
				_jsx(
					FormControlLabel,
					{
						value: basePath.path,
						control: _jsx(Radio, { size: 'small' }),
						label: _jsxs(_Fragment, {
							children: [
								basePath.label ??
									(messages[basePath.id] ? formatMessage(messages[basePath.id]) : capitalize(basePath.id)),
								':',
								' ',
								_jsx(Typography, {
									color: 'text.secondary',
									variant: 'body2',
									component: 'span',
									children: basePath.path
								})
							]
						})
					},
					basePath.path
				)
			)
		})
	});
}
export default BasePathSelector;
