/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsxs as _jsxs, jsx as _jsx, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { defineMessages, FormattedMessage, useIntl } from 'react-intl';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import PasswordRoundedIcon from '@mui/icons-material/VpnKeyRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import Divider from '@mui/material/Divider';
import DialogBody from '../DialogBody/DialogBody';
import Switch from '@mui/material/Switch';
import Chip from '@mui/material/Chip';
import SecondaryButton from '../SecondaryButton';
import PrimaryButton from '../PrimaryButton';
import Grid from '@mui/material/Grid';
import Skeleton from '@mui/material/Skeleton';
import { rand } from '../PathNavigator/utils';
import ResetPasswordDialog from '../ResetPasswordDialog';
import InputLabel from '@mui/material/InputLabel';
import { UserGroupMembershipEditor } from '../UserGroupMembershipEditor';
import TextField from '@mui/material/TextField';
import {
	isInvalidEmail,
	USER_EMAIL_MAX_LENGTH,
	USER_FIRST_NAME_MAX_LENGTH,
	USER_FIRST_NAME_MIN_LENGTH,
	USER_LAST_NAME_MAX_LENGTH,
	USER_LAST_NAME_MIN_LENGTH,
	validateFieldMinLength,
	validateRequiredField
} from '../UserManagement/utils';
import Box from '@mui/material/Box';
const translations = defineMessages({
	externallyManaged: {
		id: 'userInfoDialog.externallyManaged',
		defaultMessage: 'Managed externally'
	},
	siteName: {
		id: 'userInfoDialog.siteName',
		defaultMessage: 'Project name'
	},
	roles: {
		id: 'words.roles',
		defaultMessage: 'Roles'
	},
	invalidMinLength: {
		id: 'userInfoDialog.invalidMinLength',
		defaultMessage: 'Min {length} characters'
	}
});
export function EditUserDialogUI(props) {
	const { formatMessage } = useIntl();
	const managedInStudio = !props.user.externallyManaged;
	const {
		user,
		inProgress,
		submitOk,
		dirty,
		openResetPassword,
		sites,
		rolesBySite,
		passwordRequirementsMinComplexity,
		onSave,
		onCloseButtonClick,
		onCloseResetPasswordDialog,
		onInputChange,
		onEnableChange,
		onCancelForm,
		onResetPassword
	} = props;
	return _jsxs(_Fragment, {
		children: [
			_jsxs(Box, {
				component: 'header',
				sx: { padding: '30px 40px', display: 'flex', alignItems: 'center' },
				children: [
					_jsxs(Avatar, {
						sx: { marginRight: '30px', width: '90px', height: '90px' },
						children: [user.firstName.charAt(0), user.lastName?.charAt(0) ?? '']
					}),
					_jsxs(Box, {
						component: 'section',
						sx: { maxWidth: '70%' },
						children: [
							_jsxs(Typography, { variant: 'h6', component: 'h2', children: [user.firstName, ' ', user.lastName] }),
							_jsx(Typography, { variant: 'subtitle1', noWrap: true, title: user.username, children: user.username })
						]
					}),
					_jsxs(Box, {
						component: 'section',
						sx: { marginLeft: 'auto' },
						children: [
							managedInStudio
								? _jsx(_Fragment, {
										children: _jsx(Tooltip, {
											title: _jsx(FormattedMessage, {
												id: 'userInfoDialog.resetPassword',
												defaultMessage: 'Reset password'
											}),
											children: _jsx(IconButton, {
												onClick: () => onResetPassword(true),
												size: 'large',
												'aria-label': formatMessage({
													id: 'userInfoDialog.resetPassword',
													defaultMessage: 'Reset password'
												}),
												children: _jsx(PasswordRoundedIcon, {})
											})
										})
									})
								: _jsx(Chip, {
										label: formatMessage(translations.externallyManaged),
										size: 'small',
										sx: (theme) => ({
											background: theme.palette.info.main,
											color: theme.palette.text.primary,
											marginLeft: 'auto'
										})
									}),
							_jsx(Tooltip, {
								title: _jsx(FormattedMessage, { id: 'userInfoDialog.close', defaultMessage: 'Close' }),
								children: _jsx(IconButton, {
									edge: 'end',
									onClick: onCloseButtonClick,
									size: 'large',
									'aria-label': formatMessage({ id: 'userInfoDialog.close', defaultMessage: 'Close' }),
									children: _jsx(CloseRoundedIcon, {})
								})
							})
						]
					})
				]
			}),
			_jsx(Divider, {}),
			_jsxs(DialogBody, {
				sx: { padding: 0 },
				children: [
					_jsxs(Grid, {
						container: true,
						children: [
							_jsx(Grid, {
								size: { sm: 6 },
								children: _jsxs(Box, {
									component: 'section',
									sx: { padding: '30px 40px' },
									children: [
										_jsx(Typography, {
											variant: 'subtitle1',
											sx: { textTransform: 'uppercase', marginBottom: '10px' },
											children: _jsx(FormattedMessage, {
												id: 'userInfoDialog.userDetails',
												defaultMessage: 'User Details'
											})
										}),
										_jsxs(Box, {
											component: 'form',
											sx: {
												'& > .row': {
													display: 'flex',
													padding: '10px 0',
													alignItems: 'center',
													'& .section-label': {
														flexBasis: '180px',
														'& + .MuiInputBase-root': {
															marginTop: '0 !important'
														}
													},
													'& .username': {
														width: '100%',
														display: 'flex',
														alignItems: 'center',
														overflow: 'hidden'
													}
												}
											},
											children: [
												_jsxs('div', {
													className: 'row',
													children: [
														_jsx(Typography, {
															color: 'textSecondary',
															className: 'section-label',
															children: _jsx(FormattedMessage, { id: 'words.enabled', defaultMessage: 'Enabled' })
														}),
														_jsx(Box, {
															sx: { width: '100%', marginLeft: '-12px' },
															children: _jsx(Switch, {
																disabled: !managedInStudio,
																checked: user.enabled,
																onChange: (e) => onEnableChange({ enabled: e.target.checked }),
																color: 'primary',
																name: 'enabled',
																inputProps: { 'aria-label': 'enabled checkbox' }
															})
														})
													]
												}),
												_jsx(Divider, {}),
												_jsxs('div', {
													className: 'row',
													children: [
														_jsx(Typography, {
															color: 'textSecondary',
															className: 'section-label',
															children: _jsx(FormattedMessage, { id: 'words.username', defaultMessage: 'Username' })
														}),
														_jsx(Box, {
															component: 'section',
															className: 'username',
															children: _jsx(Typography, {
																noWrap: true,
																title: user.username,
																children: user.username
															})
														})
													]
												}),
												_jsxs('div', {
													className: 'row',
													children: [
														_jsx(InputLabel, {
															htmlFor: 'firstName',
															className: 'section-label',
															children: _jsx(Typography, {
																color: 'textSecondary',
																children: _jsx(FormattedMessage, {
																	id: 'words.firstName',
																	defaultMessage: 'First name'
																})
															})
														}),
														managedInStudio
															? _jsx(TextField, {
																	id: 'firstName',
																	onChange: (e) => onInputChange({ firstName: e.currentTarget.value }),
																	slotProps: {
																		htmlInput: { maxLength: USER_FIRST_NAME_MAX_LENGTH }
																	},
																	value: user.firstName,
																	fullWidth: true,
																	error:
																		validateRequiredField(user.firstName) ||
																		validateFieldMinLength('firstName', user.firstName),
																	helperText: validateRequiredField(user.firstName)
																		? _jsx(FormattedMessage, {
																				id: 'editUserDialog.firstNameRequired',
																				defaultMessage: 'First Name is required'
																			})
																		: validateFieldMinLength('firstName', user.firstName)
																			? formatMessage(translations.invalidMinLength, {
																					length: USER_FIRST_NAME_MIN_LENGTH
																				})
																			: null
																})
															: _jsx(Typography, { className: 'username', children: user.firstName })
													]
												}),
												_jsxs('div', {
													className: 'row',
													children: [
														_jsx(InputLabel, {
															htmlFor: 'lastName',
															className: 'section-label',
															children: _jsx(Typography, {
																color: 'textSecondary',
																children: _jsx(FormattedMessage, { id: 'words.lastName', defaultMessage: 'Last name' })
															})
														}),
														managedInStudio
															? _jsx(TextField, {
																	id: 'lastName',
																	onChange: (e) => onInputChange({ lastName: e.currentTarget.value }),
																	slotProps: {
																		htmlInput: { maxLength: USER_LAST_NAME_MAX_LENGTH }
																	},
																	value: user.lastName,
																	fullWidth: true,
																	error:
																		validateRequiredField(user.lastName) ||
																		validateFieldMinLength('lastName', user.lastName),
																	helperText: validateRequiredField(user.lastName)
																		? _jsx(FormattedMessage, {
																				id: 'editUserDialog.lastNameRequired',
																				defaultMessage: 'Last Name is required'
																			})
																		: validateFieldMinLength('lastName', user.lastName)
																			? formatMessage(translations.invalidMinLength, {
																					length: USER_LAST_NAME_MIN_LENGTH
																				})
																			: null
																})
															: _jsx(Typography, { className: 'username', children: user.lastName })
													]
												}),
												_jsxs('div', {
													className: 'row',
													children: [
														_jsx(InputLabel, {
															htmlFor: 'email',
															className: 'section-label',
															children: _jsx(Typography, {
																color: 'textSecondary',
																children: _jsx(FormattedMessage, { id: 'words.email', defaultMessage: 'E-mail' })
															})
														}),
														managedInStudio
															? _jsx(TextField, {
																	id: 'email',
																	onChange: (e) => onInputChange({ email: e.currentTarget.value }),
																	value: user.email,
																	error: validateRequiredField(user.email) || isInvalidEmail(user.email),
																	fullWidth: true,
																	helperText: validateRequiredField(user.email)
																		? _jsx(FormattedMessage, {
																				id: 'editUserDialog.emailRequired',
																				defaultMessage: 'Email is required'
																			})
																		: isInvalidEmail(user.email)
																			? _jsx(FormattedMessage, {
																					id: 'editUserDialog.invalidEmail',
																					defaultMessage: 'Email is invalid'
																				})
																			: null,
																	slotProps: {
																		htmlInput: { maxLength: USER_EMAIL_MAX_LENGTH }
																	}
																})
															: _jsx(Typography, { className: 'username', children: user.email })
													]
												}),
												managedInStudio &&
													_jsxs(Box, {
														sx: {
															display: 'flex',
															paddingBottom: '20px',
															'& button:first-child': {
																marginLeft: 'auto',
																marginRight: '10px'
															}
														},
														children: [
															_jsx(SecondaryButton, {
																disabled: !dirty || inProgress,
																onClick: onCancelForm,
																children: _jsx(FormattedMessage, { id: 'words.cancel', defaultMessage: 'Cancel' })
															}),
															_jsx(PrimaryButton, {
																disabled: !dirty || !submitOk || inProgress,
																onClick: onSave,
																loading: inProgress,
																children: _jsx(FormattedMessage, { id: 'words.save', defaultMessage: 'Save' })
															})
														]
													})
											]
										})
									]
								})
							}),
							_jsx(Grid, {
								size: { sm: 6 },
								children: _jsx(Box, {
									component: 'section',
									sx: { padding: '30px 40px' },
									children: _jsx(UserGroupMembershipEditor, { username: user.username })
								})
							})
						]
					}),
					_jsx(Divider, {}),
					_jsxs(Box, {
						component: 'section',
						sx: { padding: '30px 40px' },
						children: [
							_jsx(Typography, {
								variant: 'subtitle1',
								sx: { textTransform: 'uppercase', marginBottom: '10px' },
								children: _jsx(FormattedMessage, {
									id: 'userInfoDialog.siteRoles',
									defaultMessage: 'Roles per project'
								})
							}),
							_jsxs(Grid, {
								container: true,
								spacing: 2,
								children: [
									_jsx(Grid, {
										size: 4,
										children: sites.map((site) =>
											_jsx(Typography, { variant: 'body2', sx: { margin: '10px 0' }, children: site.name }, site.id)
										)
									}),
									_jsx(Grid, {
										size: 8,
										children: sites.map((site, i) =>
											rolesBySite[site.id]
												? rolesBySite[site.id].length
													? _jsx(
															Typography,
															{ variant: 'body2', sx: { margin: '10px 0' }, children: rolesBySite[site.id].join(', ') },
															site.id
														)
													: _jsxs(
															Typography,
															{
																variant: 'body2',
																color: 'textSecondary',
																sx: { margin: '10px 0' },
																children: [
																	'(',
																	_jsx(FormattedMessage, { id: 'userInfoDialog.noRoles', defaultMessage: 'No roles' }),
																	')'
																]
															},
															site.id
														)
												: _jsx(
														Skeleton,
														{ variant: 'text', sx: { margin: '10px 0' }, style: { width: `${rand(50, 90)}%` } },
														i
													)
										)
									})
								]
							})
						]
					})
				]
			}),
			managedInStudio &&
				_jsx(ResetPasswordDialog, {
					open: openResetPassword,
					passwordRequirementsMinComplexity: passwordRequirementsMinComplexity,
					user: user,
					onClose: onCloseResetPasswordDialog
				})
		]
	});
}
export default EditUserDialogUI;
