/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import FormControl from '@mui/material/FormControl';
import commonStyles from './styles';
import FormGroup from '@mui/material/FormGroup';
import FormLabel from '@mui/material/FormLabel';
import usePossibleTranslation from '../../hooks/usePossibleTranslation';
export function CheckboxGroup(props) {
	const { field, value = [], onChange, disabled } = props;
	const label = usePossibleTranslation(field.name);
	const handleChange = (e) =>
		onChange(e.target.checked ? value.concat(e.target.value) : value.filter((val) => val !== e.target.value));
	return _jsxs(_Fragment, {
		children: [
			_jsx(FormLabel, { sx: commonStyles.inputLabel, htmlFor: field.id, children: label }),
			_jsx(FormControl, {
				variant: 'outlined',
				sx: commonStyles.formControl,
				fullWidth: true,
				children: _jsx(FormGroup, {
					children: field.values?.map((possibleValue) =>
						_jsx(
							FormControlLabel,
							{
								control: _jsx(Checkbox, {
									value: possibleValue.value,
									color: 'primary',
									checked: value.includes(possibleValue.value),
									onChange: handleChange,
									disabled: disabled
								}),
								label: possibleValue.label
							},
							possibleValue.value
						)
					)
				})
			})
		]
	});
}
export default CheckboxGroup;
