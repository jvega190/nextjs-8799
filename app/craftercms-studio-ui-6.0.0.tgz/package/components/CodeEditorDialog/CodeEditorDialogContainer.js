/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import React, { useEffect, useRef, useState } from 'react';
import DialogHeader from '../DialogHeader/DialogHeader';
import DialogBody from '../DialogBody/DialogBody';
import { fetchContentXML, lock, writeContent } from '../../services/content';
import { ConditionalLoadingState } from '../LoadingState/LoadingState';
import AceEditor from '../AceEditor/AceEditor';
import { useDispatch } from 'react-redux';
import Skeleton from '@mui/material/Skeleton';
import ListSubheader from '@mui/material/ListSubheader';
import DialogFooter from '../DialogFooter/DialogFooter';
import SecondaryButton from '../SecondaryButton';
import { FormattedMessage, useIntl } from 'react-intl';
import { showSystemNotification } from '../../state/actions/system';
import translations from './translations';
import MenuItem from '@mui/material/MenuItem';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import { isItemLockedForMe, isLockedState } from '../../utils/content';
import { useContentTypes } from '../../hooks/useContentTypes';
import { useActiveUser } from '../../hooks/useActiveUser';
import { useActiveSiteId } from '../../hooks/useActiveSiteId';
import { useReferences } from '../../hooks/useReferences';
import { getHostToGuestBus } from '../../utils/subjects';
import { reloadRequest } from '../../state/actions/preview';
import { getContentModelSnippets } from './utils';
import { MultiChoiceSaveButton } from '../MultiChoiceSaveButton';
import useUpToDateRefs from '../../hooks/useUpdateRefs';
import { EnhancedDialog, useEnhancedDialogContext } from '../EnhancedDialog';
import { writeConfiguration } from '../../services/configuration';
import { forkJoin, switchMap } from 'rxjs';
import { cancelPackages, fetchAffectedPackages } from '../../services/workflow';
import Alert, { alertClasses } from '@mui/material/Alert';
import { pushDialog } from '../../state/actions/dialogStack';
import { createComponentId, pushErrorDialog } from '../../utils/system';
import { useContentItem } from '../../hooks/useContentItem';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import TextFieldWithMax from '../TextFieldWithMax';
import { Typography } from '@mui/material';
import useSpreadState from '../../hooks/useSpreadState';
export function CodeEditorDialogContainer(props) {
	const { path, onMinimize, onClose, mode, readonly, contentType, onFullScreen, onSuccess } = props;
	const { open, isSubmitting } = useEnhancedDialogContext();
	const item = useContentItem(path);
	const site = useActiveSiteId();
	const user = useActiveUser();
	const [loading, setLoading] = useState(false);
	const [content, setContent] = useState(null);
	const itemLoaded = Boolean(item); // isLocked and isLockedForMe only hold accurate value if item was already loaded.
	const isLocked = isLockedState(item?.state);
	const isLockedForMe = isItemLockedForMe(item, user.username);
	const shouldPerformLock = open && itemLoaded && !readonly && !isLockedForMe && !isLocked;
	const editorRef = useRef(undefined);
	const dispatch = useDispatch();
	const { formatMessage } = useIntl();
	const contentTypes = useContentTypes();
	const [anchorEl, setAnchorEl] = React.useState(null);
	const [snippets, setSnippets] = useState({});
	const [contentModelSnippets, setContentModelSnippets] = useState(null);
	const [affectedPackages, setAffectedPackages] = useState(undefined);
	const { updateSubmittingOrHasPendingChanges } = useEnhancedDialogContext();
	const storedId = 'codeEditor';
	const {
		'craftercms.freemarkerCodeSnippets': freemarkerCodeSnippets,
		'craftercms.groovyCodeSnippets': groovyCodeSnippets
	} = useReferences() ?? {};
	const onChangeTimeoutRef = useRef(null);
	const [saveWithCommentState, setSaveWithCommentState] = useSpreadState({
		saveWithComment: false,
		openDialog: false,
		comment: '',
		saveType: null
	});
	const isConfig = path.startsWith('/config');
	const onEditorChanges = () => {
		clearTimeout(onChangeTimeoutRef.current);
		onChangeTimeoutRef.current = setTimeout(() => {
			updateSubmittingOrHasPendingChanges({ hasPendingChanges: content !== editorRef.current.getValue() });
		}, 150);
	};
	const save = (callback, cancelPackagesComment = '') => {
		if (!isLockedForMe && !readonly) {
			updateSubmittingOrHasPendingChanges({ isSubmitting: true });
			const value = editorRef.current.getValue();
			const module = isConfig ? path.split('/')[2] : null;
			const service$ = isConfig
				? writeConfiguration(site, path.replace(`/config/${module}`, ''), module, value)
				: writeContent(site, path, value, {
						unlock: false,
						...(saveWithCommentState.saveWithComment && { comment: saveWithCommentState.comment })
					});
			// If item is in packages in active workflow, before saving we need to cancel the packages.
			const preWriteAction$ = affectedPackages?.length
				? cancelPackages(site, {
						packageIds: affectedPackages.map((p) => p.id),
						comment: cancelPackagesComment
					}).pipe(switchMap(() => service$))
				: service$;
			preWriteAction$.subscribe({
				next() {
					updateSubmittingOrHasPendingChanges({ isSubmitting: false, hasPendingChanges: false });
					dispatch(showSystemNotification({ message: formatMessage(translations.saved) }));
					setTimeout(callback);
					getHostToGuestBus().next(reloadRequest());
					onSuccess?.();
				},
				error({ response }) {
					updateSubmittingOrHasPendingChanges({ isSubmitting: false });
					dispatch(pushErrorDialog({ props: { error: response } }));
				}
			});
		}
	};
	const checkItemWorkflow = (callback) => {
		// Before saving, check if the item is part of a package in active workflow. If so, show a dialog to review the
		// packages before continuing with the cancellation of the packages and saving the item.
		if (affectedPackages?.length) {
			dispatch(
				pushDialog({
					component: createComponentId('ViewPackagesDialog'),
					props: {
						item,
						cancelPackagesInitialComment: formatMessage(
							{ defaultMessage: 'Cancel packages to write on "{path}"' },
							{ path }
						),
						onContinue: (cancelPackagesUpdatedComment) => {
							save(callback, cancelPackagesUpdatedComment);
						}
					}
				})
			);
		} else {
			save(callback);
		}
	};
	const onSaveButtonClick = () => {
		checkItemWorkflow(() => setContent(editorRef.current.getValue()));
	};
	const onAddSnippet = (event) => {
		setAnchorEl(event.currentTarget);
	};
	const closeSnippets = () => {
		setAnchorEl(null);
	};
	const onSnippetSelected = (snippet) => {
		const cursorPosition = editorRef.current.getCursorPosition();
		editorRef.current.session.insert(cursorPosition, snippet.value);
		editorRef.current.focus();
		closeSnippets();
	};
	const onCloseButtonClick = (e) => {
		fnRefs.current.onClose(e, null);
	};
	const saveChoiceSelection = (type) => {
		switch (type) {
			case 'save':
				onSaveButtonClick();
				break;
			case 'saveAndClose':
				checkItemWorkflow(() => onCloseButtonClick(null));
				break;
			case 'saveAndMinimize':
				checkItemWorkflow(() => {
					setContent(editorRef.current.getValue());
					onMinimize?.();
				});
				break;
		}
	};
	const onMultiChoiceSaveButtonClick = (e, type) => {
		if (saveWithCommentState.saveWithComment) {
			setSaveWithCommentState({ openDialog: true, saveType: type });
		} else {
			saveChoiceSelection(type);
		}
	};
	const onAceInit = (editor) => {
		editor.commands.addCommand({
			name: 'saveToCrafter',
			bindKey: { win: 'Ctrl-S', mac: 'Command-S' },
			exec: () => fnRefs.current.onSaveButtonClick(),
			readOnly: false
		});
	};
	const fnRefs = useUpToDateRefs({ onSaveButtonClick, onClose });
	// add content model variables
	useEffect(() => {
		if (contentTypes && item) {
			const _contentType = contentType
				? contentType
				: Object.values(contentTypes).find((contentType) => contentType.displayTemplate === item.path)?.id;
			if (mode === 'ftl') {
				let { contentVariable, ...rest } = freemarkerCodeSnippets;
				setSnippets(rest);
				if (contentVariable && _contentType) {
					setContentModelSnippets(getContentModelSnippets(contentVariable, contentTypes[_contentType].fields));
				}
			} else if (mode === 'groovy') {
				let { accessContentModel, ...rest } = groovyCodeSnippets;
				setSnippets(rest);
				if (accessContentModel && _contentType) {
					setContentModelSnippets(getContentModelSnippets(accessContentModel, contentTypes[_contentType].fields));
				}
			}
		}
	}, [contentTypes, contentType, mode, item, freemarkerCodeSnippets, groovyCodeSnippets]);
	useEffect(() => {
		if (content === null) {
			setLoading(true);
			updateSubmittingOrHasPendingChanges({ isSubmitting: true });
			const subscription = forkJoin([fetchContentXML(site, path), fetchAffectedPackages(site, path)]).subscribe(
				([xml, affectedPackages]) => {
					setContent(xml);
					setAffectedPackages(affectedPackages);
					setLoading(false);
					updateSubmittingOrHasPendingChanges({ isSubmitting: false });
				}
			);
			return () => {
				subscription.unsubscribe();
			};
		}
	}, [content, dispatch, path, site, updateSubmittingOrHasPendingChanges]);
	useEffect(() => {
		if (shouldPerformLock) {
			lock(site, path).subscribe();
		}
	}, [path, shouldPerformLock, site]);
	return _jsxs(_Fragment, {
		children: [
			_jsx(DialogHeader, {
				title: item ? item.label : _jsx(Skeleton, { width: '120px' }),
				subtitle: affectedPackages?.length
					? _jsx(Alert, {
							variant: 'outlined',
							severity: 'warning',
							sx: {
								p: 0,
								border: 'none',
								[`& .${alertClasses.icon}, & .${alertClasses.message}`]: {
									p: 0
								},
								[`& .${alertClasses.action}`]: {
									py: 0
								}
							},
							action: _jsx(Button, {
								color: 'inherit',
								size: 'small',
								sx: { p: 0 },
								onClick: () => {
									dispatch(pushDialog({ component: createComponentId('ViewPackagesDialog'), props: { item } }));
								},
								children: _jsx(FormattedMessage, { defaultMessage: 'Review' })
							}),
							children: _jsx(FormattedMessage, {
								defaultMessage:
									'The item is part of one or more publishing packages. Editing it will cancel the packages.'
							})
						})
					: null,
				onCloseButtonClick: onCloseButtonClick,
				onMinimizeButtonClick: onMinimize,
				onFullScreenButtonClick: onFullScreen,
				disabled: isSubmitting
			}),
			_jsx(DialogBody, {
				sx: {
					height: '60vh',
					padding: 0,
					'.MuiDialogTitle-root + &': {
						pt: 0
					}
				},
				children: _jsx(ConditionalLoadingState, {
					isLoading: loading,
					sxs: { root: { flexGrow: 1 } },
					children: _jsx(AceEditor, {
						ref: editorRef,
						autoFocus: !readonly,
						mode: `ace/mode/${mode}`,
						value: content ?? '',
						onChange: onEditorChanges,
						readOnly: isLockedForMe || readonly,
						sxs: { editorRoot: { position: 'absolute' } },
						enableBasicAutocompletion: true,
						enableSnippets: true,
						enableLiveAutocompletion: true,
						onInit: onAceInit
					})
				})
			}),
			!readonly &&
				_jsxs(DialogFooter, {
					children: [
						_jsx(Button, {
							onClick: onAddSnippet,
							endIcon: _jsx(ExpandMoreRoundedIcon, {}),
							sx: { marginRight: 'auto' },
							disabled: isSubmitting || isLockedForMe,
							children: _jsx(FormattedMessage, { id: 'codeEditor.insertCode', defaultMessage: 'Insert Code' })
						}),
						!isConfig &&
							_jsx(FormControlLabel, {
								control: _jsx(Checkbox, {
									size: 'small',
									checked: saveWithCommentState.saveWithComment,
									onChange: (e) => setSaveWithCommentState({ saveWithComment: e.target.checked })
								}),
								label: _jsx(Typography, {
									variant: 'body2',
									children: _jsx(FormattedMessage, { defaultMessage: 'Save with comment' })
								})
							}),
						_jsx(SecondaryButton, {
							onClick: onCloseButtonClick,
							sx: { mr: '8px' },
							disabled: isSubmitting,
							children: _jsx(FormattedMessage, { id: 'words.cancel', defaultMessage: 'Cancel' })
						}),
						_jsx(MultiChoiceSaveButton, {
							loading: isSubmitting,
							disabled: isLockedForMe,
							storageKey: storedId,
							onClick: onMultiChoiceSaveButtonClick
						})
					]
				}),
			_jsxs(Menu, {
				anchorEl: anchorEl,
				keepMounted: true,
				open: Boolean(anchorEl),
				onClose: closeSnippets,
				children: [
					contentModelSnippets &&
						_jsx(ListSubheader, {
							disableSticky: true,
							children: _jsx(FormattedMessage, { id: 'codeEditor.contentModel', defaultMessage: 'Content model' })
						}),
					contentModelSnippets?.map((snippet, i) =>
						_jsx(MenuItem, { onClick: () => onSnippetSelected(snippet), dense: true, children: snippet.label }, i)
					),
					_jsx(ListSubheader, {
						children: _jsx(FormattedMessage, { id: 'words.snippets', defaultMessage: 'Snippets' })
					}),
					Object.values(snippets).map((snippet, i) =>
						_jsx(MenuItem, { onClick: () => onSnippetSelected(snippet), dense: true, children: snippet.label }, i)
					)
				]
			}),
			_jsxs(EnhancedDialog, {
				open: saveWithCommentState.openDialog,
				onClose: () => setSaveWithCommentState({ openDialog: false }),
				maxWidth: 'sm',
				fullWidth: true,
				title: _jsx(FormattedMessage, { defaultMessage: 'Save with Comment' }),
				children: [
					_jsx(DialogBody, {
						children: _jsx(TextFieldWithMax, {
							autoFocus: true,
							margin: 'dense',
							label: _jsx(FormattedMessage, { defaultMessage: 'Comment' }),
							type: 'text',
							fullWidth: true,
							multiline: true,
							minRows: 2,
							value: saveWithCommentState.comment,
							onChange: (e) => setSaveWithCommentState({ comment: e.target.value }),
							disabled: loading
						})
					}),
					_jsxs(DialogFooter, {
						children: [
							_jsx(Button, {
								onClick: () => setSaveWithCommentState({ openDialog: false, comment: '', saveType: null }),
								disabled: loading,
								children: _jsx(FormattedMessage, { id: 'words.cancel', defaultMessage: 'Cancel' })
							}),
							_jsx(Button, {
								onClick: () => {
									setSaveWithCommentState({ openDialog: false });
									saveChoiceSelection(saveWithCommentState.saveType);
								},
								disabled: loading || !saveWithCommentState.comment.trim(),
								variant: 'contained',
								color: 'primary',
								children: _jsx(FormattedMessage, { id: 'words.save', defaultMessage: 'Save' })
							})
						]
					})
				]
			})
		]
	});
}
export default CodeEditorDialogContainer;
