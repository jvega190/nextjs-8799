/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useCallback, useEffect, useState } from 'react';
import { search } from '../../services/search';
import { useActiveSiteId } from '../../hooks/useActiveSiteId';
import { useEnv } from '../../hooks/useEnv';
import { useDebouncedInput } from '../../hooks/useDebouncedInput';
import { useSpreadState } from '../../hooks/useSpreadState';
import { useDispatch } from 'react-redux';
import { BrowseFilesDialogUI, viewModes } from '.';
import { initialParameters } from './utils';
import { checkPathExistence } from '../../services/content';
import { FormattedMessage } from 'react-intl';
import EmptyState from '../EmptyState';
import BrowseFilesDialogContainerSkeleton from './BrowseFilesDialogContainerSkeleton';
import { getStoredBrowseDialogViewMode, setStoredBrowseDialogViewMode } from '../../utils/state';
import useActiveUser from '../../hooks/useActiveUser';
import { withIndex, withoutIndex } from '../../utils/path';
import { createPresenceTable } from '../../utils/array';
import { createLookupTable } from '../../utils/object';
import { prepareSearchParams } from '../Search/utils';
import { popDialog, pushDialog } from '../../state/actions/dialogStack';
import { nanoid } from 'nanoid';
import { createComponentId } from '../../utils/system';
const defaultPreselectedPaths = [];
export function BrowseFilesDialogContainer(props) {
	const {
		path,
		onClose,
		onSuccess,
		multiSelect = false,
		mimeTypes,
		contentTypes,
		numOfLoaderItems,
		allowUpload = true,
		initialParameters: initialParametersProp,
		preselectedPaths = defaultPreselectedPaths,
		disableChangePreselected = true
	} = props;
	const [items, setItems] = useState();
	const site = useActiveSiteId();
	const { guestBase } = useEnv();
	const dispatch = useDispatch();
	const [keyword, setKeyword] = useState(initialParametersProp?.keywords ?? '');
	const [selectedCard, setSelectedCard] = useState();
	const [searchParameters, setSearchParameters] = useSpreadState({
		...initialParameters,
		...initialParametersProp,
		filters: {
			...initialParameters.filters,
			...initialParametersProp?.filters,
			...(mimeTypes && { 'mime-type': mimeTypes }),
			...(contentTypes && { 'content-type': contentTypes })
		}
	});
	const [total, setTotal] = useState();
	const [selectedLookup, setSelectedLookup] = useSpreadState({});
	const selectedArray = Object.keys(selectedLookup).filter((key) => selectedLookup[key]);
	const selectedInCurrentPage = items?.filter((item) => selectedArray.includes(item.path));
	const allSelectedInCurrentPage = items?.length > 0 && selectedInCurrentPage.length === items.length;
	const someSelectedInCurrentPage =
		(items?.length > 0 && selectedInCurrentPage.length > 0 && selectedInCurrentPage.length < items?.length) ?? false;
	const browsePath = path.replace(/\/+$/, '');
	const [currentPath, setCurrentPath] = useState(browsePath);
	const [fetchingBrowsePathExists, setFetchingBrowsePathExists] = useState(false);
	const [browsePathExists, setBrowsePathExists] = useState(false);
	const [sortKeys, setSortKeys] = useState([]);
	const { username } = useActiveUser();
	const [viewMode, setViewMode] = useState(getStoredBrowseDialogViewMode(username));
	const [fetchingPreselectedItems, setFetchingPreselectedItems] = useState(false);
	const disableSubmission = fetchingPreselectedItems || (!selectedArray.length && !selectedCard);
	const preselectedLookup = createPresenceTable(preselectedPaths);
	const fetchItems = useCallback(() => {
		// Since lookahead regex is not supported by opensearch, we are excluding the current path from the search using a
		// negative filter in a query. This scenario only happens with pages, hence the `withIndex` function wrapping the
		// current path.
		search(site, {
			...prepareSearchParams(searchParameters),
			path: `${currentPath}/[^/]+(/index\\.xml)?`,
			query: `-localId:"${withIndex(currentPath)}"`
		}).subscribe((response) => {
			setTotal(response.total);
			setItems(response.items);
			setSortKeys(response.facets.map((facet) => facet.name));
		});
	}, [searchParameters, currentPath, site]);
	useEffect(() => {
		const query = preselectedPaths?.map((path) => `localId:"${path}"`).join(' ');
		if (query) {
			setFetchingPreselectedItems(true);
			search(site, { query }).subscribe({
				next: ({ items }) => {
					if (multiSelect) {
						setSelectedLookup(createLookupTable(items, 'path'));
					} else if (items.length) {
						setSelectedCard(items[0]);
					}
					setFetchingPreselectedItems(false);
				},
				error: () => {
					setFetchingPreselectedItems(false);
				}
			});
		}
	}, [site, preselectedPaths, multiSelect, setSelectedLookup]);
	useEffect(() => {
		let subscription;
		if (!browsePathExists) {
			setFetchingBrowsePathExists(true);
			subscription = checkPathExistence(site, browsePath).subscribe((exists) => {
				if (exists) {
					fetchItems();
					setBrowsePathExists(true);
				}
				setFetchingBrowsePathExists(false);
			});
		} else {
			fetchItems();
		}
		return () => {
			subscription?.unsubscribe();
		};
	}, [fetchItems, site, browsePath, browsePathExists]);
	const onCardSelected = (item) => {
		if (multiSelect) {
			setSelectedLookup({ [item.path]: selectedLookup[item.path] ? null : item });
		} else {
			setSelectedCard(selectedCard?.path === item.path ? null : item);
		}
	};
	const onSelectAll = () => {
		if (multiSelect) {
			const newSelectedLookup = { ...selectedLookup };
			items.forEach((item) => {
				newSelectedLookup[item.path] = allSelectedInCurrentPage ? null : item;
			});
			setSelectedLookup(newSelectedLookup);
		}
	};
	const onSearch = useCallback(
		(keywords) => {
			setSearchParameters({ keywords });
		},
		[setSearchParameters]
	);
	const onSearch$ = useDebouncedInput(onSearch, 400);
	function handleSearchKeyword(keyword) {
		setKeyword(keyword);
		onSearch$.next(keyword);
	}
	const onSelectButtonClick = () => {
		onSuccess?.(multiSelect ? selectedArray.map((path) => selectedLookup[path]) : selectedCard);
	};
	const onChangePage = (page) => {
		setSearchParameters({ offset: page * searchParameters.limit });
	};
	const onChangeRowsPerPage = (e) => {
		setSearchParameters({ offset: 0, limit: e.target.value });
	};
	const onCheckboxChecked = (path, selected) => {
		setSelectedLookup({ [path]: selected ? items.find((item) => item.path === path) : null });
	};
	const onPathSelected = (path) => {
		setCurrentPath(withoutIndex(path));
	};
	const onCloseButtonClick = (e) => onClose(e, null);
	const onUpload = () => {
		const dialogId = nanoid();
		dispatch(
			pushDialog({
				id: dialogId,
				component: createComponentId('SingleFileUploadDialog'),
				props: {
					site,
					path: currentPath,
					fileTypes: mimeTypes,
					onClose: () => dispatch(popDialog({ id: dialogId })),
					onUploadComplete: () => {
						dispatch(popDialog({ id: dialogId }));
						setTimeout(() => {
							fetchItems();
						}, 2000);
					}
				}
			})
		);
	};
	const onRefresh = () => {
		fetchItems();
	};
	const switchViewMode = () => {
		let currentIndex = viewModes.indexOf(viewMode);
		let nextIndex;
		if (currentIndex === viewModes.length - 1) {
			nextIndex = 0;
		} else {
			nextIndex = currentIndex + 1;
		}
		setStoredBrowseDialogViewMode(username, viewModes[nextIndex]);
		setViewMode(viewModes[nextIndex]);
	};
	return fetchingBrowsePathExists
		? _jsx(BrowseFilesDialogContainerSkeleton, {})
		: browsePathExists
			? _jsx(BrowseFilesDialogUI, {
					viewMode: viewMode,
					onToggleViewMode: switchViewMode,
					currentPath: currentPath,
					items: items,
					path: browsePath,
					guestBase: guestBase,
					keyword: keyword,
					selectedCard: selectedCard,
					selectedArray: selectedArray,
					multiSelect: multiSelect,
					searchParameters: searchParameters,
					setSearchParameters: setSearchParameters,
					limit: searchParameters.limit,
					offset: searchParameters.offset,
					total: total,
					sortKeys: sortKeys,
					onCardSelected: onCardSelected,
					onChangePage: onChangePage,
					onChangeRowsPerPage: onChangeRowsPerPage,
					onCheckboxChecked: onCheckboxChecked,
					handleSearchKeyword: handleSearchKeyword,
					onCloseButtonClick: onCloseButtonClick,
					onPathSelected: onPathSelected,
					onSelectButtonClick: onSelectButtonClick,
					numOfLoaderItems: numOfLoaderItems,
					onRefresh: onRefresh,
					onUpload: onUpload,
					allowUpload: allowUpload,
					preselectedLookup: preselectedLookup,
					disableChangePreselected: disableChangePreselected,
					disableSubmission: disableSubmission,
					onSelectAll: onSelectAll,
					allSelected: allSelectedInCurrentPage,
					someSelected: someSelectedInCurrentPage
				})
			: _jsx(EmptyState, {
					sxs: { root: { height: '60vh' } },
					title: _jsx(FormattedMessage, {
						id: 'browseFilesDialog.emptyStateMessage',
						defaultMessage: "Path `{path}` doesn't exist.",
						values: { path: currentPath }
					})
				});
}
export default BrowseFilesDialogContainer;
