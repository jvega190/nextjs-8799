/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
import DialogBody from '../DialogBody';
import { Box } from '@mui/material';
import MediaSkeletonCard from './MediaSkeletonCard';
export function BrowseFilesDialogContainerSkeleton(props) {
	return _jsx(_Fragment, {
		children: _jsx(DialogBody, {
			sx: { minHeight: '60vh', padding: 0 },
			children: _jsxs(Box, {
				display: 'flex',
				children: [
					_jsx(Box, {
						component: 'section',
						sx: {
							width: '270px',
							minWidth: '270px',
							padding: '16px',
							overflow: 'auto',
							rowGap: (theme) => theme.spacing(1)
						}
					}),
					_jsx(Box, {
						component: 'section',
						sx: { flexGrow: 1, padding: '16px', overflow: 'auto' },
						children: _jsx(Box, {
							sx: {
								display: 'grid',
								gridTemplateColumns: 'repeat(auto-fit, minmax(200px, max-content))',
								gridGap: '16px',
								padding: 'initial'
							},
							children: Array(5)
								.fill(null)
								.map((x, i) => _jsx(MediaSkeletonCard, {}, i))
						})
					})
				]
			})
		})
	});
}
export default BrowseFilesDialogContainerSkeleton;
