/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2025 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { createElement, useState } from 'react';
import EnhancedDialog from '../EnhancedDialog/EnhancedDialog';
import FolderMoveAlert from '../FolderMoveAlert/FolderMoveAlert';
import { batchActions } from '../../state/actions/misc';
import { setClipboard } from '../../state/actions/content';
import { emitSystemEvent, itemCut, showCutItemSuccessNotification } from '../../state/actions/system';
import { FormattedMessage } from 'react-intl';
import SecondaryButton from '../SecondaryButton';
import PrimaryButton from '../PrimaryButton';
import DialogFooter from '../DialogFooter';
import { useDispatch } from 'react-redux';
import Tooltip from '@mui/material/Tooltip';
export function FolderMoveAlertDialog(props) {
	// eslint-disable-next-line @typescript-eslint/no-unused-vars -- Need `item` removed to pass down props to EnhancedDialog
	const { item, ...rest } = props;
	return _jsx(EnhancedDialog, {
		maxWidth: 'sm',
		title: _jsx(FormattedMessage, { defaultMessage: 'Warning' }),
		...rest,
		children: createElement(Body, props)
	});
}
function Body({ item, onClose }) {
	const [moveAck, setMoveAck] = useState(false);
	const dispatch = useDispatch();
	const onContinue = () => {
		dispatch(
			batchActions([
				setClipboard({ type: 'CUT', sourcePath: item.path }),
				emitSystemEvent(itemCut({ target: item.path })),
				showCutItemSuccessNotification()
			])
		);
		onClose?.(null, null);
	};
	return _jsxs(_Fragment, {
		children: [
			_jsx(FolderMoveAlert, {
				autoFocus: true,
				initialExpanded: true,
				checked: moveAck,
				action: 'move',
				onChange: (e) => setMoveAck(e.target.checked),
				sx: { border: 'none', borderRadius: 0 }
			}),
			_jsxs(DialogFooter, {
				children: [
					_jsx(SecondaryButton, {
						onClick: (e) => onClose?.(e, null),
						children: _jsx(FormattedMessage, { defaultMessage: 'Cancel' })
					}),
					_jsx(Tooltip, {
						title: moveAck
							? ''
							: _jsx(FormattedMessage, {
									defaultMessage: 'Please click the warning checkbox above to confirm and continue.'
								}),
						children: _jsx('span', {
							children: _jsx(PrimaryButton, {
								onClick: onContinue,
								disabled: !moveAck,
								children: _jsx(FormattedMessage, { defaultMessage: 'Continue' })
							})
						})
					})
				]
			})
		]
	});
}
export default FolderMoveAlertDialog;
