/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
import { CssBaseline } from '@mui/material';
import { Global } from '@emotion/react';
import { staticGlobalStyles } from './css';
import { useTheme } from '@mui/material/styles';
import { useMemo } from 'react';
import { typographyStyles } from './typography';
export function GlobalStyles(props) {
	const { cssBaseline = true } = props;
	const theme = useTheme();
	const dynamicStyles = useMemo(
		() => ({
			body: { background: theme.palette.background.paper },
			'.minimized-bar-portal-root': {
				right: '0',
				bottom: '20px',
				display: 'flex',
				position: 'fixed',
				flexDirection: 'row-reverse',
				width: '100%',
				overflow: 'auto',
				padding: '2px 20px',
				zIndex: theme.zIndex.modal,
				pointerEvents: 'none',
				'& > *': {
					pointerEvents: 'all'
				}
			}
		}),
		[theme.palette.background.paper, theme.zIndex.modal]
	);
	return _jsxs(_Fragment, {
		children: [
			cssBaseline && _jsx(CssBaseline, { enableColorScheme: true }),
			_jsx(Global, { styles: dynamicStyles }),
			_jsx(Global, { styles: staticGlobalStyles }),
			_jsx(Global, { styles: typographyStyles })
		]
	});
}
export default GlobalStyles;
