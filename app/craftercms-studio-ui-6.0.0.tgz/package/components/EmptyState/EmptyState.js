/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import React from 'react';
import Typography from '@mui/material/Typography';
import emptyImage from '../../assets/desert.svg';
import { useIntl } from 'react-intl';
import { nou } from '../../utils/object';
import Box from '@mui/material/Box';
function isValidElement(target) {
	return React.isValidElement(target) || nou(target) || ['string', 'number'].includes(typeof target);
}
export function EmptyState(props) {
	const { sxs } = props;
	const { formatMessage } = useIntl();
	const { image = emptyImage, classes: propClasses, children } = props;
	const title = isValidElement(props.title) ? props.title : formatMessage(props.title);
	const subtitle = isValidElement(props.subtitle) ? props.subtitle : formatMessage(props.subtitle);
	return _jsxs(Box, {
		className: propClasses?.root,
		sx: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			flexDirection: 'column',
			margin: (theme) => theme.spacing(2),
			...sxs?.root
		},
		children: [
			image &&
				_jsx(Box, {
					component: 'img',
					className: propClasses?.image,
					sx: { width: 100, maxWidth: '80%', ...sxs?.image },
					src: image,
					alt: ''
				}),
			title &&
				_jsx(Typography, {
					variant: 'body1',
					component: 'h3',
					className: propClasses?.title,
					sx: { margin: (theme) => `${theme.spacing(1)} 0`, ...sxs?.title },
					color: 'textSecondary',
					children: title
				}),
			subtitle &&
				_jsx(Typography, {
					variant: 'body2',
					component: 'p',
					className: propClasses?.subtitle,
					sx: { textAlign: 'center', ...sxs?.subtitle },
					color: 'textSecondary',
					children: subtitle
				}),
			children
		]
	});
}
export default EmptyState;
