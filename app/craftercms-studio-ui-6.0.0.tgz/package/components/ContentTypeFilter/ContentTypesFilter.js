/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { forwardRef } from 'react';
import { FormattedMessage, useIntl } from 'react-intl';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import useArchetypesList from '../../hooks/useArchetypesList';
import { getPossibleTranslation } from '../../utils/i18n';
export const ContentTypesFilter = forwardRef((props, ref) => {
	const { formatMessage } = useIntl();
	const archetypes = useArchetypesList();
	return _jsxs(Select, {
		...props,
		ref: ref,
		children: [
			_jsx(MenuItem, { value: 'all', children: _jsx(FormattedMessage, { defaultMessage: 'Show all types' }) }),
			archetypes.map((option) =>
				_jsx(
					MenuItem,
					{
						value: option.id,
						children: _jsx(FormattedMessage, {
							defaultMessage: '{label} only',
							values: {
								label: getPossibleTranslation(option.name, formatMessage)
							}
						})
					},
					option.id
				)
			)
		]
	});
});
export default ContentTypesFilter;
