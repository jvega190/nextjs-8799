/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import Button from '@mui/material/Button';
import React from 'react';
import Popover from '@mui/material/Popover';
import { defineMessages, useIntl } from 'react-intl';
import Typography from '@mui/material/Typography';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Radio from '@mui/material/Radio';
import { Checkbox, FormGroup } from '@mui/material';
import Box from '@mui/material/Box';
import { packageStatesMap } from '../PublishPackageReviewDialog/utils';
import { allFiltersState } from './PublishingQueue';
const messages = defineMessages({
	pathExpression: {
		id: 'publishingDashboard.pathExpression',
		defaultMessage: 'Path Expression'
	},
	environment: {
		id: 'common.publishingTarget',
		defaultMessage: 'Publishing Target'
	},
	state: {
		id: 'publishingDashboard.state',
		defaultMessage: 'State'
	},
	all: {
		id: 'publishingDashboard.all',
		defaultMessage: 'All'
	}
});
export const stateMessages = defineMessages({
	ready: {
		id: 'publishingDashboard.ready',
		defaultMessage: 'Ready for Live'
	},
	processing: {
		id: 'publishingDashboard.processing',
		defaultMessage: 'Processing'
	},
	liveSuccess: {
		id: 'publishingDashboard.liveSuccess',
		defaultMessage: 'Live Success'
	},
	liveCompletedWithErrors: {
		id: 'publishingDashboard.liveCompletedWithErrors',
		defaultMessage: 'Live Completed with Errors'
	},
	liveFailed: {
		id: 'publishingDashboard.liveFailed',
		defaultMessage: 'Live Failed'
	},
	stagingSuccess: {
		id: 'publishingDashboard.stagingSuccess',
		defaultMessage: 'Staging Success'
	},
	stagingCompletedWithErrors: {
		id: 'publishingDashboard.stagingCompletedWithErrors',
		defaultMessage: 'Staging Completed with Errors'
	},
	stagingFailed: {
		id: 'publishingDashboard.stagingFailed',
		defaultMessage: 'Staging Failed'
	},
	completed: {
		id: 'publishingDashboard.completed',
		defaultMessage: 'Completed'
	},
	cancelled: {
		id: 'publishingDashboard.cancelled',
		defaultMessage: 'Cancelled'
	}
});
export function FilterDropdown(props) {
	const [anchorEl, setAnchorEl] = React.useState(null);
	const { text, className, handleFilterChange, currentFilters, filters, sx } = props;
	const { formatMessage } = useIntl();
	const handleClick = (event) => {
		setAnchorEl(event.currentTarget);
	};
	const handleClose = () => {
		setAnchorEl(null);
	};
	return _jsxs('div', {
		children: [
			_jsxs(Button, {
				variant: 'outlined',
				onClick: handleClick,
				sx: sx,
				className: className,
				children: [text, ' ', _jsx(ArrowDropDownIcon, {})]
			}),
			_jsxs(Popover, {
				id: 'publishingFilterDropdown',
				anchorEl: anchorEl,
				slotProps: { paper: { sx: { width: '300px' } } },
				keepMounted: true,
				open: Boolean(anchorEl),
				onClose: handleClose,
				anchorOrigin: {
					vertical: 'bottom',
					horizontal: 'right'
				},
				transformOrigin: {
					vertical: 'top',
					horizontal: 'right'
				},
				children: [
					_jsxs('section', {
						children: [
							_jsx(Box, {
								component: 'header',
								sx: (theme) => ({
									background:
										theme.palette.mode === 'dark' ? theme.palette.background.default : theme.palette.grey['100'],
									padding: '10px'
								}),
								children: _jsx(Typography, {
									variant: 'body1',
									children: _jsx('strong', { children: formatMessage(messages.environment) })
								})
							}),
							_jsx(Box, {
								sx: { width: '100%', padding: '5px 15px 20px 15px' },
								children: _jsxs(RadioGroup, {
									'aria-label': formatMessage(messages.environment),
									name: 'target',
									value: currentFilters.target,
									onChange: handleFilterChange,
									children: [
										_jsx(FormControlLabel, {
											value: '',
											control: _jsx(Radio, { color: 'primary' }),
											label: formatMessage(messages.all)
										}),
										filters.environments &&
											filters.environments.map((filter, index) =>
												_jsx(
													FormControlLabel,
													{ value: filter, control: _jsx(Radio, { color: 'primary' }), label: filter },
													index
												)
											)
									]
								})
							})
						]
					}),
					_jsxs('section', {
						children: [
							_jsx(Box, {
								component: 'header',
								sx: (theme) => ({
									background:
										theme.palette.mode === 'dark' ? theme.palette.background.default : theme.palette.grey['100'],
									padding: '10px'
								}),
								children: _jsx(Typography, {
									variant: 'body1',
									sx: { ml: '5px' },
									children: _jsx(FormControlLabel, {
										value: '',
										label: _jsx('strong', { children: formatMessage(messages.state) }),
										control: _jsx(Checkbox, {
											color: 'primary',
											value: '',
											indeterminate:
												currentFilters.states !== null &&
												currentFilters.states !== 0 &&
												currentFilters.states !== allFiltersState,
											checked: currentFilters.states === allFiltersState,
											onChange: handleFilterChange
										})
									})
								})
							}),
							_jsx(Box, {
								sx: { width: '100%', padding: '5px 15px 20px 15px' },
								children: _jsx(FormGroup, {
									children: Object.entries(packageStatesMap).map(([key, { mask, validation }]) => {
										return _jsx(
											FormControlLabel,
											{
												value: mask,
												control: _jsx(Checkbox, {
													color: 'primary',
													value: mask,
													checked: validation(currentFilters.states),
													onChange: handleFilterChange
												}),
												label: formatMessage(stateMessages[key])
											},
											key
										);
									})
								})
							})
						]
					})
				]
			})
		]
	});
}
export default FilterDropdown;
