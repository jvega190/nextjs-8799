/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
import { FormattedMessage } from 'react-intl';
import { DeleteContentTypeDialogContainer } from './DeleteContentTypeDialogContainer';
import { EnhancedDialog } from '../EnhancedDialog';
function DeleteContentTypeDialog(props) {
	const { contentType, isSubmitting, onComplete, ...rest } = props;
	return _jsx(EnhancedDialog, {
		title: _jsx(FormattedMessage, { id: 'deleteContentTypeDialog.headerTitle', defaultMessage: 'Delete Content Type' }),
		dialogHeaderProps: {
			subtitle: _jsx(FormattedMessage, {
				id: 'deleteContentTypeDialog.headerSubtitle',
				defaultMessage: `Please confirm the deletion of "{name}"`,
				values: { name: contentType.name }
			})
		},
		...rest,
		children: _jsx(DeleteContentTypeDialogContainer, {
			contentType: contentType,
			isSubmitting: isSubmitting,
			onComplete: onComplete
		})
	});
}
export default DeleteContentTypeDialog;
