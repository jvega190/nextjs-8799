/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import List from '@mui/material/List';
import ListSubheader from '@mui/material/ListSubheader';
import { ListItem, ListItemText } from '@mui/material';
import ItemDisplay from '../ItemDisplay';
import Typography from '@mui/material/Typography';
function ContentTypeUsageReport(props) {
	const { entries, classes, messages } = props;
	return _jsx(_Fragment, {
		children: entries.map(([type, items]) =>
			_jsx(
				List,
				{
					subheader: _jsxs(ListSubheader, {
						className: classes?.listHeader,
						sx: { background: (theme) => theme.palette.background.paper },
						disableSticky: true,
						children: [messages[type] ?? type, ' (', items.length, ')']
					}),
					children: items.map((item) =>
						_jsx(
							ListItem,
							{
								divider: true,
								className: classes?.listItem,
								sx: { background: (theme) => theme.palette.background.paper },
								children: _jsx(ListItemText, {
									primary: _jsx(ItemDisplay, { item: item, showNavigableAsLinks: false }),
									secondary: _jsx(Typography, { variant: 'body2', color: 'textSecondary', children: item.path })
								})
							},
							item.path
						)
					)
				},
				type
			)
		)
	});
}
export default ContentTypeUsageReport;
