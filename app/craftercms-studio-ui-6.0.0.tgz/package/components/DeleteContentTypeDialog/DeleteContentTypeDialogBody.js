/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
import { useEffect, useState } from 'react';
import { defineMessages, FormattedMessage, useIntl } from 'react-intl';
import DialogBody from '../DialogBody/DialogBody';
import EmptyState from '../EmptyState/EmptyState';
import Alert from '@mui/material/Alert';
import { TextField } from '@mui/material';
import DialogFooter from '../DialogFooter/DialogFooter';
import SecondaryButton from '../SecondaryButton/SecondaryButton';
import PrimaryButton from '../PrimaryButton/PrimaryButton';
import LoadingState from '../LoadingState/LoadingState';
import ContentTypeUsageReport from './ContentTypeUsageReport';
import Box from '@mui/material/Box';
const messages = defineMessages({
	content: {
		id: 'words.content',
		defaultMessage: 'Content'
	},
	templates: {
		id: 'words.templates',
		defaultMessage: 'Templates'
	},
	scripts: {
		id: 'words.scripts',
		defaultMessage: 'Scripts'
	}
});
export function DeleteContentTypeDialogBody(props) {
	const { onCloseButtonClick, data, contentType, onSubmit: onSubmitProp, password = 'delete', submitting } = props;
	const { formatMessage } = useIntl();
	const dataEntries = Object.entries(data);
	const entriesWithItems = dataEntries.filter(([, items]) => items.length > 0);
	const noUsages = entriesWithItems.length === 0;
	const hasUsages = !noUsages;
	const [confirmPasswordPassed, setConfirmPasswordPassed] = useState(false);
	const [passwordFieldValue, setPasswordFieldValue] = useState('');
	useEffect(() => {
		setConfirmPasswordPassed(passwordFieldValue.toLowerCase() === password.toLowerCase());
	}, [password, passwordFieldValue]);
	const onSubmit = (e) => {
		e.preventDefault();
		if (confirmPasswordPassed || noUsages) {
			onSubmitProp?.();
		}
	};
	return _jsxs(_Fragment, {
		children: [
			_jsx(DialogBody, {
				children: noUsages
					? _jsx(Box, {
							sx: { background: (theme) => theme.palette.background.paper },
							children: _jsx(EmptyState, {
								title: _jsx(FormattedMessage, {
									id: 'deleteContentTypeDialog.noUsagesFound',
									defaultMessage: 'No usages found'
								}),
								subtitle: _jsx(FormattedMessage, {
									id: 'deleteContentTypeDialog.safeToDelete',
									defaultMessage: 'The content type can be safely deleted.'
								})
							})
						})
					: _jsxs(_Fragment, {
							children: [
								_jsx(Alert, {
									variant: 'outlined',
									severity: 'warning',
									sx: { marginBottom: '1em' },
									icon: false,
									children: _jsx(FormattedMessage, {
										defaultMessage: 'Please review and confirm all content type references that will be deleted.'
									})
								}),
								_jsx(ContentTypeUsageReport, {
									entries: entriesWithItems,
									messages: {
										content: formatMessage(messages.content),
										templates: formatMessage(messages.templates),
										scripts: formatMessage(messages.scripts)
									}
								}),
								_jsxs(Alert, {
									severity: 'warning',
									sx: { marginBottom: '.5em' },
									children: [
										_jsx(FormattedMessage, {
											defaultMessage: `Type the word "<b>{password}</b>" to confirm the deletion of "{name}" and all its references.`,
											values: {
												password,
												name: contentType.name,
												b: (message) => {
													return _jsx(Box, { component: 'strong', sx: { fontWeight: 600 }, children: message }, '');
												}
											}
										}),
										_jsx(TextField, {
											fullWidth: true,
											disabled: submitting,
											sx: {
												marginTop: '1em',
												'& legend': {
													width: 0
												}
											},
											value: passwordFieldValue,
											onChange: (e) => setPasswordFieldValue(e.target.value),
											onKeyPress: (e) => e.key === 'Enter' && onSubmit(e)
										})
									]
								})
							]
						})
			}),
			_jsxs(DialogFooter, {
				children: [
					_jsx(SecondaryButton, {
						onClick: onCloseButtonClick,
						autoFocus: true,
						disabled: submitting,
						children: _jsx(FormattedMessage, { id: 'words.cancel', defaultMessage: 'Cancel' })
					}),
					_jsx(PrimaryButton, {
						disabled: (hasUsages && !confirmPasswordPassed) || submitting,
						onClick: onSubmit,
						children: _jsx(FormattedMessage, { id: 'deleteContentTypeDialog.submitButton', defaultMessage: 'Delete' })
					})
				]
			}),
			submitting &&
				_jsx(Box, {
					sx: {
						position: 'absolute',
						top: 0,
						left: 0,
						right: 0,
						bottom: 0,
						display: 'flex',
						background: 'rgba(255,255,255,0.7)'
					},
					children: _jsx(LoadingState, {})
				})
		]
	});
}
export default DeleteContentTypeDialogBody;
