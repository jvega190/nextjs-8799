/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
import { FormattedMessage } from 'react-intl';
import { DropDownMenu } from '../DropDownMenuButton';
import { useMemo } from 'react';
export const filterOptionsLookup = {
	all: {
		name: _jsx(FormattedMessage, { defaultMessage: 'All' }),
		types: []
	},
	item: {
		name: _jsx(FormattedMessage, { defaultMessage: 'Items' }),
		types: ['page', 'component', 'levelDescriptor', 'taxonomy']
	},
	asset: {
		name: _jsx(FormattedMessage, { defaultMessage: 'Assets' }),
		types: ['asset']
	},
	contentType: {
		name: _jsx(FormattedMessage, { defaultMessage: 'Content Types' }),
		types: ['content type']
	},
	template: {
		name: _jsx(FormattedMessage, { defaultMessage: 'Templates' }),
		types: ['renderingTemplate']
	},
	script: {
		name: _jsx(FormattedMessage, { defaultMessage: 'Scripts' }),
		types: ['script']
	},
	other: {
		name: _jsx(FormattedMessage, { defaultMessage: 'Other' }),
		types: ['file', 'folder']
	}
};
export function DashletFilter(props) {
	const { selectedKeys, onChange } = props;
	const options = useMemo(
		() =>
			Object.keys(filterOptionsLookup).map((key) => ({
				id: key,
				primaryText: filterOptionsLookup[key].name,
				selected: selectedKeys.includes(key)
			})),
		[selectedKeys]
	);
	return _jsx(DropDownMenu, {
		size: 'small',
		variant: 'text',
		onMenuItemClick: onChange,
		options: options,
		closeOnSelection: false,
		menuProps: { sx: { minWidth: 180 } },
		children: selectedKeys.includes('all')
			? _jsx(FormattedMessage, { defaultMessage: 'Show all' })
			: _jsx(FormattedMessage, { defaultMessage: 'Filters active: {count}', values: { count: selectedKeys.length } })
	});
}
export default DashletFilter;
