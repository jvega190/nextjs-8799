/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsxs as _jsxs, jsx as _jsx, Fragment as _Fragment } from 'react/jsx-runtime';
import DeleteRoundedIcon from '@mui/icons-material/DeleteRounded';
import DialogBody from '../DialogBody/DialogBody';
import Typography from '@mui/material/Typography';
import { defineMessages, FormattedMessage, useIntl } from 'react-intl';
import Divider from '@mui/material/Divider';
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import ConfirmDropdown from '../ConfirmDropdown';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import PrimaryButton from '../PrimaryButton';
import Box from '@mui/material/Box';
import TransferList from '../TransferList';
import InputLabel from '@mui/material/InputLabel';
import OutlinedInput from '@mui/material/OutlinedInput';
import FormHelperText from '@mui/material/FormHelperText';
import {
	GROUP_DESCRIPTION_MAX_LENGTH,
	GROUP_NAME_MAX_LENGTH,
	GROUP_NAME_MIN_LENGTH,
	validateGroupNameMinLength,
	validateRequiredField
} from '../GroupManagement/utils';
import { excludeCommonItems } from '../TransferList/utils';
const translations = defineMessages({
	confirmHelperText: {
		id: 'editGroupDialog.helperText',
		defaultMessage: 'Delete group "{name}"?'
	},
	confirmOk: {
		id: 'words.yes',
		defaultMessage: 'Yes'
	},
	confirmCancel: {
		id: 'words.no',
		defaultMessage: 'No'
	}
});
export function EditGroupDialogUI(props) {
	const { formatMessage } = useIntl();
	const {
		title,
		subtitle,
		group,
		groupNameError,
		onDeleteGroup,
		onSave,
		submitOk,
		onChangeValue,
		onAddMembers,
		onRemoveMembers,
		onCloseButtonClick,
		users,
		members,
		membersLookup,
		inProgressIds,
		isDirty,
		isEdit,
		transferListState,
		sourceItemsAllChecked,
		onFilterUsers,
		onFetchMoreUsers,
		hasMoreUsers,
		disableAddMembers,
		isSubmitting
	} = props;
	const {
		sourceItems,
		sourceFilterKeyword,
		setSourceFilterKeyword,
		targetItems,
		filteredTargetItems,
		targetFilterKeyword,
		setTargetFilterKeyword,
		checkedList,
		onItemClicked,
		onCheckAllClicked,
		disableRemove,
		targetItemsAllChecked
	} = transferListState;
	return _jsxs(_Fragment, {
		children: [
			_jsxs(Box, {
				component: 'header',
				sx: {
					padding: '30px 40px',
					display: 'flex',
					alignItems: 'center'
				},
				children: [
					_jsxs('section', { children: [title, subtitle] }),
					_jsxs(Box, {
						component: 'section',
						sx: { marginLeft: 'auto' },
						children: [
							onDeleteGroup &&
								isEdit &&
								_jsx(ConfirmDropdown, {
									cancelText: formatMessage(translations.confirmCancel),
									confirmText: formatMessage(translations.confirmOk),
									confirmHelperText: formatMessage(translations.confirmHelperText, {
										name: group.name
									}),
									iconTooltip: _jsx(FormattedMessage, {
										id: 'editGroupDialog.deleteGroup',
										defaultMessage: 'Delete group'
									}),
									icon: DeleteRoundedIcon,
									onConfirm: () => {
										onDeleteGroup(group);
									}
								}),
							_jsx(Tooltip, {
								title: _jsx(FormattedMessage, { id: 'editGroupDialog.close', defaultMessage: 'Close' }),
								children: _jsx(IconButton, {
									edge: 'end',
									onClick: onCloseButtonClick,
									size: 'large',
									'aria-label': formatMessage({ id: 'editGroupDialog.close', defaultMessage: 'Close' }),
									children: _jsx(CloseRoundedIcon, {})
								})
							})
						]
					})
				]
			}),
			_jsx(Divider, {}),
			_jsxs(DialogBody, {
				sx: { p: 0 },
				children: [
					_jsxs(Box, {
						component: 'section',
						sx: { padding: '30px 40px', paddingBottom: 0 },
						children: [
							_jsx(Typography, {
								variant: 'subtitle1',
								sx: { textTransform: 'uppercase', marginBottom: '10px' },
								children: _jsx(FormattedMessage, {
									id: 'editGroupDialog.groupDetails',
									defaultMessage: 'Group Details'
								})
							}),
							_jsxs('form', {
								onSubmit: (e) => {
									e.preventDefault();
									onSave?.();
								},
								children: [
									_jsxs(Box, {
										display: 'flex',
										alignItems: 'center',
										p: '15px 0 0 0',
										children: [
											_jsx(InputLabel, {
												htmlFor: 'groupName',
												sx: { flexBasis: '180px', marginTop: '0 !important' },
												children: _jsx(Typography, {
													variant: 'subtitle2',
													children: _jsx(FormattedMessage, { id: 'words.name', defaultMessage: 'Name' })
												})
											}),
											isEdit
												? _jsx(Typography, {
														sx: { width: '100%' },
														color: 'textSecondary',
														noWrap: true,
														title: group.name,
														children: group.name
													})
												: _jsx(OutlinedInput, {
														id: 'groupName',
														onChange: (e) => onChangeValue({ key: 'name', value: e.currentTarget.value }),
														value: group.name,
														error: groupNameError,
														fullWidth: true,
														autoFocus: true,
														inputProps: { maxLength: GROUP_NAME_MAX_LENGTH }
													})
										]
									}),
									_jsxs(Box, {
										display: 'flex',
										p: '0 0 15px',
										children: [
											_jsx(Box, { sx: { flexBasis: '180px' } }),
											_jsx(FormHelperText, {
												error: groupNameError,
												children: validateRequiredField(group.name, isDirty)
													? _jsx(FormattedMessage, {
															id: 'editGroupDialog.requiredGroupName',
															defaultMessage: 'Group name is required.'
														})
													: validateGroupNameMinLength(group.name)
														? _jsx(FormattedMessage, {
																id: 'editGroupDialog.minLength',
																defaultMessage: 'Min {length} characters.',
																values: {
																	length: GROUP_NAME_MIN_LENGTH
																}
															})
														: _jsx(FormattedMessage, {
																id: 'editGroupDialog.invalidMinLength',
																defaultMessage:
																	'Max {length} characters, consisting of letters, numbers, dash (-), underscore (_) and dot (.).',
																values: {
																	length: GROUP_NAME_MAX_LENGTH
																}
															})
											})
										]
									}),
									_jsxs(Box, {
										display: 'flex',
										alignItems: 'center',
										p: '15px  0',
										children: [
											_jsx(InputLabel, {
												htmlFor: 'groupDescription',
												sx: { flexBasis: '180px', marginTop: '0 !important' },
												children: _jsx(Typography, {
													variant: 'subtitle2',
													children: _jsx(FormattedMessage, { id: 'words.description', defaultMessage: 'Description' })
												})
											}),
											_jsx(OutlinedInput, {
												id: 'groupDescription',
												onChange: (e) => onChangeValue({ key: 'desc', value: e.currentTarget.value }),
												value: group.desc,
												fullWidth: true,
												autoFocus: isEdit,
												inputProps: { maxLength: GROUP_DESCRIPTION_MAX_LENGTH },
												disabled: group.externallyManaged
											})
										]
									}),
									!group.externallyManaged &&
										_jsx(Box, {
											sx: {
												display: 'flex',
												paddingBottom: '20px',
												'& button:first-child': {
													marginLeft: 'auto',
													marginRight: '10px'
												}
											},
											children: _jsx(PrimaryButton, {
												disabled: !submitOk,
												loading: isSubmitting,
												type: 'submit',
												children: _jsx(FormattedMessage, { id: 'words.save', defaultMessage: 'Save' })
											})
										})
								]
							})
						]
					}),
					_jsx(Divider, {}),
					_jsx(Box, {
						component: 'section',
						sx: { padding: '30px 40px' },
						children: isEdit
							? users &&
								members &&
								_jsxs(_Fragment, {
									children: [
										_jsx(Typography, {
											variant: 'subtitle1',
											sx: { textTransform: 'uppercase', marginBottom: '30px' },
											children: _jsx(FormattedMessage, {
												id: 'editGroupDialog.groupMembers',
												defaultMessage: 'Group Members'
											})
										}),
										_jsx(TransferList, {
											disabled: group.externallyManaged,
											inProgressIds: inProgressIds,
											source: {
												title: _jsx(FormattedMessage, { id: 'words.users', defaultMessage: 'Users' }),
												items: sourceItems,
												filterKeyword: sourceFilterKeyword,
												setFilterKeyword: setSourceFilterKeyword,
												disabledItems: membersLookup,
												emptyStateMessage: _jsx(FormattedMessage, {
													id: 'transferList.noResults',
													defaultMessage: 'No results, try to change the query'
												}),
												onItemClick: onItemClicked,
												checkedList,
												inProgressIds,
												isAllChecked: sourceItemsAllChecked,
												onCheckAllClicked: (items, checked) => {
													onCheckAllClicked(excludeCommonItems(items, targetItems), checked);
												},
												onFilter: onFilterUsers,
												onFetchMore: onFetchMoreUsers,
												hasMoreItems: hasMoreUsers
											},
											target: {
												title: _jsx(FormattedMessage, { id: 'words.members', defaultMessage: 'Members' }),
												items: filteredTargetItems,
												filterKeyword: targetFilterKeyword,
												setFilterKeyword: setTargetFilterKeyword,
												emptyStateMessage: _jsx(FormattedMessage, {
													id: 'transferList.targetEmptyStateMessage',
													defaultMessage: 'No members on this group'
												}),
												onItemClick: onItemClicked,
												checkedList,
												inProgressIds,
												isAllChecked: targetItemsAllChecked,
												onCheckAllClicked
											},
											disableAdd: disableAddMembers,
											disableRemove: disableRemove,
											addToTarget: onAddMembers,
											removeFromTarget: onRemoveMembers
										})
									]
								})
							: _jsx(Box, {
									display: 'flex',
									justifyContent: 'center',
									children: _jsx(Typography, {
										variant: 'subtitle2',
										color: 'textSecondary',
										children: _jsx(FormattedMessage, {
											id: 'editGroupDialog.groupMemberHelperText',
											defaultMessage: 'Group members are editable after creation'
										})
									})
								})
					})
				]
			})
		]
	});
}
export default EditGroupDialogUI;
