/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import DialogFooter from '../DialogFooter';
import SecondaryButton from '../SecondaryButton';
import { FormattedMessage, useIntl } from 'react-intl';
import PrimaryButton from '../PrimaryButton';
import { DialogBody } from '../DialogBody';
import PackageDetails from '../PackageDetailsDialog/PackageDetails';
import TextFieldWithMax from '../TextFieldWithMax';
import { cancelPackages } from '../../services/workflow';
import useActiveSiteId from '../../hooks/useActiveSiteId';
import { isBlank } from '../../utils/string';
import useSpreadState from '../../hooks/useSpreadState';
import { useDispatch } from 'react-redux';
import { Divider } from '@mui/material';
import { showSystemNotification } from '../../state/actions/system';
import { pushErrorDialog } from '../../utils/system';
import { useEnhancedDialogContext } from '../EnhancedDialog';
export function CancelPackageDialogContainer(props) {
	const { packageId, onSuccess, onClose, isSubmitting } = props;
	const [state, setState] = useSpreadState({
		comment: '',
		error: null
	});
	const dispatch = useDispatch();
	const siteId = useActiveSiteId();
	const submitDisabled = isBlank(state.comment);
	const { formatMessage } = useIntl();
	const { updateSubmittingOrHasPendingChanges } = useEnhancedDialogContext();
	const handleSubmit = () => {
		updateSubmittingOrHasPendingChanges({ isSubmitting: true });
		cancelPackages(siteId, {
			packageIds: [packageId],
			comment: state.comment
		}).subscribe({
			next() {
				updateSubmittingOrHasPendingChanges({ isSubmitting: false });
				dispatch(
					showSystemNotification({ message: formatMessage({ defaultMessage: 'Package cancelled successfully.' }) })
				);
				onSuccess?.();
			},
			error({ response }) {
				updateSubmittingOrHasPendingChanges({ isSubmitting: false });
				dispatch(pushErrorDialog({ props: { error: response.response } }));
			}
		});
	};
	return _jsxs(_Fragment, {
		children: [
			_jsx(DialogBody, {
				sx: { px: 4 },
				children: _jsx(PackageDetails, {
					packageId: packageId,
					reviewActions: _jsxs(_Fragment, {
						children: [
							_jsx(Divider, {}),
							_jsx(TextFieldWithMax, {
								value: state.comment,
								label: _jsx(FormattedMessage, { defaultMessage: 'Comment' }),
								fullWidth: true,
								onChange: (e) => setState({ comment: e.target.value }),
								multiline: true,
								required: true,
								sx: { mt: 2 }
							})
						]
					})
				})
			}),
			_jsxs(DialogFooter, {
				children: [
					_jsx(SecondaryButton, {
						disabled: isSubmitting,
						onClick: (e) => onClose(e, null),
						children: _jsx(FormattedMessage, { defaultMessage: 'Close' })
					}),
					_jsx(PrimaryButton, {
						disabled: submitDisabled,
						loading: isSubmitting,
						onClick: () => handleSubmit(),
						children: _jsx(FormattedMessage, { defaultMessage: 'Confirm' })
					})
				]
			})
		]
	});
}
export default CancelPackageDialogContainer;
