/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2024 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { EnhancedDialog } from '../EnhancedDialog';
import { FormattedMessage } from 'react-intl';
import CancelPackageDialogContainer from './CancelPackageDialogContainer';
export function CancelPackageDialog(props) {
	const { packageId, onSuccess, isSubmitting, ...enhancedDialogProps } = props;
	return _jsx(EnhancedDialog, {
		fullWidth: true,
		maxWidth: 'lg',
		...enhancedDialogProps,
		title: _jsx(FormattedMessage, { defaultMessage: 'Cancel Package' }),
		isSubmitting: isSubmitting,
		children: _jsx(CancelPackageDialogContainer, {
			packageId: packageId,
			onSuccess: onSuccess,
			isSubmitting: isSubmitting
		})
	});
}
export default CancelPackageDialog;
