/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useEffect, useState } from 'react';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import EditIcon from '@mui/icons-material/Edit';
import { defineMessages, useIntl } from 'react-intl';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import palette from '../../styles/palette';
import Box from '@mui/material/Box';
const messages = defineMessages({
	siteInfo: {
		id: 'createSiteDialog.siteInfo',
		defaultMessage: 'Project Info'
	},
	blueprintStrategy: {
		id: 'createSiteDialog.blueprintStrategy',
		defaultMessage: 'Create from plugin'
	},
	gitStrategy: {
		id: 'createSiteDialog.gitStrategy',
		defaultMessage: 'Existing remote git repo clone'
	},
	creationStrategy: {
		id: 'createSiteDialog.creationStrategy',
		defaultMessage: 'Creation Strategy'
	},
	additionalOptions: {
		id: 'createSiteDialog.additionalOptions',
		defaultMessage: 'Additional Options'
	},
	remoteName: {
		id: 'createSiteDialog.remoteName',
		defaultMessage: 'Git Remote Name'
	},
	remoteURL: {
		id: 'createSiteDialog.remoteURL',
		defaultMessage: 'Git Repo URL'
	},
	siteId: {
		id: 'createSiteDialog.siteId',
		defaultMessage: 'Project ID'
	},
	siteName: {
		id: 'createSiteDialog.siteName',
		defaultMessage: 'Project Name'
	},
	gitBranch: {
		id: 'createSiteDialog.gitBranch',
		defaultMessage: 'Git Branch'
	},
	userNameAndPassword: {
		id: 'createSiteDialog.userNameAndPassword',
		defaultMessage: 'Username & Password'
	},
	token: {
		id: 'createSiteDialog.token',
		defaultMessage: 'Token'
	},
	privateKey: {
		id: 'createSiteDialog.privateKey',
		defaultMessage: 'Private Key'
	},
	authentication: {
		id: 'createSiteDialog.authentication',
		defaultMessage: 'Authentication'
	},
	noDescription: {
		id: 'createSiteDialog.noDescription',
		defaultMessage: 'No description supplied'
	},
	description: {
		id: 'createSiteDialog.description',
		defaultMessage: 'Description'
	},
	blueprint: {
		id: 'createSiteDialog.plugin',
		defaultMessage: 'Blueprint'
	},
	blueprintParameters: {
		id: 'createSiteDialog.blueprintParameters',
		defaultMessage: 'Blueprint Parameters'
	},
	useDefaultValue: {
		id: 'createSiteDialog.useDefaultValue',
		defaultMessage: 'use default value'
	}
});
function BlueprintReview(props) {
	const { onGoTo, inputs, blueprint } = props;
	const [passwordFields, setPasswordFields] = useState(null);
	const { formatMessage } = useIntl();
	useEffect(() => {
		if (blueprint.parameters) {
			let fields = {};
			blueprint.parameters.forEach((parameter) => {
				if (parameter.type === 'PASSWORD') {
					fields[parameter.name] = false;
				}
			});
			setPasswordFields(fields);
		}
	}, [blueprint]);
	function renderAuth(type) {
		if (type === 'basic') {
			return formatMessage(messages.userNameAndPassword);
		} else if (type === 'token') {
			return formatMessage(messages.token);
		} else {
			return formatMessage(messages.privateKey);
		}
	}
	function showPassword(parameter) {
		setPasswordFields({ ...passwordFields, [parameter.name]: !passwordFields[parameter.name] });
	}
	function renderSingleParameter(parameter) {
		if (inputs.blueprintFields[parameter.name] && parameter.type === 'STRING') {
			return inputs.blueprintFields[parameter.name];
		} else if (parameter.type === 'STRING') {
			return parameter.defaultValue;
		} else if (inputs.blueprintFields[parameter.name] && parameter.type === 'PASSWORD') {
			return _jsxs('span', {
				children: [
					passwordFields && passwordFields[parameter.name] ? inputs.blueprintFields[parameter.name] : '********',
					_jsx(IconButton, {
						edge: 'end',
						sx: {
							color: (theme) => theme.palette.primary.main,
							padding: '1px',
							marginLeft: '5px',
							'& svg': {
								fontSize: '1rem'
							}
						},
						'aria-label': 'toggle password visibility',
						onClick: () => {
							showPassword(parameter);
						},
						size: 'large',
						children: passwordFields && passwordFields[parameter.name] ? _jsx(VisibilityOff, {}) : _jsx(Visibility, {})
					})
				]
			});
		} else {
			return '********';
		}
	}
	function renderBlueprintParameters() {
		return blueprint.parameters.map((parameter, index) => {
			return _jsxs(
				Typography,
				{
					variant: 'body2',
					gutterBottom: true,
					children: [
						_jsxs(Box, { component: 'span', sx: { fontWeight: 'bold' }, children: [parameter.label, ':', ' '] }),
						renderSingleParameter(parameter)
					]
				},
				index
			);
		});
	}
	function renderGitOptions() {
		return _jsxs('div', {
			children: [
				inputs.repoUrl &&
					_jsxs(Typography, {
						variant: 'body2',
						gutterBottom: true,
						children: [
							_jsxs(Box, {
								component: 'span',
								sx: { fontWeight: 'bold' },
								children: [formatMessage(messages.remoteURL), ':', ' ']
							}),
							' ',
							inputs.repoUrl
						]
					}),
				_jsxs(Typography, {
					variant: 'body2',
					gutterBottom: true,
					children: [
						_jsxs(Box, {
							component: 'span',
							sx: { fontWeight: 'bold' },
							children: [formatMessage(messages.remoteName), ':']
						}),
						` ${inputs.repoRemoteName ? inputs.repoRemoteName : 'origin'}`
					]
				}),
				inputs.repoAuthentication !== 'none' &&
					_jsxs(Typography, {
						variant: 'body2',
						gutterBottom: true,
						children: [
							_jsxs(Box, {
								component: 'span',
								sx: { fontWeight: 'bold' },
								children: [formatMessage(messages.authentication), ':']
							}),
							' ',
							renderAuth(inputs.repoAuthentication)
						]
					})
			]
		});
	}
	return _jsx(Box, {
		sx: { maxWidth: '600px', margin: 'auto' },
		children: _jsxs(Grid, {
			container: true,
			spacing: 3,
			children: [
				_jsxs(Grid, {
					size: 12,
					children: [
						_jsxs(Typography, {
							variant: 'h6',
							gutterBottom: true,
							sx: { mb: 0 },
							children: [
								formatMessage(messages.creationStrategy),
								_jsx(IconButton, {
									'aria-label': 'goto',
									sx: {
										color: (theme) => theme.palette.primary.main,
										'& svg': {
											fontSize: '1.2rem'
										}
									},
									onClick: () => onGoTo(0),
									size: 'large',
									children: _jsx(EditIcon, {})
								})
							]
						}),
						blueprint.id !== 'GIT'
							? _jsxs('div', {
									children: [
										_jsx(Typography, {
											variant: 'body2',
											gutterBottom: true,
											children: formatMessage(messages.blueprintStrategy)
										}),
										_jsxs(Typography, {
											variant: 'body2',
											gutterBottom: true,
											children: [
												_jsxs(Box, {
													component: 'span',
													sx: { fontWeight: 'bold' },
													children: [formatMessage(messages.blueprint), ':', ' ']
												}),
												' ',
												blueprint && blueprint.name
											]
										})
									]
								})
							: _jsx('div', {
									children: _jsx(Typography, {
										variant: 'body2',
										gutterBottom: true,
										children: formatMessage(messages.gitStrategy)
									})
								})
					]
				}),
				_jsxs(Grid, {
					size: 12,
					children: [
						_jsxs(Typography, {
							variant: 'h6',
							gutterBottom: true,
							sx: { mb: 0 },
							children: [
								formatMessage(messages.siteInfo),
								_jsx(IconButton, {
									'aria-label': 'goto',
									sx: {
										color: (theme) => theme.palette.primary.main,
										'& svg': {
											fontSize: '1.2rem'
										}
									},
									onClick: () => onGoTo(1),
									size: 'large',
									children: _jsx(EditIcon, {})
								})
							]
						}),
						_jsxs(Typography, {
							variant: 'body2',
							gutterBottom: true,
							noWrap: true,
							children: [
								_jsxs(Box, {
									component: 'span',
									sx: { fontWeight: 'bold' },
									children: [formatMessage(messages.siteName), ':', ' ']
								}),
								' ',
								inputs.siteName
							]
						}),
						_jsxs(Typography, {
							variant: 'body2',
							gutterBottom: true,
							children: [
								_jsxs(Box, {
									component: 'span',
									sx: { fontWeight: 'bold' },
									children: [formatMessage(messages.siteId), ':', ' ']
								}),
								' ',
								inputs.siteId
							]
						}),
						_jsxs(Typography, {
							variant: 'body2',
							gutterBottom: true,
							children: [
								_jsxs(Box, {
									component: 'span',
									sx: { fontWeight: 'bold' },
									children: [formatMessage(messages.description), ':']
								}),
								` `,
								inputs.description
									? inputs.description
									: _jsxs(Box, {
											component: 'span',
											sx: { color: palette.gray.medium2 },
											children: ['(', formatMessage(messages.noDescription), ')']
										})
							]
						}),
						_jsxs(Typography, {
							variant: 'body2',
							gutterBottom: true,
							children: [
								_jsxs(Box, {
									component: 'span',
									sx: { fontWeight: 'bold' },
									children: [formatMessage(messages.gitBranch), ':']
								}),
								` ${inputs.gitBranch ? inputs.gitBranch : 'master'}`
							]
						}),
						blueprint.source !== 'GIT' && blueprint.id === 'GIT' && renderGitOptions()
					]
				}),
				blueprint.parameters &&
					!!blueprint.parameters.length &&
					_jsxs(Grid, {
						size: 12,
						children: [
							_jsxs(Typography, {
								variant: 'h6',
								gutterBottom: true,
								sx: { mb: 0 },
								children: [
									formatMessage(messages.blueprintParameters),
									_jsx(IconButton, {
										'aria-label': 'goto',
										sx: {
											color: (theme) => theme.palette.primary.main,
											'& svg': {
												fontSize: '1.2rem'
											}
										},
										onClick: () => onGoTo(1),
										size: 'large',
										children: _jsx(EditIcon, {})
									})
								]
							}),
							renderBlueprintParameters()
						]
					})
			]
		})
	});
}
export default BlueprintReview;
