/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
import Grid from '@mui/material/Grid';
import FormHelperText from '@mui/material/FormHelperText';
import Divider from '@mui/material/Divider';
import usePossibleTranslation from '../../hooks/usePossibleTranslation';
export function AudiencesFormSection(props) {
	const { field, showDivider, children } = props;
	const helpText = usePossibleTranslation(field.helpText);
	return _jsxs(_Fragment, {
		children: [
			_jsxs(Grid, { size: 12, children: [children, _jsx(FormHelperText, { children: helpText })] }),
			showDivider && _jsx(Divider, { style: { margin: '15px 0' } })
		]
	});
}
