/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import { forwardRef, useState } from 'react';
import { MenuItem } from '@mui/material';
import Fab from '@mui/material/Fab';
import Menu from '@mui/material/Menu';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
const SPACINGS = {
	small: 5,
	medium: 10
};
const ActionsGroup = forwardRef(function ActionsGroup(props, ref) {
	const { actions, classes: propClasses, className, max = 5, spacing, onActionClicked, sxs, ...other } = props;
	const clampedMax = max < 2 ? 2 : max;
	const extraActions = actions.length > clampedMax ? actions.length - clampedMax + 1 : 0;
	const marginLeft = spacing && SPACINGS[spacing] !== undefined ? SPACINGS[spacing] : spacing;
	const [showMenu, setShowMenu] = useState();
	return _jsxs(Box, {
		className: [className, propClasses?.root].filter(Boolean).join(' '),
		sx: sxs?.root,
		...other,
		ref: ref,
		children: [
			actions.slice(0, actions.length - extraActions).map((child, index) =>
				_jsx(
					Button,
					{
						onClick: (e) => onActionClicked?.(child.id, e),
						style: { marginLeft: index === 0 ? undefined : marginLeft },
						className: propClasses?.action,
						sx: {
							minWidth: '40px',
							...sxs?.action
						},
						color: 'primary',
						variant: 'text',
						size: 'small',
						children: child.label
					},
					child.id
				)
			),
			extraActions
				? _jsxs(Fab, {
						onClick: (e) => {
							setShowMenu(e.target);
						},
						size: 'small',
						variant: 'extended',
						color: 'inherit',
						className: propClasses?.more,
						style: {
							marginLeft
						},
						children: ['+', extraActions]
					})
				: null,
			_jsx(Menu, {
				open: Boolean(showMenu),
				anchorEl: showMenu,
				onClose: () => setShowMenu(void 0),
				children: actions.slice(actions.length - extraActions).map((child) =>
					_jsx(
						MenuItem,
						{
							onClick: (e) => {
								setShowMenu(void 0);
								onActionClicked?.(child.id, e);
							},
							children: child.label
						},
						child.id
					)
				)
			})
		]
	});
});
export default ActionsGroup;
