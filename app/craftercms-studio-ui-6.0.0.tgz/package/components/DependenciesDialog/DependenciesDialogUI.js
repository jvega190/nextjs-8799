/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { FormattedMessage } from 'react-intl';
import { useState } from 'react';
import DialogBody from '../DialogBody/DialogBody';
import SingleItemSelector from '../SingleItemSelector';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import DependenciesList from './DependenciesList';
import Menu from '@mui/material/Menu';
import DialogFooter from '../DialogFooter/DialogFooter';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import { assetsTypes } from './utils';
import Radio from '@mui/material/Radio';
import { ApiResponseErrorState } from '../ApiResponseErrorState';
import { LoadingState } from '../LoadingState';
import { EmptyState } from '../EmptyState';
import { getRootPath } from '../../utils/path';
import MoreVertIcon from '@mui/icons-material/MoreVertRounded';
import IconButton from '@mui/material/IconButton';
import Box from '@mui/material/Box';
export function DependenciesDialogUI(props) {
	const {
		dependencies,
		item,
		rootPath,
		setItem,
		compactView,
		setCompactView,
		showTypes,
		setShowTypes,
		dependenciesShown,
		setDependenciesShown,
		isEditableItem,
		handleEditorDisplay,
		handleHistoryDisplay,
		contextMenu,
		handleContextMenuClick,
		handleContextMenuClose,
		error
	} = props;
	const [openSelector, setOpenSelector] = useState(false);
	return _jsxs(_Fragment, {
		children: [
			_jsxs(DialogBody, {
				sx: { overflow: 'auto', minHeight: '50vh' },
				children: [
					_jsxs(Box, {
						sx: { marginBottom: '15px', display: 'flex' },
						children: [
							_jsx(SingleItemSelector, {
								label: _jsx(FormattedMessage, { id: 'words.item', defaultMessage: 'Item' }),
								open: openSelector,
								onClose: () => setOpenSelector(false),
								onDropdownClick: () => setOpenSelector(!openSelector),
								rootPath: rootPath,
								selectedItem: item,
								disabled: rootPath !== getRootPath(item.path),
								onItemClicked: (item) => {
									setOpenSelector(false);
									setItem(item);
								}
							}),
							_jsx(FormControl, {
								sx: { minWidth: 120, marginLeft: 'auto' },
								children: _jsxs(Select, {
									value: dependenciesShown ?? 'depends-on',
									onChange: (event) => {
										setDependenciesShown(event.target.value);
									},
									slotProps: {
										input: {
											sx: {
												fontSize: '16px',
												border: 'none',
												background: 'none'
											}
										}
									},
									children: [
										_jsx(MenuItem, {
											value: 'depends-on-me',
											children: _jsx(FormattedMessage, { defaultMessage: 'References of selected item' })
										}),
										_jsx(MenuItem, {
											value: 'depends-on',
											children: _jsx(FormattedMessage, {
												defaultMessage: 'Items that are referenced by the selected item'
											})
										})
									]
								})
							})
						]
					}),
					error
						? _jsx(ApiResponseErrorState, { error: error })
						: !dependencies
							? _jsx(LoadingState, { sxs: { root: { height: '100%', flexGrow: 1 } } })
							: dependencies?.length === 0
								? _jsx(EmptyState, {
										sxs: { root: { minHeight: 300, height: '100%' } },
										title:
											dependenciesShown === 'depends-on-me'
												? _jsx(FormattedMessage, {
														defaultMessage: '"{itemName}" has no references',
														values: { itemName: item?.label }
													})
												: _jsx(FormattedMessage, {
														defaultMessage: 'Nothing is referenced by "{itemName}"',
														values: { itemName: item?.label }
													})
									})
								: _jsxs(_Fragment, {
										children: [
											_jsx(DependenciesList, {
												dependencies: dependencies,
												compactView: compactView,
												showTypes: showTypes,
												renderAction: (dependency) =>
													isEditableItem(dependency.path)
														? _jsx(IconButton, {
																'aria-haspopup': 'true',
																onClick: (e) => {
																	handleContextMenuClick(e, dependency);
																},
																sx: { p: 1 },
																size: 'large',
																children: _jsx(MoreVertIcon, {})
															})
														: null
											}),
											_jsxs(Menu, {
												anchorEl: contextMenu.el,
												keepMounted: true,
												open: Boolean(contextMenu.el),
												onClose: handleContextMenuClose,
												children: [
													contextMenu.dependency &&
														isEditableItem(contextMenu.dependency.path) &&
														_jsx(MenuItem, {
															onClick: () => {
																handleEditorDisplay(contextMenu.dependency);
																handleContextMenuClose();
															},
															children: _jsx(FormattedMessage, {
																id: 'dependenciesDialog.edit',
																defaultMessage: 'Edit'
															})
														}),
													contextMenu.dependency &&
														_jsx(MenuItem, {
															onClick: () => {
																setItem(contextMenu.dependency);
																handleContextMenuClose();
															},
															children: _jsx(FormattedMessage, {
																id: 'dependenciesDialog.references',
																defaultMessage: 'References'
															})
														}),
													_jsxs(MenuItem, {
														onClick: () => {
															handleHistoryDisplay(contextMenu.dependency);
															handleContextMenuClose();
														},
														children: [
															' ',
															_jsx(FormattedMessage, { id: 'dependenciesDialog.history', defaultMessage: 'History' })
														]
													})
												]
											})
										]
									})
				]
			}),
			_jsxs(DialogFooter, {
				sx: (theme) => ({ paddingLeft: theme.spacing(2), paddingRight: theme.spacing(2) }),
				children: [
					_jsx(FormControlLabel, {
						sx: { marginRight: 'auto' },
						control: _jsx(Checkbox, {
							checked: compactView,
							onChange: (event) => {
								setCompactView(event.target.checked);
							},
							color: 'primary'
						}),
						label: _jsx(FormattedMessage, { defaultMessage: 'Compact' })
					}),
					_jsx(FormControl, {
						sx: { minWidth: 120, marginLeft: 'auto' },
						children: _jsx(Select, {
							value: showTypes,
							onChange: (event) => {
								setShowTypes(event.target.value);
							},
							slotProps: {
								input: {
									sx: {
										fontSize: '16px',
										border: 'none',
										background: 'none',
										'& > .MuiRadio-root': {
											display: 'none'
										}
									}
								}
							},
							MenuProps: {
								sx: {
									'& .MuiListItem-root': {
										padding: '0 10px',
										fontSize: '14px',
										'& > .MuiRadio-root': {
											padding: '6px',
											'& .MuiSvgIcon-root': {
												width: '16px',
												height: '16px'
											}
										}
									}
								},
								transformOrigin: {
									vertical: 'bottom',
									horizontal: 'left'
								}
							},
							children: Object.keys(assetsTypes).map((typeId) =>
								_jsxs(
									MenuItem,
									{
										value: typeId,
										children: [
											_jsx(Radio, { checked: showTypes === typeId, color: 'primary' }),
											assetsTypes[typeId].label
										]
									},
									typeId
								)
							)
						})
					})
				]
			})
		]
	});
}
export default DependenciesDialogUI;
