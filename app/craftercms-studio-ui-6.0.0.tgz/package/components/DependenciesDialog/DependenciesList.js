/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import { isImage } from '../../utils/content';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import ListItemText from '@mui/material/ListItemText';
import { assetsTypes } from './utils';
export function DependenciesList(props) {
	const { dependencies, compactView, showTypes, renderAction } = props;
	return _jsx(List, {
		sx: {
			backgroundColor: (theme) => theme.palette.background.paper,
			padding: 0,
			borderRadius: '5px 5px 0 0'
		},
		children: dependencies
			?.filter((dependency) => assetsTypes[showTypes].filter(dependency))
			.map((dependency, i) =>
				_jsxs(
					ListItem,
					{
						divider: dependencies.length - 1 !== i,
						sx: {
							padding: 0,
							height: compactView ? '43px' : '70px'
						},
						children: [
							isImage(dependency.path) &&
								!compactView &&
								_jsx(ListItemAvatar, {
									children: _jsx(Avatar, {
										sx: { width: '100px', height: '70px', borderRadius: 0 },
										src: dependency.path
									})
								}),
							_jsx(ListItemText, {
								sx: { paddingLeft: '15px' },
								primary: dependency.label,
								secondary: !compactView ? dependency.path : null
							}),
							!dependency.path.startsWith('/config/studio/content-types') && renderAction(dependency)
						]
					},
					dependency.path
				)
			)
	});
}
export default DependenciesList;
