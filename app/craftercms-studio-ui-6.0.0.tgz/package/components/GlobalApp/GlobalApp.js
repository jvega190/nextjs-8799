/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { lazy, Suspense, useEffect, useMemo, useState } from 'react';
import LauncherGlobalNav from '../LauncherGlobalNav';
import ResizeableDrawer from '../ResizeableDrawer/ResizeableDrawer';
import {
	createHashRouter,
	createRoutesFromElements,
	Navigate,
	Outlet,
	Route,
	RouterProvider,
	useLocation
} from 'react-router';
import SiteManagement from '../SiteManagement';
import { getLauncherSectionLink, urlMapping } from '../LauncherSection/utils';
import EmptyState from '../EmptyState/EmptyState';
import { FormattedMessage, useIntl } from 'react-intl';
import { useGlobalAppState } from './GlobalAppContext';
import Typography from '@mui/material/Typography';
import CrafterCMSLogo from '../../icons/CrafterCMSLogo';
import LoadingState from '../LoadingState/LoadingState';
import LauncherOpenerButton from '../LauncherOpenerButton';
import { useGlobalNavigation } from '../../hooks/useGlobalNavigation';
import GlobalAppToolbar from '../GlobalAppToolbar';
import Skeleton from '@mui/material/Skeleton';
import { globalMenuMessages } from '../../env/i18n-legacy';
import { GlobalRoutes } from '../../env/routes';
const routeWrapper = (module) => ({ ...module, Component: module.default });
// Site management loaded normally above as it is usually where people first land.
const UserManagement = lazy(() => import('../UserManagement/UserManagement'));
const GroupManagement = () => import('../GroupManagement/GroupManagement').then(routeWrapper);
const AuditManagement = () => import('../AuditManagement/AuditManagement').then(routeWrapper);
const LogLevelManagement = () => import('../LogLevelManagement/LogLevelManagement').then(routeWrapper);
const LogConsole = () => import('../LogConsole/LogConsole').then(routeWrapper);
const GlobalConfigManagement = () => import('../GlobalConfigManagement/GlobalConfigManagement').then(routeWrapper);
const EncryptTool = () => import('../EncryptTool/EncryptTool').then(routeWrapper);
const TokenManagement = () => import('../TokenManagement/TokenManagement').then(routeWrapper);
const AboutCrafterCMSView = () => import('../AboutCrafterCMSView/AboutCrafterCMSView').then(routeWrapper);
const AccountManagement = lazy(() => import('../AccountManagement/AccountManagement'));
export function GlobalApp(props) {
	const { passwordRequirementsMinComplexity } = props;
	const globalNavigation = useGlobalNavigation();
	if (!globalNavigation.items) {
		return _jsx(LoadingState, { sxs: { root: { height: '100%', margin: 0 } } });
	}
	const router = createHashRouter(
		createRoutesFromElements(
			_jsxs(Route, {
				path: '/',
				element: _jsx(GlobalAppInternal, { ...props }),
				children: [
					_jsx(Route, { path: GlobalRoutes.Projects, element: _jsx(SiteManagement, {}) }),
					_jsx(Route, { path: '/sites', element: _jsx(SiteManagement, {}) }),
					_jsx(Route, {
						path: GlobalRoutes.Users,
						element: _jsx(UserManagement, { passwordRequirementsMinComplexity: passwordRequirementsMinComplexity })
					}),
					_jsx(Route, { path: GlobalRoutes.Groups, lazy: GroupManagement }),
					_jsx(Route, { path: GlobalRoutes.Audit, lazy: AuditManagement }),
					_jsx(Route, { path: GlobalRoutes.LogLevel, lazy: LogLevelManagement }),
					_jsx(Route, { path: GlobalRoutes.LogConsole, lazy: LogConsole }),
					_jsx(Route, { path: GlobalRoutes.GlobalConfig, lazy: GlobalConfigManagement }),
					_jsx(Route, { path: GlobalRoutes.EncryptTool, lazy: EncryptTool }),
					_jsx(Route, { path: GlobalRoutes.TokenManagement, lazy: TokenManagement }),
					_jsx(Route, { path: GlobalRoutes.About, lazy: AboutCrafterCMSView }),
					_jsx(Route, {
						path: GlobalRoutes.Settings,
						element: _jsx(AccountManagement, { passwordRequirementsMinComplexity: passwordRequirementsMinComplexity })
					}),
					_jsx(Route, {
						path: '/',
						element: _jsx(Navigate, { to: `${urlMapping[globalNavigation.items[0].id].replace('#', '')}` })
					}),
					_jsx(Route, { path: '*', element: _jsx(RouteNotFound, {}) })
				]
			})
		)
	);
	return _jsx(RouterProvider, { router: router });
}
function RouteNotFound() {
	const { pathname } = useLocation();
	return _jsxs(Box, {
		display: 'flex',
		flexDirection: 'column',
		height: '100%',
		children: [
			_jsx(Box, { component: 'section', sx: { margin: '10px 12px 0 auto' }, children: _jsx(LauncherOpenerButton, {}) }),
			_jsx(EmptyState, {
				sxs: {
					root: {
						height: '100%',
						margin: 0
					}
				},
				title: '404',
				subtitle: _jsx(FormattedMessage, {
					id: 'globalApp.routeNotFound',
					defaultMessage: 'Route "{pathname}" not found',
					values: { pathname }
				})
			})
		]
	});
}
export function GlobalAppInternal(props) {
	const { footerHtml } = props;
	const [width, setWidth] = useState(240);
	const [{ openSidebar }] = useGlobalAppState();
	const { items } = useGlobalNavigation();
	const { formatMessage } = useIntl();
	const location = useLocation();
	const idByPathLookup = useMemo(
		() =>
			items?.reduce((lookup, item) => {
				lookup[getLauncherSectionLink(item.id, '').replace(/^#/, '')] = item.id;
				return lookup;
			}, {}),
		[items]
	);
	useEffect(() => {
		const path = location.pathname;
		const id = idByPathLookup?.[path];
		document.title = `CrafterCMS - ${formatMessage(
			globalMenuMessages[id] ?? {
				id: 'globalApp.routeNotFound',
				defaultMessage: 'Route not found'
			}
		)}`;
	}, [formatMessage, idByPathLookup, location.pathname]);
	return _jsxs(Paper, {
		sx: { height: '100vh', width: '100%' },
		elevation: 0,
		children: [
			_jsxs(ResizeableDrawer, {
				sxs: {
					drawerPaper: {
						top: '0',
						padding: 2
					},
					drawerBody: {
						height: '100%',
						display: 'flex',
						flexDirection: 'column',
						justifyContent: 'space-between'
					}
				},
				open: openSidebar,
				width: width,
				onWidthChange: setWidth,
				children: [
					_jsx(LauncherGlobalNav, {
						title: '',
						sectionSxs: {
							nav: {
								maxHeight: '100%',
								overflow: 'auto'
							}
						},
						tileSxs: {
							tile: {
								width: '100%',
								height: '35px',
								flexDirection: 'row',
								justifyContent: 'left',
								margin: '0 0 5px'
							},
							iconAvatar: {
								width: '25px',
								height: '25px',
								margin: '5px 10px'
							},
							title: {
								textAlign: 'left'
							}
						}
					}),
					_jsxs(Box, {
						component: 'footer',
						sx: { padding: '20px 0', textAlign: 'center' },
						children: [
							_jsx(CrafterCMSLogo, { width: 100, sxs: { root: { margin: '0 auto 10px auto' } } }),
							_jsx(Typography, {
								component: 'p',
								variant: 'caption',
								sx: (theme) => ({
									color: theme.palette.text.secondary,
									'& > a': {
										textDecoration: 'none',
										color: theme.palette.primary.main
									}
								}),
								dangerouslySetInnerHTML: { __html: footerHtml }
							})
						]
					})
				]
			}),
			_jsx(Box, {
				sx: (theme) => ({
					transition: theme.transitions.create('padding-left', {
						easing: theme.transitions.easing.easeOut,
						duration: theme.transitions.duration.enteringScreen
					})
				}),
				height: '100%',
				width: '100%',
				paddingLeft: openSidebar ? `${width}px` : 0,
				children: _jsx(Suspense, {
					fallback: _jsxs(_Fragment, {
						children: [
							_jsx(GlobalAppToolbar, { title: _jsx(Skeleton, { width: '140px' }) }),
							_jsx(Box, { display: 'flex', sx: { height: '100%' }, children: _jsx(LoadingState, {}) })
						]
					}),
					children: _jsx(Outlet, {})
				})
			})
		]
	});
}
export default GlobalApp;
