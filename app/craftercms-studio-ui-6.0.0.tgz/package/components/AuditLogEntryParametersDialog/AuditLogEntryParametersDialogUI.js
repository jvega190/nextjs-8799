/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { FormattedMessage } from 'react-intl';
import DialogBody from '../DialogBody/DialogBody';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import TableBody from '@mui/material/TableBody';
export function AuditLogEntryParametersDialogUI(props) {
	const { parameters = [] } = props;
	return _jsx(DialogBody, {
		children: _jsxs(Table, {
			children: [
				_jsx(TableHead, {
					children: _jsxs(TableRow, {
						children: [
							_jsx(TableCell, { children: _jsx(FormattedMessage, { id: 'words.id', defaultMessage: 'Id' }) }),
							_jsx(TableCell, {
								align: 'right',
								children: _jsx(FormattedMessage, { id: 'words.type', defaultMessage: 'Type' })
							}),
							_jsx(TableCell, {
								align: 'right',
								children: _jsx(FormattedMessage, { id: 'words.value', defaultMessage: 'Value' })
							})
						]
					})
				}),
				_jsx(TableBody, {
					children: parameters.map((logParameters) =>
						_jsxs(
							TableRow,
							{
								children: [
									_jsx(TableCell, { component: 'th', scope: 'row', children: logParameters.targetId }),
									_jsx(TableCell, { align: 'right', children: logParameters.targetType }),
									_jsx(TableCell, { align: 'right', children: logParameters.targetValue })
								]
							},
							logParameters.targetId
						)
					)
				})
			]
		})
	});
}
export default AuditLogEntryParametersDialogUI;
