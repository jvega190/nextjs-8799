/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { get } from '../utils/ajax';
import { toQueryString } from '../utils/object';
import { map } from 'rxjs/operators';
export function fetchAuditLog(options) {
	const mergedOptions = {
		limit: 100,
		offset: 0,
		...options
	};
	return get(`/studio/api/2/audit${toQueryString(mergedOptions)}`).pipe(
		map(({ response }) =>
			Object.assign(response.auditLog, {
				limit: response.limit < mergedOptions.limit ? mergedOptions.limit : response.limit,
				offset: response.offset,
				total: response.total
			})
		)
	);
}
export function fetchAuditLogEntry(id, siteId) {
	const qs = toQueryString({ siteId }, { skipNull: true });
	return get(`/studio/api/2/audit/${id}${qs}`).pipe(map((response) => response?.response?.auditLog));
}
