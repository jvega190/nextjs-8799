/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { get } from '../utils/ajax';
import { reversePluckProps, toQueryString } from '../utils/object';
import { map } from 'rxjs/operators';
import { createPagedArray } from '../utils/array';
import { prepareVirtualItemProps } from '../utils/content';
function parseDashletOptions(options) {
	const { sortBy, sortOrder, itemType } = options;
	return {
		...reversePluckProps(options, 'itemType', 'sortBy', 'sortOrder'),
		...(itemType && { itemType: itemType.join(',') }),
		...(sortBy && sortOrder && { sort: `${sortBy} ${sortOrder}` })
	};
}
export function fetchActivity(siteId, options) {
	const qs = toQueryString({ siteId, ...options }, { arrayFormat: 'comma' });
	return get(`/studio/api/2/dashboard/activity${qs}`).pipe(
		map(({ response: { activities, total, offset, limit } }) =>
			Object.assign(activities, {
				total,
				offset,
				limit
			})
		)
	);
}
export function fetchMyActivity(siteId, options) {
	const qs = toQueryString({ siteId, ...options });
	return get(`/studio/api/2/dashboard/activity/me${qs}`).pipe(
		map(({ response: { activities, total, offset, limit } }) =>
			Object.assign(activities, {
				total,
				offset,
				limit
			})
		)
	);
}
export function fetchPendingApproval(siteId, options) {
	const qs = toQueryString({ siteId, ...parseDashletOptions(options) });
	return get(`/studio/api/2/dashboard/content/pending_approval${qs}`).pipe(
		map(({ response }) =>
			createPagedArray(
				response.publishingItems.map((item) => prepareVirtualItemProps(item)),
				response
			)
		)
	);
}
export function fetchUnpublished(siteId, options) {
	const qs = toQueryString({ siteId, ...parseDashletOptions(options) });
	return get(`/studio/api/2/dashboard/content/unpublished${qs}`).pipe(
		map(({ response }) =>
			createPagedArray(
				response.unpublishedItems.map((item) => prepareVirtualItemProps(item)),
				response
			)
		)
	);
}
export function fetchScheduled(siteId, options) {
	const qs = toQueryString({ siteId, ...parseDashletOptions(options) });
	return get(`/studio/api/2/dashboard/publishing/scheduled${qs}`).pipe(
		map(({ response }) =>
			createPagedArray(
				response.publishingItems.map((item) => prepareVirtualItemProps(item)),
				response
			)
		)
	);
}
export function fetchScheduledPackageItems(siteId, packageId) {
	const qs = toQueryString({ siteId });
	return get(`/studio/api/2/dashboard/publishing/scheduled/${packageId}${qs}`).pipe(
		map((response) => response?.response?.publishingPackageItems.map((item) => prepareVirtualItemProps(item)))
	);
}
export function fetchPublishingHistory(siteId, options) {
	const qs = toQueryString({ siteId, ...options });
	return get(`/studio/api/2/dashboard/publishing/history${qs}`).pipe(
		map(({ response }) => createPagedArray(response.publishingPackages, response))
	);
}
export function fetchPublishingHistoryPackageItems(siteId, packageId, options) {
	const qs = toQueryString({ siteId, ...options });
	return get(`/studio/api/2/dashboard/publishing/history/${packageId}${qs}`).pipe(
		map(({ response }) =>
			createPagedArray(
				response.publishingPackageItems.map((item) => prepareVirtualItemProps(item)),
				response
			)
		)
	);
}
export function fetchExpired(siteId, options) {
	const qs = toQueryString({ siteId, ...options });
	return get(`/studio/api/2/dashboard/content/expired${qs}`).pipe(
		map((response) =>
			response?.response?.items.map((item) => ({
				...item,
				contentItem: prepareVirtualItemProps(item.sandboxItem)
			}))
		)
	);
}
export function fetchExpiring(siteId, options) {
	const qs = toQueryString({ siteId, ...options });
	return get(`/studio/api/2/dashboard/content/expiring${qs}`).pipe(
		map((response) =>
			response?.response?.items.map((item) => ({
				...item,
				contentItem: prepareVirtualItemProps(item.sandboxItem)
			}))
		)
	);
}
export function fetchPublishingStats(siteId, days) {
	const qs = toQueryString({ siteId, days });
	return get(`/studio/api/2/dashboard/publishing/stats${qs}`).pipe(
		map((response) => response?.response?.publishingStats)
	);
}
