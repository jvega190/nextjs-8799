/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
export const immutableEmptyArray = [];
export function forEach(array, fn, emptyReturnValue) {
	if (emptyReturnValue != null && array?.length === 0) {
		return emptyReturnValue;
	}
	for (let i = 0, l = array.length; i < l; i++) {
		const result = fn(array[i], i, array);
		if (result !== 'continue') {
			if (result === 'break') {
				break;
			} else if (result !== undefined) {
				return result;
			}
		}
	}
	return emptyReturnValue;
}
export function asArray(value) {
	return Boolean(value) ? (Array.isArray(value) ? value : [value]) : [];
}
export function createPresenceTable(list, valueOrGenerator = true, itemKeyGenerator = (value) => value) {
	const table = {};
	const callback =
		typeof valueOrGenerator === 'function'
			? (value) => (table[itemKeyGenerator(value)] = valueOrGenerator(value))
			: (value) => (table[itemKeyGenerator(value)] = valueOrGenerator);
	list.forEach(callback);
	return table;
}
/**
 * Receives two different arrays of string, it will combine it selecting one string of the first array
 * and then other string of the second array, until there are no more strings
 * @param a
 * @param b
 */
export function mergeArraysAlternatively(a, b) {
	return (a.length > b.length ? a : b).reduce(
		(acc, cur, i) => (a[i] && b[i] ? [...acc, a[i], b[i]] : [...acc, cur]),
		[]
	);
}
export function createPagedArray(array, response) {
	return Object.assign(array, {
		total: response.total,
		offset: response.offset,
		limit: response.limit
	});
}
export const areAllPairsEqual = (touples) => !touples.some(([a, b]) => a !== b);
