/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import { makeStyles } from 'tss-react/mui';
import palette from '../../styles/palette';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import { FormattedMessage } from 'react-intl';
import { useSelector } from 'react-redux';
const useStyles = makeStyles()(() => ({
  countContainer: {
    padding: '5px'
  },
  submissionCommentCount: {
    fontSize: '14px',
    color: palette.gray.medium4
  }
}));
function CharCountStatus(props) {
  const { classes } = useStyles();
  const { commentLength, commentMaxLength } = props;
  return _jsxs(Grid, {
    container: true,
    direction: 'row',
    justifyContent: 'space-between',
    className: classes.countContainer,
    children: [
      _jsx(Grid, {
        children: _jsx(Typography, {
          className: classes.submissionCommentCount,
          children: _jsx(FormattedMessage, {
            id: 'deleteDialog.maxCharacters',
            defaultMessage: 'Max {maxLength} characters',
            values: { maxLength: commentMaxLength }
          })
        })
      }),
      _jsx(Grid, {
        children: _jsxs(Typography, {
          className: classes.submissionCommentCount,
          children: [commentLength, '/', commentMaxLength]
        })
      })
    ]
  });
}
export function CharCountStatusContainer(props) {
  const { commentLength } = props;
  const commentMaxLength = useSelector((state) => state.uiConfig.publishing.submissionCommentMaxLength);
  return _jsx(CharCountStatus, { commentLength: commentLength, commentMaxLength: commentMaxLength });
}
export default CharCountStatus;
