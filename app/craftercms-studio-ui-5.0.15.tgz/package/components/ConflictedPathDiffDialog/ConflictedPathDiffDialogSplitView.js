/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useEffect, useRef } from 'react';
import { withMonaco } from '../../utils/system';
export function ConflictedPathDiffDialogSplitView(props) {
  const { diff, className } = props;
  const ref = useRef(undefined);
  useEffect(() => {
    if (diff) {
      withMonaco((monaco) => {
        const studioVersion = monaco.editor.createModel(diff.studioVersion, 'text/plain');
        const remoteVersion = monaco.editor.createModel(diff.remoteVersion, 'text/plain');
        const diffEditor = monaco.editor.createDiffEditor(ref.current, {
          scrollbar: {
            alwaysConsumeMouseWheel: false
          },
          readOnly: true,
          // Monaco editor has a breakpoint for split view, we had to decrease it for the split view to show in current dialog
          renderSideBySideInlineBreakpoint: 300
        });
        diffEditor.setModel({
          original: studioVersion,
          modified: remoteVersion
        });
      });
    }
  }, [diff]);
  return _jsx('div', { ref: ref, className: className });
}
export default ConflictedPathDiffDialogSplitView;
