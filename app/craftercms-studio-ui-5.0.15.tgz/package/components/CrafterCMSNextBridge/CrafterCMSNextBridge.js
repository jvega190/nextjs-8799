/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { Fragment, lazy, Suspense, useLayoutEffect, useState } from 'react';
import { setRequestForgeryToken } from '../../utils/auth';
import { getStore } from '../../state/store';
import { SnackbarProvider } from 'notistack';
import I18nProvider from '../I18nProvider';
import StoreProvider from '../StoreProvider';
import CrafterThemeProvider from '../CrafterThemeProvider';
import SnackbarCloseButton from '../SnackbarCloseButton';
import { publishCrafterGlobal } from '../../env/craftercms';
import { registerComponents } from '../../env/registerComponents';
import LoadingState from '../LoadingState';
import GlobalStyles from '../GlobalStyles';
import ErrorState from '../ErrorState/ErrorState';
import NotistackVariant from '../NotistackVariant';
import useSnackbarDuration from '../../hooks/useSnackbarDuration';
const LegacyConcierge = lazy(() => import('../LegacyConcierge/LegacyConcierge'));
const GlobalDialogManager = lazy(() => import('../GlobalDialogManager/GlobalDialogManager'));
export function CrafterCMSNextBridge(props) {
  const [store, setStore] = useState(null);
  const [storeError, setStoreError] = useState();
  const autoHideDuration = useSnackbarDuration();
  const {
    children,
    themeOptions,
    suspenseFallback = '',
    mountCssBaseline = true,
    mountGlobalDialogManager = true,
    mountSnackbarProvider = true,
    mountLegacyConcierge = false
  } = props;
  const SnackbarOrFragment = mountSnackbarProvider ? SnackbarProvider : Fragment;
  const snackbarOrFragmentProps = mountSnackbarProvider
    ? {
        maxSnack: 5,
        autoHideDuration,
        anchorOrigin: { vertical: 'bottom', horizontal: 'left' },
        action: (id) => _jsx(SnackbarCloseButton, { id: id }),
        Components: {
          error: NotistackVariant,
          success: NotistackVariant,
          warning: NotistackVariant,
          info: NotistackVariant
        }
      }
    : {};
  useLayoutEffect(() => {
    registerComponents();
    publishCrafterGlobal();
    setRequestForgeryToken();
    getStore().subscribe({
      next: (store) => setStore(store),
      error: (message) => setStoreError(message)
    });
  }, []);
  return _jsxs(CrafterThemeProvider, {
    themeOptions: themeOptions,
    children: [
      _jsx(I18nProvider, {
        children: _jsx(SnackbarOrFragment, {
          ...snackbarOrFragmentProps,
          children: storeError
            ? _jsx(ErrorState, {
                title: storeError,
                imageUrl: '/studio/static-assets/images/warning_state.svg',
                styles: { title: { textAlign: 'center' }, image: { width: 250, marginBottom: 10, marginTop: 10 } }
              })
            : store
              ? _jsxs(StoreProvider, {
                  store: store,
                  children: [
                    _jsx(Suspense, { fallback: suspenseFallback, children: children }),
                    mountGlobalDialogManager &&
                      _jsx(Suspense, { fallback: '', children: _jsx(GlobalDialogManager, {}) }),
                    mountLegacyConcierge && _jsx(Suspense, { fallback: '', children: _jsx(LegacyConcierge, {}) })
                  ]
                })
              : _jsx(LoadingState, {})
        })
      }),
      _jsx(GlobalStyles, { cssBaseline: mountCssBaseline })
    ]
  });
}
export default CrafterCMSNextBridge;
