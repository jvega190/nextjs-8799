/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
import { CopyDialogBody } from './CopyDialogBody';
import EnhancedDialog from '../EnhancedDialog/EnhancedDialog';
import { messages } from './utils';
import { useIntl } from 'react-intl';
export function CopyDialog(props) {
  const { item, site, onOk, ...rest } = props;
  const { formatMessage } = useIntl();
  return _jsx(EnhancedDialog, {
    ...rest,
    dialogHeaderProps: {
      title: formatMessage(messages.copyDialogTitle),
      subtitle: formatMessage(messages.copyDialogSubtitle)
    },
    children: _jsx(CopyDialogBody, {
      item: item,
      site: site,
      onOk: onOk,
      onClose: props.onClose,
      disabled: props.isSubmitting
    })
  });
}
export default CopyDialog;
