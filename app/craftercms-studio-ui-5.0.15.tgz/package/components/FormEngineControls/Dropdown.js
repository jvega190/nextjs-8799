/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import useStyles from './styles';
import usePossibleTranslation from '../../hooks/usePossibleTranslation';
import { useIntl } from 'react-intl';
import { getPossibleTranslation } from '../../utils/i18n';
export function Dropdown(props) {
  const { field, value = '', onChange, disabled } = props;
  const { classes } = useStyles();
  const label = usePossibleTranslation(field.name);
  const { formatMessage } = useIntl();
  const handleSelectChange = (event) => {
    onChange(event.target.value);
  };
  return _jsxs(FormControl, {
    variant: 'outlined',
    className: classes.formControl,
    fullWidth: true,
    children: [
      _jsx(InputLabel, { id: `labelFor_${field.id}`, children: label }),
      _jsx(Select, {
        labelId: `labelFor_${field.id}`,
        id: `select_${field.id}`,
        label: label,
        fullWidth: true,
        value: value,
        onChange: handleSelectChange,
        disabled: disabled,
        children: field.values?.map((possibleValue) =>
          _jsx(
            MenuItem,
            { value: possibleValue.value, children: getPossibleTranslation(possibleValue.label, formatMessage) },
            possibleValue.value
          )
        )
      })
    ]
  });
}
export default Dropdown;
