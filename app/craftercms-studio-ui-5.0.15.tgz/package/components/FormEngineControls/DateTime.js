/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import DateTimeTimezonePicker from '../DateTimeTimezonePicker/DateTimeTimezonePicker';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import useStyles from './styles';
import { useSelection } from '../../hooks/useSelection';
import usePossibleTranslation from '../../hooks/usePossibleTranslation';
export function DateTime(props) {
  const { field, value, onChange, disabled } = props;
  const { classes } = useStyles();
  const locale = useSelection((state) => state.uiConfig.locale);
  const label = usePossibleTranslation(field.name);
  return _jsxs(FormControl, {
    variant: 'outlined',
    className: classes.formControl,
    fullWidth: true,
    children: [
      _jsx(InputLabel, {
        className: classes.inputLabel,
        sx: { position: 'relative', transform: 'none' },
        htmlFor: field.id,
        children: label
      }),
      _jsx(DateTimeTimezonePicker, {
        id: field.id,
        value: value,
        onChange: onChange,
        disabled: disabled,
        localeCode: locale.localeCode,
        dateTimeFormatOptions: locale.dateTimeFormatOptions
      })
    ]
  });
}
export default DateTime;
