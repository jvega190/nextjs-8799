/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import DashletCard from '../DashletCard/DashletCard';
import palette from '../../styles/palette';
import { FormattedMessage } from 'react-intl';
import { useEffect, useMemo, useState } from 'react';
import useSpreadState from '../../hooks/useSpreadState';
import useActiveSiteId from '../../hooks/useActiveSiteId';
import { fetchPublishingStats } from '../../services/dashboard';
import Skeleton from '@mui/material/Skeleton';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import { contentEvent, deleteContentEvent, publishEvent, workflowEvent } from '../../state/actions/system';
import { getHostToHostBus } from '../../utils/subjects';
import { filter } from 'rxjs/operators';
function DevContentOpsStats(props) {
  const { stats, sx } = props;
  return _jsx(_Fragment, {
    children:
      stats &&
      _jsxs(Stack, {
        direction: 'row',
        spacing: 2,
        sx: sx?.root,
        children: [
          _jsxs(Box, {
            children: [
              _jsx(Typography, {
                component: 'span',
                children: stats.numberOfPublishes,
                lineHeight: 1,
                sx: { fontWeight: (theme) => theme.typography.fontWeightMedium }
              }),
              ' ',
              _jsx(Typography, { component: 'span', children: _jsx(FormattedMessage, { defaultMessage: 'Publishes' }) })
            ]
          }),
          _jsxs(Box, {
            children: [
              _jsx(Typography, {
                component: 'span',
                children: stats.numberOfNewAndPublishedItems,
                lineHeight: 1,
                sx: { fontWeight: (theme) => theme.typography.fontWeightMedium }
              }),
              ' ',
              _jsx(Typography, {
                component: 'span',
                children: _jsx(FormattedMessage, { defaultMessage: 'Created & Published' })
              })
            ]
          }),
          _jsxs(Box, {
            children: [
              _jsx(Typography, {
                component: 'span',
                children: stats.numberOfEditedAndPublishedItems,
                lineHeight: 1,
                sx: { fontWeight: (theme) => theme.typography.fontWeightMedium }
              }),
              ' ',
              _jsx(Typography, {
                component: 'span',
                children: _jsx(FormattedMessage, { defaultMessage: 'Edited & Published' })
              })
            ]
          })
        ]
      })
  });
}
export function DevContentOpsDashlet(props) {
  const { borderLeftColor = palette.teal.main } = props;
  const site = useActiveSiteId();
  const [{ stats, loading }, setState] = useSpreadState({
    stats: null,
    loading: false
  });
  const [days, setDays] = useState(30);
  const onRefresh = useMemo(
    () => (backgroundRefresh) => {
      if (!backgroundRefresh) {
        setState({ stats: null, loading: true });
      }
      fetchPublishingStats(site, days).subscribe((stats) => {
        setState({ stats, loading: false });
      });
    },
    [site, setState, days]
  );
  useEffect(() => {
    onRefresh();
  }, [onRefresh]);
  // region Item Updates Propagation
  useEffect(() => {
    const events = [deleteContentEvent.type, workflowEvent.type, publishEvent.type, contentEvent.type];
    const hostToHost$ = getHostToHostBus();
    const subscription = hostToHost$.pipe(filter((e) => events.includes(e.type))).subscribe(({ type, payload }) => {
      onRefresh(true);
    });
    return () => {
      subscription.unsubscribe();
    };
  }, [onRefresh]);
  // endregion
  return _jsxs(DashletCard, {
    ...props,
    sxs: { content: { pt: 2, pb: (theme) => `${theme.spacing(2)} !important` }, ...props.sxs },
    borderLeftColor: borderLeftColor,
    children: [
      _jsxs(_Fragment, {
        children: [
          _jsxs(Box, {
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            children: [
              _jsx(Typography, {
                variant: 'h6',
                children: _jsx(FormattedMessage, {
                  id: 'devContentOpsDashlet.widgetTitle',
                  defaultMessage: 'DevContentOps'
                })
              }),
              _jsx(DevContentOpsStats, { stats: stats, sx: { root: { ml: 2, display: { xs: 'none', lg: 'flex' } } } }),
              _jsxs(Select, {
                variant: 'standard',
                disableUnderline: true,
                value: days,
                onChange: (e) => setDays(e.target.value),
                SelectDisplayProps: { style: { paddingLeft: '8px' } },
                children: [
                  _jsx(MenuItem, {
                    value: 3,
                    children: _jsx(FormattedMessage, { defaultMessage: '{days} days', values: { days: 3 } })
                  }),
                  _jsx(MenuItem, {
                    value: 7,
                    children: _jsx(FormattedMessage, { defaultMessage: '{days} days', values: { days: 7 } })
                  }),
                  _jsx(MenuItem, {
                    value: 30,
                    children: _jsx(FormattedMessage, {
                      defaultMessage: '{months} {months, plural, one {month} other {months}}',
                      values: { months: 1 }
                    })
                  }),
                  _jsx(MenuItem, {
                    value: 90,
                    children: _jsx(FormattedMessage, {
                      defaultMessage: '{months} {months, plural, one {month} other {months}}',
                      values: { months: 3 }
                    })
                  }),
                  _jsx(MenuItem, {
                    value: 365,
                    children: _jsx(FormattedMessage, {
                      defaultMessage: '{years} {years, plural, one {year} other {years}}',
                      values: { years: 1 }
                    })
                  })
                ]
              })
            ]
          }),
          _jsx(DevContentOpsStats, { stats: stats, sx: { root: { mt: 1, display: { lg: 'none' } } } })
        ]
      }),
      loading && _jsx(Skeleton, {})
    ]
  });
}
export default DevContentOpsDashlet;
