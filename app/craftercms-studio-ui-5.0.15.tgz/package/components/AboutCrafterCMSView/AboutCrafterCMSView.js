/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import GlobalAppToolbar from '../GlobalAppToolbar';
import { FormattedMessage } from 'react-intl';
import Paper from '@mui/material/Paper';
import useStyles from './styles';
import CrafterCMSLogo from '../../icons/CrafterCMSLogo';
import Box from '@mui/material/Box';
import Link from '@mui/material/Link';
import Typography from '@mui/material/Typography';
import { useSelection } from '../../hooks/useSelection';
import { useEnv } from '../../hooks/useEnv';
export function AboutCrafterCMSView() {
  const env = useEnv();
  const { classes } = useStyles();
  const localeBranch = useSelection((state) => state.uiConfig.locale);
  return _jsx(Paper, {
    elevation: 0,
    children: _jsxs(Box, {
      display: 'flex',
      flexDirection: 'column',
      height: 'calc(100vh - 215px)',
      children: [
        _jsx(GlobalAppToolbar, { title: _jsx(FormattedMessage, { id: 'global.about', defaultMessage: 'About' }) }),
        _jsx(Box, {
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexGrow: [1],
          children: _jsxs(Paper, {
            className: classes.paperRoot,
            children: [
              _jsx(CrafterCMSLogo, { width: 250, className: classes.logo }),
              _jsxs('div', {
                className: classes.row,
                children: [
                  _jsxs(Typography, {
                    variant: 'subtitle2',
                    className: 'aboutLabel',
                    children: [
                      _jsx(FormattedMessage, { id: 'about.versionNumber', defaultMessage: 'Version Number' }),
                      ':'
                    ]
                  }),
                  _jsx(Typography, {
                    variant: 'body2',
                    children: `${env.packageVersion}-${env.packageBuild?.substring(0, 6)}`
                  })
                ]
              }),
              _jsxs('div', {
                className: classes.row,
                children: [
                  _jsxs(Typography, {
                    variant: 'subtitle2',
                    className: 'aboutLabel',
                    children: [_jsx(FormattedMessage, { id: 'about.buildNumber', defaultMessage: 'Build Number' }), ':']
                  }),
                  _jsx(Typography, { variant: 'body2', children: env.packageBuild })
                ]
              }),
              _jsxs('div', {
                className: classes.row,
                children: [
                  _jsxs(Typography, {
                    variant: 'subtitle2',
                    className: 'aboutLabel',
                    children: [_jsx(FormattedMessage, { id: 'about.buildDate', defaultMessage: 'Build Date' }), ':']
                  }),
                  _jsx(Typography, {
                    variant: 'body2',
                    children: new Intl.DateTimeFormat(
                      localeBranch.localeCode,
                      localeBranch.dateTimeFormatOptions
                    ).format(new Date(env.packageBuildDate))
                  })
                ]
              }),
              _jsx('div', {
                className: classes.externalLink,
                children: _jsx(Typography, {
                  variant: 'body2',
                  children: _jsx(FormattedMessage, {
                    id: 'aboutView.attribution',
                    defaultMessage: 'CrafterCMS is made possible by these other <a>open source software projects</a>.',
                    values: {
                      a: (msg) =>
                        _jsx(Link, {
                          href: `https://craftercms.com/docs/current/contribute/acknowledgements.html`,
                          target: '_blank',
                          children: msg
                        })
                    }
                  })
                })
              })
            ]
          })
        })
      ]
    })
  });
}
export default AboutCrafterCMSView;
