/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useState } from 'react';
import { makeStyles } from 'tss-react/mui';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import palette from '../../styles/palette';
const useStyles = makeStyles()(() => ({
  menu: {
    padding: '5px 10px'
  },
  openMenuBtn: {
    fontSize: '16px'
  },
  openMenuBtnIcon: {
    fontSize: '24px',
    marginLeft: '5px',
    paddingTop: '2px',
    fill: palette.gray.medium4
  },
  radioGroup: {
    '&:focus': {
      outline: 0
    }
  }
}));
export function ContentTypesFilter(props) {
  const { onFilterChange, selected, disabled, filters } = props;
  const { classes } = useStyles();
  const [anchorEl, setAnchorEl] = useState(null);
  const filter = filters.find((filter) => filter.type === selected);
  const onMenuClose = () => setAnchorEl(null);
  const onMenuOpen = (e) => setAnchorEl(e.currentTarget);
  const onChange = (e) => {
    onFilterChange(e.target.value);
    onMenuClose();
  };
  return _jsxs(_Fragment, {
    children: [
      _jsxs(Button, {
        disabled: disabled,
        onClick: onMenuOpen,
        className: classes.openMenuBtn,
        children: [filter.label, _jsx(ArrowDropDownIcon, { className: classes.openMenuBtnIcon })]
      }),
      _jsx(Menu, {
        anchorEl: anchorEl,
        keepMounted: true,
        open: Boolean(anchorEl),
        onClose: onMenuClose,
        classes: { paper: classes.menu },
        anchorOrigin: {
          vertical: 'bottom',
          horizontal: 'right'
        },
        transformOrigin: {
          vertical: 'bottom',
          horizontal: 'right'
        },
        children: _jsx(RadioGroup, {
          value: selected,
          onChange: onChange,
          className: classes.radioGroup,
          children: filters.map((filter) =>
            _jsx(
              FormControlLabel,
              { value: filter.type, control: _jsx(Radio, { color: 'primary' }), label: filter.label },
              filter.type
            )
          )
        })
      })
    ]
  });
}
export default ContentTypesFilter;
