/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useState } from 'react';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Radio from '@mui/material/Radio';
import Collapse from '@mui/material/Collapse';
import { defineMessages, FormattedMessage, useIntl } from 'react-intl';
import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import { makeStyles } from 'tss-react/mui';
import Typography from '@mui/material/Typography';
const useStyles = makeStyles()((theme) => ({
  authBox: {
    padding: '10px',
    background: theme.palette.background.paper,
    borderRadius: '5px',
    marginLeft: '30px',
    display: 'flex',
    justifyContent: 'center'
  },
  margin: {
    margin: theme.spacing(1)
  },
  textField: {
    width: '100%'
  }
}));
const messages = defineMessages({
  userName: {
    id: 'words.userName',
    defaultMessage: 'Username'
  },
  password: {
    id: 'words.password',
    defaultMessage: 'Password'
  },
  token: {
    id: 'words.token',
    defaultMessage: 'Token'
  },
  privateKey: {
    id: 'gitAuthForm.privateKey',
    defaultMessage: 'Private Key'
  }
});
function renderHelperText(name, value = '', helperText, required, submitted) {
  if (required && !value && submitted) {
    return _jsx(FormattedMessage, { id: 'gitForm.required', defaultMessage: '{name} is required.', values: { name } });
  } else {
    return helperText;
  }
}
function AuthFields(props) {
  const { inputs, handleInputChange, onKeyPress } = props;
  const type = inputs.repoAuthentication;
  const [showPassword, setShowPassword] = useState(false);
  const { formatMessage } = useIntl();
  const { classes, cx } = useStyles();
  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };
  return _jsxs('div', {
    className: classes.authBox,
    children: [
      (type === 'basic' || type === 'token') &&
        _jsx(TextField, {
          id: 'repoUsername',
          name: 'repoUsername',
          'data-field-id': 'repoUsername',
          className: cx(classes.margin, classes.textField),
          label: formatMessage(messages.userName),
          required: true,
          autoFocus: true,
          value: inputs.repoUsername,
          onKeyPress: onKeyPress,
          onChange: handleInputChange,
          error: inputs.submitted && !inputs.repoUsername,
          helperText: renderHelperText(
            formatMessage(messages.userName),
            inputs.repoUsername,
            '',
            true,
            inputs.submitted
          )
        }),
      type === 'basic' &&
        _jsx(TextField, {
          id: 'repoPassword',
          name: 'repoPassword',
          'data-field-id': 'repoPassword',
          className: cx(classes.margin, classes.textField),
          type: showPassword ? 'text' : 'password',
          label: formatMessage(messages.password),
          required: true,
          value: inputs.repoPassword,
          onKeyPress: onKeyPress,
          onChange: handleInputChange,
          error: inputs.submitted && !inputs.repoPassword,
          helperText: renderHelperText(
            formatMessage(messages.password),
            inputs.repoPassword,
            '',
            true,
            inputs.submitted
          ),
          slotProps: {
            input: {
              endAdornment: _jsx(InputAdornment, {
                position: 'end',
                children: _jsx(IconButton, {
                  edge: 'end',
                  'aria-label': 'toggle password visibility',
                  onClick: handleClickShowPassword,
                  size: 'large',
                  children: showPassword ? _jsx(VisibilityOff, {}) : _jsx(Visibility, {})
                })
              })
            }
          }
        }),
      type === 'token' &&
        _jsx(TextField, {
          id: 'repoToken',
          name: 'repoToken',
          'data-field-id': 'repoToken',
          className: cx(classes.margin, classes.textField),
          type: showPassword ? 'text' : 'password',
          label: formatMessage(messages.token),
          required: true,
          value: inputs.repoToken,
          error: inputs.submitted && !inputs.repoToken,
          helperText: renderHelperText(formatMessage(messages.token), inputs.repoToken, '', true, inputs.submitted),
          onKeyPress: onKeyPress,
          onChange: handleInputChange,
          slotProps: {
            input: {
              endAdornment: _jsx(InputAdornment, {
                position: 'end',
                children: _jsx(IconButton, {
                  edge: 'end',
                  'aria-label': 'toggle password visibility',
                  onClick: handleClickShowPassword,
                  size: 'large',
                  children: showPassword ? _jsx(VisibilityOff, {}) : _jsx(Visibility, {})
                })
              })
            }
          }
        }),
      type === 'key' &&
        _jsx(TextField, {
          id: 'repoKey',
          name: 'repoKey',
          'data-field-id': 'repoKey',
          label: formatMessage(messages.privateKey),
          required: true,
          fullWidth: true,
          multiline: true,
          className: classes.margin,
          error: inputs.submitted && !inputs.repoKey,
          helperText: renderHelperText(formatMessage(messages.privateKey), inputs.repoKey, '', true, inputs.submitted),
          onKeyPress: onKeyPress,
          onChange: handleInputChange,
          value: inputs.repoKey
        })
    ]
  });
}
export function GitAuthForm(props) {
  const { inputs, setInputs, handleInputChange, onKeyPress } = props;
  const viewAuth = (type) => {
    const _expanded = { ...inputs.expanded };
    Object.keys(inputs.expanded).map((key) => {
      if (key === type) {
        return (_expanded[key] = !_expanded[key]);
      }
      return (_expanded[key] = false);
    });
    setInputs({ ...inputs, expanded: _expanded });
  };
  return _jsxs(_Fragment, {
    children: [
      _jsx(Typography, {
        variant: 'subtitle1',
        color: 'textSecondary',
        children: _jsx(FormattedMessage, { id: 'words.authentication', defaultMessage: 'Authentication' })
      }),
      _jsxs(RadioGroup, {
        'aria-label': 'repoAuthentication',
        name: 'repoAuthentication',
        value: inputs.repoAuthentication,
        onChange: handleInputChange,
        onKeyPress: onKeyPress,
        children: [
          _jsx(FormControlLabel, {
            value: 'none',
            control: _jsx(Radio, { onChange: () => viewAuth('none') }),
            label: _jsx(FormattedMessage, {
              id: 'gitForm.noAuthenticationRequired',
              defaultMessage: 'Authentication not required (public URL)'
            })
          }),
          _jsx(FormControlLabel, {
            value: 'basic',
            control: _jsx(Radio, { onChange: () => viewAuth('basic') }),
            label: _jsx(FormattedMessage, { id: 'gitForm.usernameAndPassword', defaultMessage: 'Username & Password' })
          }),
          _jsx(Collapse, {
            in: inputs.expanded.basic,
            timeout: 300,
            unmountOnExit: true,
            children: _jsx(AuthFields, { inputs: inputs, handleInputChange: handleInputChange })
          }),
          _jsx(FormControlLabel, {
            value: 'token',
            control: _jsx(Radio, { onChange: () => viewAuth('token') }),
            label: _jsx(FormattedMessage, { id: 'gitForm.token', defaultMessage: 'Token' })
          }),
          _jsx(Collapse, {
            in: inputs.expanded.token,
            timeout: 300,
            unmountOnExit: true,
            children: _jsx(AuthFields, { inputs: inputs, handleInputChange: handleInputChange })
          }),
          _jsx(FormControlLabel, {
            value: 'key',
            control: _jsx(Radio, { onChange: () => viewAuth('key') }),
            label: _jsx(FormattedMessage, { id: 'gitForm.privateKey', defaultMessage: 'Private Key' })
          }),
          _jsx(Collapse, {
            in: inputs.expanded.key,
            timeout: 300,
            unmountOnExit: true,
            children: _jsx(AuthFields, { inputs: inputs, handleInputChange: handleInputChange })
          })
        ]
      })
    ]
  });
}
export default GitAuthForm;
