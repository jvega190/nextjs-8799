/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
import { makeStyles } from 'tss-react/mui';
import { FormattedMessage } from 'react-intl';
import { SelectionList } from './SelectionList';
import { nnou } from '../../utils/object';
// region useStyles
const useStyles = makeStyles()((theme) => ({
  dependencySelection: {
    background: theme.palette.background.paper,
    border: `1px solid ${theme.palette.divider}`,
    minHeight: '374px'
  },
  dependencySelectionDisabled: {
    opacity: 0.7
  },
  showAllBtn: {
    marginLeft: 0,
    verticalAlign: 'baseline'
  },
  listItemTitle: {
    '& h4': {
      fontSize: '1rem',
      margin: 0,
      padding: 0,
      fontWeight: 400
    }
  },
  listItemPath: {
    padding: 0
  }
}));
// endregion
export function DependencySelection(props) {
  const {
    items,
    selectedItems,
    dependencies,
    onItemClicked,
    onSelectAllClicked,
    onSelectAllSoftClicked,
    disabled = false
  } = props;
  const { classes, cx } = useStyles();
  return _jsx(_Fragment, {
    children: _jsxs('div', {
      className: cx(classes.dependencySelection, disabled && classes.dependencySelectionDisabled),
      children: [
        _jsx(SelectionList, {
          title: _jsx(FormattedMessage, { id: 'publishDialog.itemsToPublish', defaultMessage: 'Items To Publish' }),
          items: items,
          onItemClicked: onItemClicked,
          onSelectAllClicked: onSelectAllClicked,
          displayItemTitle: true,
          selectedItems: selectedItems,
          disabled: disabled
        }),
        nnou(dependencies) &&
          _jsxs(_Fragment, {
            children: [
              _jsx(SelectionList, {
                title: _jsx(FormattedMessage, {
                  id: 'publishDialog.hardDependencies',
                  defaultMessage: 'Hard Dependencies'
                }),
                subtitle: _jsx(FormattedMessage, {
                  id: 'publishDialog.submissionMandatory',
                  defaultMessage: 'Submission Mandatory'
                }),
                emptyMessage: _jsx(FormattedMessage, {
                  id: 'publishDialog.emptyHardDependencies',
                  defaultMessage: 'No hard dependencies'
                }),
                paths: dependencies.hardDependencies ?? [],
                displayItemTitle: false,
                disabled: disabled
              }),
              _jsx(SelectionList, {
                title: _jsx(FormattedMessage, {
                  id: 'publishDialog.softDependencies',
                  defaultMessage: 'Soft Dependencies'
                }),
                subtitle: _jsx(FormattedMessage, {
                  id: 'publishDialog.submissionOptional',
                  defaultMessage: 'Submission Optional'
                }),
                emptyMessage: _jsx(FormattedMessage, {
                  id: 'publishDialog.emptySoftDependencies',
                  defaultMessage: 'No soft dependencies'
                }),
                paths: dependencies.softDependencies ?? [],
                onItemClicked: onItemClicked,
                onSelectAllClicked: onSelectAllSoftClicked,
                displayItemTitle: false,
                selectedItems: selectedItems,
                disabled: disabled
              })
            ]
          })
      ]
    })
  });
}
export default DependencySelection;
