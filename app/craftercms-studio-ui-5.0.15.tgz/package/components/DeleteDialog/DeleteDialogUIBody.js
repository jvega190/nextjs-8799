/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
import { useDeleteDialogUIStyles } from './styles';
import Grid from '@mui/material/Grid';
import TextFieldWithMax from '../TextFieldWithMax/TextFieldWithMax';
import { FormattedMessage } from 'react-intl';
import { SelectionList } from '../DependencySelection/SelectionList';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import Alert from '@mui/material/Alert';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import Typography from '@mui/material/Typography';
import List from '@mui/material/List';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import InfoIcon from '@mui/icons-material/InfoOutlined';
export function DeleteDialogUIBody(props) {
  const {
    items,
    childItems,
    dependentItems,
    comment,
    selectedItems,
    isCommentRequired = false,
    isDisabled,
    isConfirmDeleteChecked,
    onCommentChange,
    onItemClicked,
    onSelectAllClicked,
    onConfirmDeleteChange,
    onEditDependantClick
  } = props;
  const { classes } = useDeleteDialogUIStyles();
  return _jsxs(Grid, {
    container: true,
    spacing: 3,
    children: [
      _jsx(Grid, {
        size: { xs: 12, sm: 7 },
        children: _jsxs('div', {
          className: classes.depsContainer,
          children: [
            _jsx(SelectionList, {
              title: _jsx(FormattedMessage, { id: 'deleteDialog.deleteItems', defaultMessage: 'Delete Items' }),
              items: items,
              onItemClicked: onItemClicked,
              onSelectAllClicked: onSelectAllClicked,
              displayItemTitle: true,
              selectedItems: selectedItems,
              disabled: isDisabled
            }),
            _jsx(ListItem, {
              divider: true,
              dense: true,
              disableGutters: !Boolean(dependentItems),
              children: _jsx(ListItemText, {
                primary: _jsxs(Typography, {
                  variant: 'subtitle1',
                  component: 'span',
                  children: [
                    _jsx(FormattedMessage, { id: 'deleteDialog.dependentItems', defaultMessage: 'Dependent Items' }),
                    ` • `,
                    _jsx(FormattedMessage, {
                      id: 'deleteDialog.brokenItems',
                      defaultMessage: 'Will have broken references'
                    })
                  ]
                })
              })
            }),
            dependentItems.length
              ? _jsx(List, {
                  children: dependentItems.map((path) => {
                    return _jsx(
                      ListItem,
                      {
                        dense: true,
                        secondaryAction: _jsx(Button, {
                          color: 'primary',
                          onClick: (e) => onEditDependantClick(e, path),
                          size: 'small',
                          sx: {
                            marginLeft: 'auto',
                            fontWeight: 'bold',
                            verticalAlign: 'baseline'
                          },
                          children: _jsx(FormattedMessage, { id: 'words.edit', defaultMessage: 'Edit' })
                        }),
                        children: _jsx(ListItemText, {
                          primary: path,
                          slotProps: {
                            primary: {
                              title: path,
                              sx: {
                                overflow: 'hidden',
                                whiteSpace: 'nowrap',
                                textOverflow: 'ellipsis'
                              }
                            }
                          }
                        })
                      },
                      path
                    );
                  })
                })
              : _jsxs(Box, {
                  sx: {
                    display: 'flex',
                    alignItems: 'center',
                    padding: '8px',
                    '& svg': {
                      marginRight: '8px'
                    }
                  },
                  children: [
                    _jsx(InfoIcon, { color: 'action', fontSize: 'small' }),
                    _jsx(Typography, {
                      variant: 'caption',
                      children: _jsx(FormattedMessage, {
                        id: 'deleteDialog.emptyDependentItems',
                        defaultMessage: 'No dependent items'
                      })
                    })
                  ]
                }),
            _jsx(SelectionList, {
              title: _jsx(FormattedMessage, { id: 'deleteDialog.childItemsText', defaultMessage: 'Child Items' }),
              subtitle: _jsx(FormattedMessage, {
                id: 'deleteDialog.willGetDeleted',
                defaultMessage: 'Will get deleted'
              }),
              emptyMessage: _jsx(FormattedMessage, {
                id: 'deleteDialog.emptyChildItems',
                defaultMessage: 'No child items'
              }),
              paths: childItems,
              displayItemTitle: false
            })
          ]
        })
      }),
      _jsx(Grid, {
        size: { xs: 12, sm: 5 },
        children: _jsxs('form', {
          className: classes.submissionCommentField,
          noValidate: true,
          autoComplete: 'off',
          children: [
            _jsx(TextFieldWithMax, {
              label: _jsx(FormattedMessage, {
                id: 'deleteDialog.submissionCommentLabel',
                defaultMessage: 'Submission Comment'
              }),
              multiline: true,
              value: comment,
              onChange: onCommentChange,
              required: isCommentRequired,
              disabled: isDisabled
            }),
            _jsx(Alert, {
              severity: 'warning',
              icon: false,
              children: _jsx(FormControlLabel, {
                className: classes.confirmCheck,
                control: _jsx(Checkbox, {
                  color: 'primary',
                  checked: isConfirmDeleteChecked,
                  onChange: onConfirmDeleteChange,
                  disabled: isDisabled
                }),
                label: _jsx(FormattedMessage, {
                  id: 'deleteDialog.confirmDeletion',
                  defaultMessage: 'I understand that deleted items will be published immediately.'
                })
              })
            })
          ]
        })
      })
    ]
  });
}
export default DeleteDialogUIBody;
