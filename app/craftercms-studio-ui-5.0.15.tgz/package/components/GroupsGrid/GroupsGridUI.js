/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import Typography from '@mui/material/Typography';
import { FormattedMessage } from 'react-intl';
import TableBody from '@mui/material/TableBody';
import Pagination from '../Pagination';
import { useStyles } from './styles';
import GlobalAppGridRow from '../GlobalAppGridRow';
import GlobalAppGridCell from '../GlobalAppGridCell';
import Box from '@mui/material/Box';
export function GroupsGridUI(props) {
  const { groups, onRowClicked, onPageChange, onRowsPerPageChange } = props;
  const { classes } = useStyles();
  return _jsxs(Box, {
    display: 'flex',
    flexDirection: 'column',
    children: [
      _jsx(TableContainer, {
        children: _jsxs(Table, {
          className: classes.tableRoot,
          children: [
            _jsx(TableHead, {
              children: _jsxs(GlobalAppGridRow, {
                className: 'hoverDisabled',
                children: [
                  _jsx(GlobalAppGridCell, {
                    align: 'left',
                    className: 'width25',
                    children: _jsx(Typography, {
                      variant: 'subtitle2',
                      children: _jsx(FormattedMessage, { id: 'words.name', defaultMessage: 'Name' })
                    })
                  }),
                  _jsx(GlobalAppGridCell, {
                    align: 'left',
                    children: _jsx(Typography, {
                      variant: 'subtitle2',
                      children: _jsx(FormattedMessage, { id: 'words.description', defaultMessage: 'Description' })
                    })
                  })
                ]
              })
            }),
            _jsx(TableBody, {
              children: groups.map((group, i) =>
                _jsxs(
                  GlobalAppGridRow,
                  {
                    onClick: () => onRowClicked(group),
                    children: [
                      _jsx(GlobalAppGridCell, {
                        align: 'left',
                        className: 'width25',
                        children: _jsx(Typography, {
                          variant: 'body2',
                          noWrap: true,
                          title: group.name,
                          children: group.name
                        })
                      }),
                      _jsx(GlobalAppGridCell, {
                        align: 'left',
                        children: _jsx(Typography, {
                          variant: 'body2',
                          className: classes.groupDescription,
                          children: group.desc
                        })
                      })
                    ]
                  },
                  group.id
                )
              )
            })
          ]
        })
      }),
      _jsx(Pagination, {
        mode: 'table',
        count: groups.total,
        rowsPerPage: groups.limit,
        page: groups && Math.ceil(groups.offset / groups.limit),
        onPageChange: (e, page) => onPageChange(page),
        onRowsPerPageChange: onRowsPerPageChange
      })
    ]
  });
}
export default GroupsGridUI;
