/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useCallback, useEffect, useState } from 'react';
import { FormattedMessage } from 'react-intl';
import AddIcon from '@mui/icons-material/Add';
import { fetchAll } from '../../services/groups';
import GroupsGridUI, { GroupsGridSkeletonTable } from '../GroupsGrid';
import EditGroupDialog from '../EditGroupDialog';
import Button from '@mui/material/Button';
import GlobalAppToolbar from '../GlobalAppToolbar';
import Paper from '@mui/material/Paper';
import { useEnhancedDialogState } from '../../hooks/useEnhancedDialogState';
import { useWithPendingChangesCloseRequest } from '../../hooks/useWithPendingChangesCloseRequest';
import SearchBar from '../SearchBar';
import useStyles from '../UserManagement/styles';
import useDebouncedInput from '../../hooks/useDebouncedInput';
import { ApiResponseErrorState } from '../ApiResponseErrorState';
import { EmptyState } from '../EmptyState';
export function GroupManagement() {
  const [offset, setOffset] = useState(0);
  const [limit, setLimit] = useState(10);
  const [fetching, setFetching] = useState(false);
  const [groups, setGroups] = useState(null);
  const [error, setError] = useState(null);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [keyword, setKeyword] = useState('');
  const { classes } = useStyles();
  const fetchGroups = useCallback(
    (keyword = '', _offset = offset) => {
      setFetching(true);
      fetchAll({ limit, offset: _offset, keyword }).subscribe({
        next(users) {
          setGroups(users);
          setError(null);
          setFetching(false);
        },
        error({ response }) {
          setError(response?.response);
          setFetching(false);
        }
      });
    },
    [limit, offset]
  );
  useEffect(() => {
    fetchGroups();
  }, [fetchGroups]);
  const editGroupDialogState = useEnhancedDialogState();
  const editGroupDialogPendingChangesCloseRequest = useWithPendingChangesCloseRequest(editGroupDialogState.onClose);
  const onRowClicked = (group) => {
    editGroupDialogState.onOpen();
    setSelectedGroup(group);
  };
  const onPageChange = (page) => {
    setOffset(page * limit);
  };
  const onRowsPerPageChange = (e) => {
    setLimit(e.target.value);
  };
  const onGroupSaved = (group) => {
    setSelectedGroup(group);
    fetchGroups();
  };
  const onGroupDeleted = (group) => {
    editGroupDialogState.onClose();
    fetchGroups();
  };
  const onGroupDialogClosed = () => {
    setSelectedGroup(null);
  };
  const onSearch = useCallback(
    (keyword) => {
      fetchGroups(keyword, 0);
    },
    [fetchGroups]
  );
  const onSearch$ = useDebouncedInput(onSearch, 400);
  function handleSearchKeyword(keyword) {
    setKeyword(keyword);
    onSearch$.next(keyword);
  }
  return _jsxs(Paper, {
    elevation: 0,
    children: [
      _jsx(GlobalAppToolbar, {
        title: _jsx(FormattedMessage, { id: 'words.groups', defaultMessage: 'Groups' }),
        leftContent: _jsx(Button, {
          startIcon: _jsx(AddIcon, {}),
          variant: 'outlined',
          color: 'primary',
          onClick: () => editGroupDialogState.onOpen(),
          children: _jsx(FormattedMessage, { id: 'sites.createGroup', defaultMessage: 'Create Group' })
        }),
        rightContent: _jsx(SearchBar, {
          classes: { root: classes.searchBarRoot },
          keyword: keyword,
          onChange: handleSearchKeyword,
          showActionButton: Boolean(keyword)
        })
      }),
      error
        ? _jsx(ApiResponseErrorState, { error: error })
        : fetching
          ? _jsx(GroupsGridSkeletonTable, { numOfItems: limit })
          : groups
            ? groups.length
              ? _jsx(GroupsGridUI, {
                  groups: groups,
                  onRowClicked: onRowClicked,
                  onPageChange: onPageChange,
                  onRowsPerPageChange: onRowsPerPageChange
                })
              : _jsx(EmptyState, {
                  title: _jsx(FormattedMessage, {
                    id: 'groupsGrid.emptyStateMessage',
                    defaultMessage: 'No Groups Found'
                  })
                })
            : _jsx(_Fragment, {}),
      _jsx(EditGroupDialog, {
        open: editGroupDialogState.open,
        group: selectedGroup,
        onClose: editGroupDialogState.onClose,
        onClosed: onGroupDialogClosed,
        onGroupSaved: onGroupSaved,
        onGroupDeleted: onGroupDeleted,
        isSubmitting: editGroupDialogState.isSubmitting,
        isMinimized: editGroupDialogState.isMinimized,
        hasPendingChanges: editGroupDialogState.hasPendingChanges,
        onWithPendingChangesCloseRequest: editGroupDialogPendingChangesCloseRequest,
        onSubmittingAndOrPendingChange: editGroupDialogState.onSubmittingAndOrPendingChange
      })
    ]
  });
}
export default GroupManagement;
