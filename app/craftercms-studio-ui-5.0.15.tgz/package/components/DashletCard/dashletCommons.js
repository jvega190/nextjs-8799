/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { styled } from '@mui/material/styles';
import MuiList from '@mui/material/List';
import MuiListItemAvatar from '@mui/material/ListItemAvatar';
import Checkbox from '@mui/material/Checkbox';
import MuiCheckbox from '@mui/material/Checkbox';
import ListItemText from '@mui/material/ListItemText';
import Skeleton from '@mui/material/Skeleton';
import Typography from '@mui/material/Typography';
import MuiListItem from '@mui/material/ListItem';
import MuiListItemIcon from '@mui/material/ListItemIcon';
import MuiListSubheader from '@mui/material/ListSubheader';
import CheckRounded from '@mui/icons-material/CheckRounded';
import Box from '@mui/material/Box';
import { UNDEFINED } from '../../utils/constants';
import { getInitials, toColor } from '../../utils/string';
import Avatar from '@mui/material/Avatar';
import { getPersonFullName } from '../SiteDashboard/utils';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import { FormattedMessage } from 'react-intl';
import { Pagination } from '../Pagination';
import { useDispatch } from 'react-redux';
import { getOffsetLeft, getOffsetTop } from '@mui/material/Popover';
import { showItemMegaMenu } from '../../state/actions/dialogs';
import IconButton from '@mui/material/IconButton';
import MoreVertRoundedIcon from '@mui/icons-material/MoreVertRounded';
import Tooltip from '@mui/material/Tooltip';
export const actionsToBeShown = [
  'edit',
  'delete',
  'publish',
  'approvePublish',
  'requestPublish',
  'rejectPublish',
  'dependencies',
  'history'
];
export const List = styled(MuiList)({ paddingTop: 0 });
export const ListSubheader = styled(MuiListSubheader)({ paddingLeft: 0, paddingRight: 0, lineHeight: 2 });
export const ListItem = styled(MuiListItem)({ padding: 0 });
export const ListItemIcon = styled(MuiListItemIcon)({ marginRight: 0 });
export const ListItemAvatar = styled(MuiListItemAvatar)({ minWidth: 50 });
export const DenseCheckbox = styled(MuiCheckbox)({ padding: '5px' });
export const DashletAvatar = styled(Avatar)({ width: 40, height: 40 });
export function PersonAvatar(props) {
  const { person, sx } = props;
  const backgroundColor = toColor(person.username);
  return _jsx(DashletAvatar, {
    src: person.avatar ?? UNDEFINED,
    children: person.avatar ? UNDEFINED : getInitials(person),
    sx: { backgroundColor, color: (theme) => theme.palette.getContrastText(backgroundColor), ...sx }
  });
}
export const getItemSkeleton = ({ numOfItems = 1, showCheckbox = false, showAvatar = false }) =>
  _jsx(List, {
    children: new Array(numOfItems)
      .fill(null)
      .map((nothing, index) =>
        _jsxs(
          ListItem,
          {
            sx: { pl: 2, pr: 2 },
            children: [
              showCheckbox && _jsx(ListItemIcon, { children: _jsx(Checkbox, { edge: 'start', disabled: true }) }),
              showAvatar && _jsx(ListItemAvatar, { children: _jsx(DashletAvatar, {}) }),
              _jsx(ListItemText, {
                primary: _jsx(Skeleton, { variant: 'text' }),
                secondary: _jsx(Typography, {
                  color: 'text.secondary',
                  variant: 'body2',
                  children: _jsx(Skeleton, { variant: 'text' })
                })
              })
            ]
          },
          index
        )
      )
  });
export const DashletEmptyMessage = ({ children, sx }) =>
  _jsxs(Box, {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    sx: { mt: 2, ...sx },
    children: [
      _jsx(CheckRounded, { sx: { color: 'success.main', mb: 1 } }),
      _jsx(Typography, { color: 'text.secondary', variant: 'body2', children: children })
    ]
  });
export function PersonFullName({ person }) {
  return _jsx(Typography, { variant: 'h6', children: getPersonFullName(person) });
}
export function Pager(props) {
  const { totalPages, totalItems, currentPage, rowsPerPage, onPagePickerChange, onPageChange, onRowsPerPageChange } =
    props;
  return _jsxs(_Fragment, {
    children: [
      _jsx(Select, {
        variant: 'standard',
        disableUnderline: true,
        value: `${currentPage}`,
        onChange: (e) => onPagePickerChange(parseInt(e.target.value)),
        sx: { fontSize: (theme) => theme.typography.fontSize },
        children: new Array(totalPages)
          .fill(null)
          .map((nothing, index) =>
            _jsx(
              MenuItem,
              {
                value: index,
                sx: { fontSize: (theme) => theme.typography.fontSize },
                children:
                  currentPage === index
                    ? _jsx(FormattedMessage, { defaultMessage: 'Page {pageNumber}', values: { pageNumber: index + 1 } })
                    : _jsx(FormattedMessage, {
                        defaultMessage: 'Go to page {pageNumber}',
                        values: { pageNumber: index + 1 }
                      })
              },
              index
            )
          )
      }),
      _jsx(Pagination, {
        count: totalItems,
        onPageChange: (e, page) => onPageChange(page),
        page: currentPage,
        rowsPerPage: rowsPerPage,
        onRowsPerPageChange: (e) => onRowsPerPageChange(parseInt(e.target.value)),
        mode: 'table'
      })
    ]
  });
}
export function DashletItemOptions(props) {
  const { path, iconButtonProps } = props;
  const dispatch = useDispatch();
  const onOpenItemMegaMenu = (element) => {
    const anchorRect = element.getBoundingClientRect();
    const top = anchorRect.top + getOffsetTop(anchorRect, 'top');
    const left = anchorRect.left + getOffsetLeft(anchorRect, 'left');
    dispatch(
      showItemMegaMenu({
        path,
        anchorReference: 'anchorPosition',
        anchorPosition: { top, left }
      })
    );
  };
  return _jsx(Tooltip, {
    title: _jsx(FormattedMessage, { defaultMessage: 'Options' }),
    children: _jsx(IconButton, {
      size: 'small',
      onClick: (e) => {
        e.stopPropagation();
        onOpenItemMegaMenu(e.currentTarget);
      },
      ...iconButtonProps,
      children: _jsx(MoreVertRoundedIcon, {})
    })
  });
}
