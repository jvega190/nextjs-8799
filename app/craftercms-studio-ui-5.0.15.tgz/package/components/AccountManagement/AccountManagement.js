/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Box from '@mui/material/Box';
import { useEffect, useState } from 'react';
import { defineMessages, FormattedMessage, useIntl } from 'react-intl';
import GlobalAppToolbar from '../GlobalAppToolbar';
import { Typography } from '@mui/material';
import Paper from '@mui/material/Paper';
import useStyles from './styles';
import Avatar from '@mui/material/Avatar';
import Container from '@mui/material/Container';
import { dispatchLanguageChange, getCurrentLocale, setStoredLanguage } from '../../utils/i18n';
import { fetchProductLanguages } from '../../services/configuration';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import Skeleton from '@mui/material/Skeleton';
import PasswordTextField from '../PasswordTextField/PasswordTextField';
import PrimaryButton from '../PrimaryButton';
import { setMyPassword } from '../../services/users';
import { useDispatch } from 'react-redux';
import { showErrorDialog } from '../../state/reducers/dialogs/error';
import { showSystemNotification } from '../../state/actions/system';
import { useActiveUser } from '../../hooks/useActiveUser';
import { PasswordStrengthDisplayPopper } from '../PasswordStrengthDisplayPopper';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import useSiteLookup from '../../hooks/useSiteLookup';
import Button from '@mui/material/Button';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import { preferencesGroups } from './utils';
const translations = defineMessages({
  languageUpdated: {
    id: 'accountManagement.languageUpdated',
    defaultMessage: 'Language preference changed'
  },
  passwordChanged: {
    id: 'accountManagement.passwordChanged',
    defaultMessage: 'Password changed successfully'
  }
});
export function AccountManagement(props) {
  const { passwordRequirementsMinComplexity = 4 } = props;
  const { classes, cx: clsx } = useStyles();
  const user = useActiveUser();
  const [language, setLanguage] = useState(() => getCurrentLocale());
  const [languages, setLanguages] = useState();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [verifiedPassword, setVerifiedPassword] = useState('');
  const [validPassword, setValidPassword] = useState(false);
  const dispatch = useDispatch();
  const { formatMessage } = useIntl();
  const [anchorEl, setAnchorEl] = useState(null);
  const sitesLookup = useSiteLookup();
  const sitesIds = Object.keys(sitesLookup);
  const [selectedSite, setSelectedSite] = useState('all');
  // Retrieve Platform Languages.
  useEffect(() => {
    fetchProductLanguages().subscribe(setLanguages);
  }, []);
  const onLanguageChanged = (language) => {
    setLanguage(language);
    setStoredLanguage(language, user.username);
    dispatchLanguageChange(language);
    dispatch(
      showSystemNotification({
        message: formatMessage(translations.languageUpdated)
      })
    );
  };
  const onSave = () => {
    setMyPassword(user.username, currentPassword, newPassword).subscribe({
      next() {
        dispatch(
          showSystemNotification({
            message: formatMessage(translations.passwordChanged)
          })
        );
        setCurrentPassword('');
        setVerifiedPassword('');
        setNewPassword('');
      },
      error({ response: { response } }) {
        dispatch(showErrorDialog({ error: response }));
      }
    });
  };
  const onClearPreference = (group, showNotification = true) => {
    if (selectedSite === 'all') {
      sitesIds.forEach((siteId) => {
        group.onClear({
          siteId,
          siteUuid: sitesLookup[siteId].uuid,
          username: user.username
        });
      });
    } else {
      group.onClear({
        siteId: selectedSite,
        siteUuid: sitesLookup[selectedSite].uuid,
        username: user.username
      });
    }
    if (showNotification) {
      dispatch(showSystemNotification({ message: formatMessage({ defaultMessage: 'Preferences cleared' }) }));
    }
  };
  const onClearEverything = () => {
    preferencesGroups.forEach((group) => onClearPreference(group, false));
    dispatch(showSystemNotification({ message: formatMessage({ defaultMessage: 'Preferences cleared' }) }));
  };
  return _jsxs(Paper, {
    elevation: 0,
    sx: { mb: 2 },
    children: [
      _jsx(GlobalAppToolbar, { title: _jsx(FormattedMessage, { id: 'words.account', defaultMessage: 'Account' }) }),
      _jsxs(Container, {
        maxWidth: 'md',
        sx: { mb: 2, pb: 2 },
        children: [
          _jsx(Paper, {
            className: clsx(classes.paper, 'mt20'),
            children: _jsxs(Box, {
              display: 'flex',
              alignItems: 'center',
              children: [
                _jsxs(Avatar, {
                  className: classes.avatar,
                  children: [user.firstName.charAt(0), user.lastName?.charAt(0) ?? '']
                }),
                _jsxs('section', {
                  children: [
                    _jsxs(Typography, { children: [user.firstName, ' ', user.lastName] }),
                    _jsx(Typography, { children: user.email })
                  ]
                })
              ]
            })
          }),
          _jsxs(Paper, {
            className: classes.paper,
            children: [
              _jsx(Typography, {
                variant: 'h5',
                children: _jsx(FormattedMessage, {
                  id: 'accountManagement.changeLanguage',
                  defaultMessage: 'Change Language'
                })
              }),
              _jsx(Box, {
                marginTop: '16px',
                children: languages
                  ? _jsx(TextField, {
                      fullWidth: true,
                      select: true,
                      label: _jsx(FormattedMessage, { id: 'words.language', defaultMessage: 'Language' }),
                      value: language,
                      onChange: (event) => onLanguageChanged(event.target.value),
                      children: languages?.map((option) =>
                        _jsx(MenuItem, { value: option.id, children: option.label }, option.id)
                      )
                    })
                  : _jsx(Skeleton, { width: '100%', height: '80px' })
              })
            ]
          }),
          _jsxs(Paper, {
            className: classes.paper,
            children: [
              _jsx(Typography, {
                variant: 'h5',
                children: _jsx(FormattedMessage, {
                  id: 'accountManagement.changePassword',
                  defaultMessage: 'Change Password'
                })
              }),
              _jsx(FormHelperText, {
                children: _jsx(FormattedMessage, {
                  id: 'accountManagement.changeHelperText',
                  defaultMessage: "Once your password has been successfully updated, you'll be required to login again."
                })
              }),
              _jsxs(Box, {
                display: 'flex',
                flexDirection: 'column',
                children: [
                  _jsx(PasswordTextField, {
                    margin: 'normal',
                    label: _jsx(FormattedMessage, {
                      id: 'accountManagement.currentPassword',
                      defaultMessage: 'Current Password'
                    }),
                    required: true,
                    fullWidth: true,
                    value: currentPassword,
                    onChange: (e) => {
                      setCurrentPassword(e.target.value);
                    }
                  }),
                  _jsx(PasswordTextField, {
                    margin: 'normal',
                    label: _jsx(FormattedMessage, {
                      id: 'accountManagement.newPassword',
                      defaultMessage: 'New Password'
                    }),
                    required: true,
                    fullWidth: true,
                    value: newPassword,
                    onChange: (e) => {
                      setNewPassword(e.target.value);
                    },
                    error: Boolean(newPassword) && !validPassword,
                    helperText:
                      newPassword &&
                      !validPassword &&
                      _jsx(FormattedMessage, {
                        id: 'accountManagement.passwordInvalid',
                        defaultMessage: 'Password is invalid.'
                      }),
                    onFocus: (e) => setAnchorEl(e.target),
                    onBlur: () => setAnchorEl(null),
                    slotProps: { htmlInput: { autoComplete: 'new-password' } }
                  }),
                  _jsx(PasswordTextField, {
                    margin: 'normal',
                    label: _jsx(FormattedMessage, {
                      id: 'accountManagement.confirmPassword',
                      defaultMessage: 'Confirm Password'
                    }),
                    required: true,
                    fullWidth: true,
                    value: verifiedPassword,
                    onChange: (e) => {
                      setVerifiedPassword(e.target.value);
                    },
                    error: newPassword !== verifiedPassword,
                    helperText:
                      newPassword !== verifiedPassword &&
                      _jsx(FormattedMessage, {
                        id: 'accountManagement.passwordMatch',
                        defaultMessage: 'Must match the previous password.'
                      })
                  }),
                  _jsx(PrimaryButton, {
                    disabled: !validPassword || newPassword !== verifiedPassword || currentPassword === '',
                    className: classes.save,
                    onClick: () => onSave(),
                    children: _jsx(FormattedMessage, { id: 'words.save', defaultMessage: 'Save' })
                  })
                ]
              })
            ]
          }),
          _jsxs(Paper, {
            className: classes.paper,
            children: [
              _jsx(Typography, {
                variant: 'h5',
                mb: 3,
                children: _jsx(FormattedMessage, { defaultMessage: 'Stored Preferences' })
              }),
              _jsx(Typography, {
                mb: 3,
                variant: 'body2',
                children: _jsx(FormattedMessage, {
                  defaultMessage: 'Clear your user preferences and reset to defaults per project or for all projects.'
                })
              }),
              _jsxs(Box, {
                display: 'flex',
                justifyContent: 'space-between',
                mb: 3,
                children: [
                  _jsxs(FormControl, {
                    sx: { minWidth: 200 },
                    children: [
                      _jsx(InputLabel, { children: _jsx(FormattedMessage, { defaultMessage: 'Project' }) }),
                      _jsxs(Select, {
                        value: selectedSite,
                        label: _jsx(FormattedMessage, { defaultMessage: 'Project' }),
                        onChange: (event) => {
                          setSelectedSite(event.target.value);
                        },
                        children: [
                          _jsx(MenuItem, {
                            value: 'all',
                            children: _jsx(FormattedMessage, { defaultMessage: 'All Projects' })
                          }),
                          sitesIds.map((siteId) =>
                            _jsx(MenuItem, { value: siteId, children: sitesLookup[siteId].name }, siteId)
                          )
                        ]
                      })
                    ]
                  }),
                  _jsxs(Button, {
                    variant: 'outlined',
                    color: 'warning',
                    size: 'large',
                    onClick: onClearEverything,
                    children: [
                      _jsx(FormattedMessage, { defaultMessage: 'Clear everything' }),
                      ' ',
                      selectedSite === 'all' && _jsx(FormattedMessage, { defaultMessage: '(All Projects)' })
                    ]
                  })
                ]
              }),
              _jsx(TableContainer, {
                component: Paper,
                children: _jsx(Table, {
                  size: 'small',
                  children: _jsx(TableBody, {
                    children: preferencesGroups.map((group, index) =>
                      _jsxs(
                        TableRow,
                        {
                          sx: { '&:last-child td, &:last-child th': { border: 0 } },
                          children: [
                            _jsx(TableCell, { component: 'th', scope: 'row', children: group.label }),
                            _jsx(TableCell, {
                              align: 'right',
                              children: _jsx(Button, {
                                variant: 'text',
                                onClick: () => onClearPreference(group),
                                children: _jsx(FormattedMessage, { defaultMessage: 'Clear' })
                              })
                            })
                          ]
                        },
                        index
                      )
                    )
                  })
                })
              })
            ]
          })
        ]
      }),
      _jsx(PasswordStrengthDisplayPopper, {
        open: Boolean(anchorEl),
        anchorEl: anchorEl,
        placement: 'top',
        value: newPassword,
        passwordRequirementsMinComplexity: passwordRequirementsMinComplexity,
        onValidStateChanged: setValidPassword
      })
    ]
  });
}
export default AccountManagement;
