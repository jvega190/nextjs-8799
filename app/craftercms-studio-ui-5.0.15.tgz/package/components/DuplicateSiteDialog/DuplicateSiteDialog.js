/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2023 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { EnhancedDialog } from '../EnhancedDialog';
import { FormattedMessage } from 'react-intl';
import { useEffect } from 'react';
import DuplicateSiteDialogContainer from './DuplicateSiteDialogContainer';
import useSpreadState from '../../hooks/useSpreadState';
import { dialogClasses } from '@mui/material/Dialog';
import useWithPendingChangesCloseRequest from '../../hooks/useWithPendingChangesCloseRequest';
import useUpdateRefs from '../../hooks/useUpdateRefs';
import useOnClose from '../../hooks/useOnClose';
const siteInitialState = {
  sourceSiteId: '',
  siteId: '',
  siteName: '',
  siteIdExist: false,
  siteNameExist: false,
  invalidSiteId: false,
  description: '',
  gitBranch: '',
  submitted: false,
  selectedView: 0,
  readOnlyBlobStores: true
};
export function DuplicateSiteDialog(props) {
  const { siteId, onSubmittingAndOrPendingChange, onClose, onGoBack, ...dialogProps } = props;
  const [site, setSite] = useSpreadState({
    ...siteInitialState,
    ...(siteId && { sourceSiteId: siteId })
  });
  const onCloseHandler = useOnClose({
    onClose: !dialogProps.isSubmitting && onClose,
    disableBackdropClick: dialogProps.isSubmitting,
    disableEscapeKeyDown: dialogProps.isSubmitting
  });
  const pendingChangesCloseRequest = useWithPendingChangesCloseRequest(onCloseHandler);
  const fnRefs = useUpdateRefs({ onSubmittingAndOrPendingChange });
  useEffect(() => {
    if (siteId) {
      setSite({ sourceSiteId: siteId });
    }
  }, [siteId, setSite]);
  useEffect(() => {
    const { sourceSiteId, siteId, siteName, description, gitBranch } = site;
    const dialogHasChanges =
      Boolean(sourceSiteId) || Boolean(siteId) || Boolean(siteName) || Boolean(description) || Boolean(gitBranch);
    fnRefs.current.onSubmittingAndOrPendingChange({ hasPendingChanges: dialogHasChanges });
  }, [site, fnRefs]);
  const views = {
    0: {
      title: _jsx(FormattedMessage, { defaultMessage: 'Duplicate Project' }),
      subtitle: _jsx(FormattedMessage, {
        defaultMessage: 'The new project will be an exact copy of the chosen project'
      })
    },
    1: {
      title: _jsx(FormattedMessage, { defaultMessage: 'Finish' }),
      subtitle: _jsx(FormattedMessage, { defaultMessage: 'Review set up summary and duplicate the project' })
    }
  };
  return _jsx(EnhancedDialog, {
    title: views[site.selectedView].title,
    dialogHeaderProps: { subtitle: views[site.selectedView].subtitle },
    maxWidth: 'lg',
    sx: {
      [`& .${dialogClasses.paper}`]: { height: 'calc(100% - 100px)', maxHeight: '1200px' }
    },
    'data-dialog-id': 'create-site-dialog',
    onWithPendingChangesCloseRequest: pendingChangesCloseRequest,
    onClosed: () => setSite(siteInitialState),
    ...dialogProps,
    onClose: onCloseHandler,
    children: _jsx(DuplicateSiteDialogContainer, {
      site: site,
      setSite: setSite,
      handleClose: onClose,
      onGoBack: onGoBack,
      isSubmitting: dialogProps.isSubmitting,
      onSubmittingAndOrPendingChange: onSubmittingAndOrPendingChange
    })
  });
}
export default DuplicateSiteDialog;
