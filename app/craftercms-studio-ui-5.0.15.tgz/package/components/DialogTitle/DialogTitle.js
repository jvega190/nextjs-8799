/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import MuiDialogTitle from '@mui/material/DialogTitle';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import palette from '../../styles/palette';
import { makeStyles } from 'tss-react/mui';
const dialogTitleStyles = makeStyles()(() => ({
  titleRoot: {
    margin: 0,
    padding: '13px 20px 11px',
    background: palette.white
  },
  title: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  subtitle: {
    fontSize: '14px',
    lineHeight: '18px',
    paddingRight: '35px'
  },
  closeIcon: {}
}));
export function DialogTitle(props) {
  const { classes } = dialogTitleStyles();
  const { onClose, title, subtitle } = props;
  return _jsxs(MuiDialogTitle, {
    className: classes.titleRoot,
    children: [
      _jsxs('div', {
        className: classes.title,
        children: [
          _jsx(Typography, { variant: 'h6', children: title }),
          onClose
            ? _jsx(IconButton, {
                'aria-label': 'close',
                onClick: onClose,
                className: classes.closeIcon,
                size: 'large',
                children: _jsx(CloseIcon, {})
              })
            : null
        ]
      }),
      subtitle && _jsx(Typography, { variant: 'subtitle1', className: classes.subtitle, children: subtitle })
    ]
  });
}
export default DialogTitle;
