/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { createContext, useContext, useEffect, useMemo } from 'react';
import { getStoredGlobalAppOpenSidebar, setStoredGlobalAppOpenSidebar } from '../../utils/state';
import { useActiveUser } from '../../hooks/useActiveUser';
import { useSpreadState } from '../../hooks/useSpreadState';
const GlobalAppContext = createContext([{ openSidebar: true }, null]);
export const GlobalAppContextProvider = ({ children }) => {
  const user = useActiveUser();
  const [state, setState] = useSpreadState(null, () => ({
    openSidebar: getStoredGlobalAppOpenSidebar(user.username)
      ? getStoredGlobalAppOpenSidebar(user.username) === 'true'
      : true
  }));
  useEffect(() => {
    setStoredGlobalAppOpenSidebar(user.username, state.openSidebar);
  }, [state.openSidebar, user.username]);
  const value = useMemo(() => [state, setState], [state, setState]);
  return _jsx(GlobalAppContext.Provider, { value: value, children: children });
};
export const useGlobalAppState = () => useContext(GlobalAppContext);
