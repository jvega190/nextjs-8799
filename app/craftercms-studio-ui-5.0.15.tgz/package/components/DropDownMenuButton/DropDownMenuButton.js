/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import Button from '@mui/material/Button';
import { useRef, useState } from 'react';
import Menu from '@mui/material/Menu';
import { ListItemText } from '@mui/material';
import { CheckRounded, KeyboardArrowDownRounded } from '@mui/icons-material';
import { UNDEFINED } from '../../utils/constants';
import ListItemButton from '@mui/material/ListItemButton';
import ListItem from '@mui/material/ListItem';
export function DropDownMenu(props) {
  const {
    options,
    onMenuItemClick: onMenuItemClickProp,
    onClick,
    closeOnSelection = true,
    menuProps,
    listItemProps,
    listItemTextProps,
    listItemButtonProps,
    ...buttonProps
  } = props;
  const buttonRef = useRef(undefined);
  const [open, setOpen] = useState(false);
  const onClose = () => setOpen(false);
  const onMenuItemClick = (e, option) => {
    closeOnSelection && onClose();
    onMenuItemClickProp?.(e, option.id);
  };
  return _jsxs(_Fragment, {
    children: [
      _jsx(Button, {
        endIcon: _jsx(KeyboardArrowDownRounded, {}),
        ...buttonProps,
        ref: buttonRef,
        onClick: (e) => {
          // @ts-ignore
          if (onClick?.(e) !== false) {
            setOpen(true);
          }
        }
      }),
      _jsx(Menu, {
        ...menuProps,
        open: open,
        anchorEl: buttonRef.current,
        onClose: onClose,
        children: options?.map((option) =>
          _jsx(
            ListItem,
            {
              disablePadding: true,
              secondaryAction: option.selected ? _jsx(CheckRounded, {}) : UNDEFINED,
              ...listItemProps,
              children: _jsx(ListItemButton, {
                dense: true,
                ...listItemButtonProps,
                selected: option.selected,
                disabled: option.disabled,
                onClick: (e) => onMenuItemClick(e, option),
                children: _jsx(ListItemText, {
                  primary: option.primaryText,
                  secondary: option.secondaryText,
                  ...listItemTextProps
                })
              })
            },
            option.id
          )
        )
      })
    ]
  });
}
export default DropDownMenu;
