/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
import questionGraphicUrl from '../../assets/question.svg';
import useUnmount from '../../hooks/useUnmount';
import DialogContent from '@mui/material/DialogContent';
import Typography from '@mui/material/Typography';
import DialogContentText from '@mui/material/DialogContentText';
import Box from '@mui/material/Box';
import { DialogFooter } from '../DialogFooter';
import { nnou } from '../../utils/object';
export function AlertDialogContainer(props) {
  const { onClosed, body, title, children, imageUrl = questionGraphicUrl, buttons, sxs } = props;
  useUnmount(onClosed);
  return _jsxs(_Fragment, {
    children: [
      _jsxs(DialogContent, {
        id: 'alertDialogBody',
        sx: {
          textAlign: 'center',
          padding: '40px 20px 25px !important',
          ...sxs?.body
        },
        children: [
          imageUrl &&
            _jsx(Box, {
              component: 'img',
              src: imageUrl,
              alt: '',
              sx: {
                margin: 'auto',
                display: 'block',
                paddingBottom: '35px',
                ...sxs?.image
              }
            }),
          title &&
            _jsx(Typography, {
              variant: 'body1',
              component: 'h2',
              sx: {
                paddingBottom: '5px',
                ...sxs?.title
              },
              children: title
            }),
          body && _jsx(DialogContentText, { color: 'textPrimary', variant: 'body2', children: body }),
          children
        ]
      }),
      nnou(buttons) &&
        _jsx(DialogFooter, {
          sx: {
            borderTop: 'none',
            display: 'flex',
            flexDirection: 'column',
            padding: '0 40px 35px',
            backgroundColor: null,
            '& > :not(:first-child)': {
              marginTop: '10px',
              marginLeft: 0
            },
            ...sxs?.footer
          },
          children: buttons
        })
    ]
  });
}
export default AlertDialogContainer;
