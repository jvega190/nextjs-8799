/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useEffect } from 'react';
import { getItemViewOption, isPage, previewPage } from '../SiteDashboard/utils';
import DashletCard from '../DashletCard/DashletCard';
import {
  DashletEmptyMessage,
  DashletItemOptions,
  getItemSkeleton,
  List,
  ListItem,
  ListSubheader
} from '../DashletCard/dashletCommons';
import palette from '../../styles/palette';
import { FormattedMessage, useIntl } from 'react-intl';
import Typography from '@mui/material/Typography';
import ListItemText from '@mui/material/ListItemText';
import { fetchExpired, fetchExpiring } from '../../services/dashboard';
import useSpreadState from '../../hooks/useSpreadState';
import useLocale from '../../hooks/useLocale';
import useActiveSiteId from '../../hooks/useActiveSiteId';
import RefreshRounded from '@mui/icons-material/RefreshRounded';
import { asLocalizedDateTime } from '../../utils/datetime';
import Divider from '@mui/material/Divider';
import { forkJoin } from 'rxjs';
import ItemDisplay from '../ItemDisplay';
import { itemActionDispatcher } from '../../utils/itemActions';
import useEnv from '../../hooks/useEnv';
import { useDispatch } from 'react-redux';
import LoadingIconButton from '../LoadingIconButton';
const renderExpiredItems = (items, locale, onItemClick, expired) =>
  items.map((item, index) => {
    const isItemPreviewable = isPage(item.sandboxItem.systemType) || item.sandboxItem.availableActionsMap.view;
    return _jsx(
      ListItem,
      {
        secondaryAction: _jsx(DashletItemOptions, { path: item.sandboxItem.path }),
        children: _jsx(ListItemText, {
          primary: _jsx(ItemDisplay, {
            item: item.sandboxItem,
            onClick: (e) => (isItemPreviewable ? onItemClick(e, item.sandboxItem) : null),
            showNavigableAsLinks: isItemPreviewable,
            styles: { ...(isItemPreviewable && { root: { cursor: 'pointer' } }) }
          }),
          secondary: _jsx(Typography, {
            color: expired ? 'error.main' : 'text.secondary',
            variant: 'body2',
            children: _jsx(FormattedMessage, {
              id: 'expiringDashlet.expiredOn',
              defaultMessage: '{expirationText} on {date}',
              values: {
                date: asLocalizedDateTime(item.expiredDateTime, locale.localeCode, locale.dateTimeFormatOptions),
                expirationText: expired ? 'Expired' : 'Expires'
              }
            })
          })
        })
      },
      index
    );
  });
export function ExpiringDashlet(props) {
  const { borderLeftColor = palette.purple.tint, days = 30, onMinimize } = props;
  const site = useActiveSiteId();
  const locale = useLocale();
  const [state, setState] = useSpreadState({
    expiring: null,
    expired: null,
    refresh: 0,
    loading: false
  });
  const { formatMessage } = useIntl();
  const { authoringBase } = useEnv();
  const dispatch = useDispatch();
  const onRefresh = () => setState({ refresh: ++state.refresh });
  const onItemClick = (e, item) => {
    if (isPage(item.systemType)) {
      e.stopPropagation();
      previewPage(site, authoringBase, item, dispatch, onMinimize);
    } else if (item.availableActionsMap.view) {
      e.stopPropagation();
      itemActionDispatcher({
        site,
        authoringBase,
        dispatch,
        formatMessage,
        option: getItemViewOption(item),
        item
      });
    }
  };
  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const foo = state.refresh + 1;
    const oneDay = 8.64e7;
    const now = new Date();
    setState({ loading: true, expiring: null, expired: null });
    forkJoin({
      expiring: fetchExpiring(site, {
        dateFrom: now.toISOString(),
        dateTo: new Date(now.getTime() + oneDay * days).toISOString()
      }),
      expired: fetchExpired(site, { limit: 10 })
    }).subscribe(({ expiring, expired }) => {
      setState({ expiring, expired, loading: false });
    });
  }, [setState, site, days, state.refresh]);
  return _jsxs(DashletCard, {
    ...props,
    borderLeftColor: borderLeftColor,
    title: _jsx(FormattedMessage, { id: 'words.expiring', defaultMessage: 'Expiring' }),
    headerAction: _jsx(LoadingIconButton, {
      onClick: onRefresh,
      loading: state.loading,
      children: _jsx(RefreshRounded, {})
    }),
    children: [
      state.loading &&
        _jsx(List, { children: getItemSkeleton({ numOfItems: 5, showAvatar: false, showCheckbox: false }) }),
      state.expired &&
        (state.expired.length === 0
          ? _jsx(DashletEmptyMessage, {
              children: _jsx(FormattedMessage, {
                id: 'expiringDashlet.noExpiredItems',
                defaultMessage: 'There are no expired items to display at this time'
              })
            })
          : _jsx(List, {
              subheader: _jsx(ListSubheader, {
                children: _jsx(FormattedMessage, { id: 'words.expired', defaultMessage: 'Expired' })
              }),
              children: renderExpiredItems(state.expired, locale, onItemClick, true)
            })),
      _jsx(Divider, { sx: { mt: 1, mb: 1 } }),
      state.expiring &&
        (state.expiring.length === 0
          ? _jsx(DashletEmptyMessage, {
              sx: { mt: 0 },
              children: _jsx(FormattedMessage, {
                id: 'expiringDashlet.noExpiringItems',
                defaultMessage: 'There are no items expiring in the next {days} days',
                values: { days }
              })
            })
          : _jsx(List, {
              subheader: _jsx(ListSubheader, {
                children: _jsx(FormattedMessage, {
                  id: 'expiringDashlet.expiringNextNDays',
                  defaultMessage: 'Expiring (next {days} days)',
                  values: { days }
                })
              }),
              children: renderExpiredItems(state.expiring, locale, onItemClick)
            }))
    ]
  });
}
export default ExpiringDashlet;
