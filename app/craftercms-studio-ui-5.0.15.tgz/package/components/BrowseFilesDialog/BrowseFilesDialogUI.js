/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useRef, useState } from 'react';
import DialogBody from '../DialogBody/DialogBody';
import DialogFooter from '../DialogFooter/DialogFooter';
import SecondaryButton from '../SecondaryButton';
import PrimaryButton from '../PrimaryButton';
import { FormattedMessage, useIntl } from 'react-intl';
import MediaCard from '../MediaCard/MediaCard';
import { useStyles } from './styles';
import SearchBar from '../SearchBar/SearchBar';
import MediaSkeletonCard from './MediaSkeletonCard';
import EmptyState from '../EmptyState/EmptyState';
import Pagination from '../Pagination';
import FolderBrowserTreeView from '../FolderBrowserTreeView';
import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import { filtersMessages } from '../SiteSearchSortBy';
import { camelize } from '../../utils/string';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Tooltip from '@mui/material/Tooltip';
import RefreshIcon from '@mui/icons-material/Refresh';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import FilterListIcon from '@mui/icons-material/FilterList';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import { inputBaseClasses } from '@mui/material/InputBase';
import ListViewIcon from '@mui/icons-material/ViewStreamRounded';
import GridViewIcon from '@mui/icons-material/GridOnRounded';
import ReorderRoundedIcon from '@mui/icons-material/ReorderRounded';
import { SORT_AUTO } from '../Search/utils';
import Checkbox from '@mui/material/Checkbox';
export function BrowseFilesDialogUI(props) {
  // region const { ... } = props;
  const {
    items,
    guestBase,
    selectedCard,
    selectedArray,
    multiSelect = false,
    path,
    currentPath,
    searchParameters,
    setSearchParameters,
    limit,
    offset,
    keyword,
    total,
    numOfLoaderItems = 12,
    sortKeys,
    onCardSelected,
    onPreviewImage,
    onCheckboxChecked,
    handleSearchKeyword,
    onPathSelected,
    onSelectButtonClick,
    onChangePage,
    onChangeRowsPerPage,
    onCloseButtonClick,
    onRefresh,
    onUpload,
    allowUpload = true,
    viewMode = 'card',
    onToggleViewMode,
    allSelected,
    someSelected,
    onSelectAll
  } = props;
  // endregion
  const { classes, cx: clsx } = useStyles();
  const { formatMessage } = useIntl();
  const [sortMenuOpen, setSortMenuOpen] = useState(false);
  const buttonRef = useRef(undefined);
  return _jsxs(_Fragment, {
    children: [
      _jsx(DialogBody, {
        className: classes.dialogBody,
        children: _jsxs(Box, {
          display: 'flex',
          className: classes.dialogContent,
          children: [
            _jsx(Box, {
              className: classes.leftWrapper,
              display: 'flex',
              flexDirection: 'column',
              rowGap: '20px',
              children: _jsx(FolderBrowserTreeView, {
                rootPath: path,
                onPathSelected: onPathSelected,
                selectedPath: currentPath
              })
            }),
            _jsxs('section', {
              className: classes.rightWrapper,
              children: [
                _jsx(Paper, {
                  className: classes.actionsBar,
                  children: _jsxs(Toolbar, {
                    disableGutters: true,
                    variant: 'dense',
                    children: [
                      _jsxs(Box, {
                        sx: { flexGrow: 1, display: 'flex' },
                        children: [
                          multiSelect &&
                            _jsxs(_Fragment, {
                              children: [
                                _jsx(Tooltip, {
                                  title: _jsx(FormattedMessage, { defaultMessage: 'Select all on this page' }),
                                  children: _jsx(Checkbox, {
                                    checked: allSelected,
                                    indeterminate: someSelected,
                                    onChange: onSelectAll
                                  })
                                }),
                                _jsx(Divider, {
                                  orientation: 'vertical',
                                  flexItem: true,
                                  className: classes.actionsBarDivider
                                })
                              ]
                            }),
                          _jsx(Tooltip, {
                            title: _jsx(FormattedMessage, { id: 'word.refresh', defaultMessage: 'Refresh' }),
                            children: _jsx(IconButton, { onClick: onRefresh, children: _jsx(RefreshIcon, {}) })
                          }),
                          allowUpload &&
                            _jsx(Tooltip, {
                              title: _jsx(FormattedMessage, { id: 'word.upload', defaultMessage: 'Upload' }),
                              children: _jsx(IconButton, {
                                onClick: onUpload,
                                sx: { mr: 1 },
                                children: _jsx(UploadFileIcon, {})
                              })
                            }),
                          _jsx(Divider, {
                            orientation: 'vertical',
                            flexItem: true,
                            className: classes.actionsBarDivider
                          }),
                          _jsx(SearchBar, {
                            keyword: keyword,
                            onChange: handleSearchKeyword,
                            showDecoratorIcon: true,
                            showActionButton: Boolean(keyword),
                            classes: { root: classes.searchRoot, inputInput: classes.searchInput }
                          }),
                          _jsx(Divider, {
                            orientation: 'vertical',
                            flexItem: true,
                            className: classes.actionsBarDivider
                          }),
                          _jsx(Button, {
                            id: 'sort-button',
                            'aria-haspopup': 'true',
                            'aria-controls': sortMenuOpen ? 'sort-menu' : undefined,
                            'aria-expanded': sortMenuOpen ? 'true' : undefined,
                            onClick: () => setSortMenuOpen(!sortMenuOpen),
                            ref: buttonRef,
                            sx: { ml: 1, mr: 1 },
                            startIcon: _jsx(FilterListIcon, {}),
                            children: _jsx(FormattedMessage, { id: 'words.sorting', defaultMessage: 'Sorting' })
                          }),
                          _jsxs(Menu, {
                            id: 'sort-menu',
                            anchorEl: buttonRef.current,
                            open: sortMenuOpen,
                            onClose: () => setSortMenuOpen(false),
                            slotProps: {
                              list: { 'aria-labelledby': 'sort-button' }
                            },
                            children: [
                              _jsx(MenuItem, {
                                children: _jsxs(FormControl, {
                                  fullWidth: true,
                                  children: [
                                    _jsx(InputLabel, {
                                      children: _jsx(FormattedMessage, {
                                        id: 'BrowseFilesDialog.sortBy',
                                        defaultMessage: 'Sort By'
                                      })
                                    }),
                                    _jsxs(Select, {
                                      fullWidth: true,
                                      value: searchParameters.sortBy,
                                      onChange: ({ target }) => {
                                        setSearchParameters({
                                          sortBy: target.value
                                        });
                                      },
                                      size: 'small',
                                      className: classes.sortingSelect,
                                      label: _jsx(FormattedMessage, {
                                        id: 'BrowseFilesDialog.sortBy',
                                        defaultMessage: 'Sort By'
                                      }),
                                      children: [
                                        _jsx(MenuItem, {
                                          value: SORT_AUTO,
                                          children: _jsx(FormattedMessage, { defaultMessage: 'Auto' })
                                        }),
                                        _jsx(MenuItem, {
                                          value: '_score',
                                          children: _jsx(FormattedMessage, {
                                            id: 'words.relevance',
                                            defaultMessage: 'Relevance'
                                          })
                                        }),
                                        _jsx(MenuItem, {
                                          value: 'internalName',
                                          children: _jsx(FormattedMessage, { id: 'words.name', defaultMessage: 'Name' })
                                        }),
                                        sortKeys.map((name, i) =>
                                          _jsx(
                                            MenuItem,
                                            { value: name, children: formatMessage(filtersMessages[camelize(name)]) },
                                            i
                                          )
                                        )
                                      ]
                                    })
                                  ]
                                })
                              }),
                              searchParameters.sortBy &&
                                SORT_AUTO !== searchParameters.sortBy &&
                                _jsx(MenuItem, {
                                  children: _jsxs(FormControl, {
                                    fullWidth: true,
                                    children: [
                                      _jsx(InputLabel, {
                                        children: _jsx(FormattedMessage, { id: 'words.order', defaultMessage: 'Order' })
                                      }),
                                      _jsxs(Select, {
                                        fullWidth: true,
                                        value: searchParameters.sortOrder,
                                        onChange: ({ target }) => {
                                          setSearchParameters({
                                            sortOrder: target.value
                                          });
                                        },
                                        size: 'small',
                                        className: classes.sortingSelect,
                                        label: _jsx(FormattedMessage, { id: 'words.order', defaultMessage: 'Order' }),
                                        children: [
                                          _jsx(MenuItem, {
                                            value: 'asc',
                                            children:
                                              searchParameters.sortBy === '_score'
                                                ? _jsx(FormattedMessage, {
                                                    id: 'browseFilesDialog.lessRelevantFirst',
                                                    defaultMessage: 'Less relevant first'
                                                  })
                                                : _jsx(FormattedMessage, {
                                                    id: 'words.ascending',
                                                    defaultMessage: 'Ascending'
                                                  })
                                          }),
                                          _jsx(MenuItem, {
                                            value: 'desc',
                                            children:
                                              searchParameters.sortBy === '_score'
                                                ? _jsx(FormattedMessage, {
                                                    id: 'browseFilesDialog.mostRelevantFirst',
                                                    defaultMessage: 'Most relevant first'
                                                  })
                                                : _jsx(FormattedMessage, {
                                                    id: 'words.descending',
                                                    defaultMessage: 'Descending'
                                                  })
                                          })
                                        ]
                                      })
                                    ]
                                  })
                                })
                            ]
                          }),
                          _jsx(Divider, {
                            orientation: 'vertical',
                            flexItem: true,
                            className: classes.actionsBarDivider
                          })
                        ]
                      }),
                      _jsxs(Box, {
                        sx: { display: 'flex', flexGrow: 0 },
                        children: [
                          _jsx(Tooltip, {
                            title: _jsx(FormattedMessage, { defaultMessage: 'Switch view mode' }),
                            children: _jsx(IconButton, {
                              onClick: onToggleViewMode,
                              sx: { mr: 1 },
                              children:
                                viewMode === 'card'
                                  ? _jsx(ListViewIcon, {})
                                  : viewMode === 'compact'
                                    ? _jsx(ReorderRoundedIcon, {})
                                    : _jsx(GridViewIcon, {})
                            })
                          }),
                          _jsx(Divider, {
                            orientation: 'vertical',
                            flexItem: true,
                            className: classes.actionsBarDivider
                          }),
                          items &&
                            _jsx(Pagination, {
                              sxs: {
                                toolbar: { pl: 0 },
                                root: {
                                  [`.${inputBaseClasses.root}`]: {
                                    marginRight: (theme) => theme.spacing(1),
                                    backgroundColor: (theme) =>
                                      theme.palette.background[theme.palette.mode === 'dark' ? 'default' : 'paper']
                                  }
                                }
                              },
                              count: total,
                              rowsPerPage: limit,
                              page: Math.ceil(offset / limit),
                              onPageChange: (e, page) => onChangePage(page),
                              onRowsPerPageChange: onChangeRowsPerPage
                            })
                        ]
                      })
                    ]
                  })
                }),
                _jsx(Box, {
                  className: classes.cardsContainer,
                  sx: [viewMode === 'row' && { display: 'flex !important', flexFlow: 'wrap' }],
                  children: items
                    ? items.map((item) =>
                        _jsx(
                          MediaCard,
                          {
                            viewMode: viewMode,
                            classes: {
                              root: clsx(
                                classes.mediaCardRoot,
                                item.path === selectedCard?.path && classes.selectedCard
                              )
                            },
                            item: item,
                            selected: multiSelect ? selectedArray : null,
                            onSelect: multiSelect ? onCheckboxChecked : null,
                            onPreview: onPreviewImage ? () => onPreviewImage(item) : null,
                            previewAppBaseUri: guestBase,
                            onClick: () => onCardSelected(item),
                            showPath: true
                          },
                          item.path
                        )
                      )
                    : new Array(numOfLoaderItems).fill(null).map((x, i) => _jsx(MediaSkeletonCard, {}, i))
                }),
                items &&
                  items.length === 0 &&
                  _jsx(EmptyState, {
                    styles: { root: { flexGrow: 1 } },
                    title: _jsx(FormattedMessage, {
                      id: 'browseFilesDialog.noResults',
                      defaultMessage: 'No items found.'
                    })
                  })
              ]
            })
          ]
        })
      }),
      _jsxs(DialogFooter, {
        children: [
          _jsx(SecondaryButton, {
            onClick: onCloseButtonClick,
            children: _jsx(FormattedMessage, { id: 'words.cancel', defaultMessage: 'Cancel' })
          }),
          _jsx(PrimaryButton, {
            disabled: !Boolean(selectedArray.length) && !selectedCard,
            onClick: onSelectButtonClick,
            children: _jsx(FormattedMessage, { id: 'words.select', defaultMessage: 'Select' })
          })
        ]
      })
    ]
  });
}
export default BrowseFilesDialogUI;
