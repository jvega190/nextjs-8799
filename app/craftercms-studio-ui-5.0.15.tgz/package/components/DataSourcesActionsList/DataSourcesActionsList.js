/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment } from 'react/jsx-runtime';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
export function DataSourcesActionsList(props) {
  const { show, rect, items, onClose } = props;
  return _jsx(_Fragment, {
    children:
      items.length > 0 &&
      _jsx(Menu, {
        open: show,
        anchorReference: 'anchorPosition',
        anchorPosition: {
          top: rect.top,
          left: rect.left
        },
        onClose: onClose,
        children: items.map((item, index) =>
          _jsx(MenuItem, { onClick: () => item.action(item.path, item.type), children: item.label }, index)
        )
      })
  });
}
export default DataSourcesActionsList;
