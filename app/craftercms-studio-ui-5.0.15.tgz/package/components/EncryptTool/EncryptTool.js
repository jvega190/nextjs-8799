/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useEffect, useRef, useState } from 'react';
import { defineMessages, FormattedMessage, useIntl } from 'react-intl';
import { encrypt as encryptService } from '../../services/security';
import Snackbar from '@mui/material/Snackbar';
import SnackbarContent from '@mui/material/SnackbarContent';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import { makeStyles } from 'tss-react/mui';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import { green, red } from '@mui/material/colors';
import { setRequestForgeryToken } from '../../utils/auth';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import GlobalAppToolbar from '../GlobalAppToolbar';
import Box from '@mui/material/Box';
import { useSpreadState } from '../../hooks/useSpreadState';
import Paper from '@mui/material/Paper';
import useUpdateRefs from '../../hooks/useUpdateRefs';
import { copyToClipboard } from '../../utils/system';
import useSnackbarDuration from '../../hooks/useSnackbarDuration';
const messages = defineMessages({
  inputLabel: {
    id: 'encryptTool.inputLabel',
    defaultMessage: 'Raw Text'
  },
  buttonText: {
    id: 'encryptTool.buttonText',
    defaultMessage: 'Encrypt Text'
  },
  successMessage: {
    id: 'encryptTool.successMessage',
    defaultMessage: 'Encrypted text copied to clipboard.'
  },
  errorMessage: {
    id: 'encryptTool.errorMessage',
    defaultMessage: 'Text encryption failed. Please try again momentarily.'
  },
  clearResultButtonText: {
    id: 'encryptTool.clearResultButtonText',
    defaultMessage: 'Clear'
  }
});
const useStyles = makeStyles()((theme) => ({
  form: {
    padding: '20px'
  },
  title: {
    color: '#555555'
  },
  success: {
    backgroundColor: green[600]
  },
  error: {
    backgroundColor: red[600]
  },
  icon: {
    fontSize: 20
  },
  iconVariant: {
    opacity: 0.9,
    marginRight: theme.spacing(1)
  },
  message: {
    display: 'flex',
    alignItems: 'center'
  }
}));
const notificationInitialState = {
  open: false,
  variant: 'success'
};
export const EncryptTool = (props) => {
  const { site, embedded = false, showAppsButton, onSubmittingAndOrPendingChange } = props;
  const { classes } = useStyles();
  const inputRef = useRef(undefined);
  const [text, setText] = useState('');
  const [result, setResult] = useState(null);
  const [fetching, setFetching] = useState(null);
  const [notificationSettings, setNotificationSettings] = useSpreadState(notificationInitialState);
  const { formatMessage } = useIntl();
  const fnRefs = useUpdateRefs({ onSubmittingAndOrPendingChange });
  const hasText = Boolean(text);
  const autoHideDuration = useSnackbarDuration();
  const focus = () => {
    const toolRawTextInput = document.querySelector('#encryptionToolRawText');
    toolRawTextInput.focus();
  };
  const encrypt = (e) => {
    e.preventDefault();
    if (text) {
      setRequestForgeryToken();
      setFetching(true);
      setResult(null);
      encryptService(text, site).subscribe({
        next(encryptedText) {
          const resultingText = `\${enc:${encryptedText}}`;
          setFetching(false);
          setText('');
          setResult(resultingText);
          copyToClipboard(resultingText)
            .then(() => {
              setNotificationSettings({ open: true, variant: 'success' });
            })
            .catch(() => {
              inputRef.current.focus();
              inputRef.current.select();
            });
        },
        error() {
          setNotificationSettings({ open: true, variant: 'error' });
        }
      });
    } else {
      focus();
    }
  };
  const clear = () => {
    setText('');
    setResult(null);
    focus();
  };
  useEffect(() => {
    fnRefs.current.onSubmittingAndOrPendingChange?.({ hasPendingChanges: hasText });
  }, [hasText, fnRefs]);
  return _jsxs(Paper, {
    elevation: 0,
    children: [
      !embedded &&
        _jsx(GlobalAppToolbar, {
          title: _jsx(FormattedMessage, { id: 'encryptTool.pageTitle', defaultMessage: 'Encryption Tool' }),
          showAppsButton: showAppsButton
        }),
      _jsx(Box, {
        p: '20px',
        children: _jsxs('form', {
          onSubmit: encrypt,
          children: [
            _jsx(TextField, {
              sx: { mb: 2 },
              label: formatMessage(messages.inputLabel),
              value: text,
              onChange: (e) => setText(e.target.value),
              onKeyUp: (e) => {
                if (e.key === 'Enter' && e.ctrlKey) {
                  encrypt(e);
                }
              },
              fullWidth: true,
              id: 'encryptionToolRawText',
              name: 'encryptionToolRawText',
              autoFocus: true,
              disabled: fetching,
              multiline: true
            }),
            result &&
              _jsx(TextField, {
                fullWidth: true,
                type: 'text',
                color: 'success',
                sx: { mb: 2 },
                ref: inputRef,
                label: _jsx(FormattedMessage, { id: 'words.result', defaultMessage: 'Result' }),
                slotProps: {
                  input: { readOnly: true }
                },
                value: result,
                onClick: (e) => {
                  const input = e.target;
                  const value = input.value;
                  input.select();
                  copyToClipboard(value).then(() => {
                    setNotificationSettings({ open: true, variant: 'success' });
                  });
                }
              }),
            _jsxs('div', {
              children: [
                _jsx(Button, {
                  type: 'button',
                  onClick: clear,
                  disabled: fetching,
                  variant: 'outlined',
                  sx: { mr: 1 },
                  children: formatMessage(messages.clearResultButtonText)
                }),
                _jsx(Button, {
                  type: 'submit',
                  onClick: encrypt,
                  disabled: fetching,
                  color: 'primary',
                  variant: 'contained',
                  children: formatMessage(messages.buttonText)
                })
              ]
            }),
            _jsx(Snackbar, {
              anchorOrigin: {
                vertical: 'top',
                horizontal: 'right'
              },
              open: notificationSettings.open,
              autoHideDuration: autoHideDuration,
              onClose: () => {
                setNotificationSettings({ open: false });
              },
              children: _jsx(SnackbarContent, {
                className: `${notificationSettings.variant === 'success' ? classes.success : classes.error} ${classes.iconVariant}`,
                'aria-describedby': 'encryptToolSnackbar',
                message: _jsxs('span', {
                  id: 'encryptToolSnackbar',
                  className: classes.message,
                  children: [
                    notificationSettings.variant === 'success'
                      ? _jsx(CheckCircleIcon, { className: `${classes.icon} ${classes.iconVariant}` })
                      : _jsx(ErrorIcon, { className: `${classes.icon} ${classes.iconVariant}` }),
                    formatMessage(
                      notificationSettings.variant === 'success' ? messages.successMessage : messages.errorMessage
                    )
                  ]
                }),
                action: [
                  _jsx(
                    IconButton,
                    {
                      'aria-label': 'close',
                      color: 'inherit',
                      onClick: () => setNotificationSettings({ open: false }),
                      size: 'large',
                      children: _jsx(CloseIcon, { className: classes.icon })
                    },
                    'close'
                  )
                ]
              })
            })
          ]
        })
      })
    ]
  });
};
export default EncryptTool;
