/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx } from 'react/jsx-runtime';
import Popover from '@mui/material/Popover';
import useStyles from './styles';
import AuditGridFilterPopoverBody from './AuditGridFilterPopoverBody';
export function AuditGridFilterPopover(props) {
  const { open, anchorPosition, onClose } = props;
  const { classes } = useStyles();
  return _jsx(Popover, {
    open: open,
    anchorPosition: anchorPosition,
    anchorReference: 'anchorPosition',
    onClose: onClose,
    classes: { paper: classes.popover },
    transformOrigin: {
      vertical: 'top',
      horizontal: 'center'
    },
    children: _jsx(AuditGridFilterPopoverBody, { ...props })
  });
}
export default AuditGridFilterPopover;
