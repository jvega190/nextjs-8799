/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from 'react/jsx-runtime';
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import useStyles from './styles';
import { defineMessages, FormattedMessage, useIntl } from 'react-intl';
import { useCallback, useMemo, useState } from 'react';
import ClearRoundedIcon from '@mui/icons-material/ClearRounded';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { AdapterMoment as DateAdapter } from '@mui/x-date-pickers/AdapterMoment';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import moment from 'moment-timezone';
import { useDebouncedInput } from '../../hooks/useDebouncedInput';
const translations = defineMessages({
  siteId: {
    id: 'auditGridFilterPopover.filterBySite',
    defaultMessage: 'Filter by Project'
  },
  user: {
    id: 'auditGridFilterPopover.filterByUser',
    defaultMessage: 'Filter by User'
  },
  origin: {
    id: 'auditGridFilterPopover.filterByOrigin',
    defaultMessage: 'Filter by Origin'
  },
  operations: {
    id: 'auditGridFilterPopover.filterByOperations',
    defaultMessage: 'Filter by Operations'
  },
  target: {
    id: 'auditGridFilterPopover.filterByTarget',
    defaultMessage: 'Filter by Target Value'
  },
  allOperations: {
    id: 'auditGridFilterPopover.allOperations',
    defaultMessage: 'All Operations'
  }
});
export function AuditGridFilterPopoverBody(props) {
  const { filterId, value, onFilterChange, timezone, onTimezoneSelected, onResetFilter, onClose } = props;
  const { classes } = useStyles();
  const { sites, users, operations, origins, timezones } = props.options;
  const { formatMessage } = useIntl();
  const [keyword, setKeyword] = useState(props.value ?? '');
  const [fromDate, setFromDate] = useState(props.dateFrom ? moment(props.dateFrom) : null);
  const [toDate, setToDate] = useState(props.dateTo ? moment(props.dateTo) : null);
  const onSearch = useCallback((keywords) => onFilterChange(filterId, keywords), [onFilterChange, filterId]);
  const onSearch$ = useDebouncedInput(onSearch, 400);
  const options = useMemo(() => {
    switch (filterId) {
      case 'siteId': {
        return [
          {
            id: 'all',
            value: 'all',
            name: _jsx(FormattedMessage, { id: 'auditGrid.allSites', defaultMessage: 'All Projects' })
          },
          {
            id: 'studio_root',
            value: 'studio_root',
            name: _jsx(FormattedMessage, { id: 'words.system', defaultMessage: 'System' })
          },
          ...sites.map((site) => ({ id: site.id, name: site.name, value: site.id }))
        ];
      }
      case 'user': {
        return [
          {
            id: 'all',
            value: 'all',
            name: _jsx(FormattedMessage, { id: 'auditGrid.allUsers', defaultMessage: 'All Users' })
          },
          ...users.map((user) => ({ id: user.id.toString(), name: user.username, value: user.username }))
        ];
      }
      case 'origin': {
        return [
          {
            id: 'all',
            value: 'all',
            name: _jsx(FormattedMessage, { id: 'auditGrid.allOrigins', defaultMessage: 'All Origins' })
          },
          ...origins
        ];
      }
      case 'operations': {
        return [
          {
            id: 'all',
            value: 'all',
            name: formatMessage(translations.allOperations)
          },
          ...operations
        ];
      }
    }
  }, [filterId, formatMessage, operations, origins, sites, users]);
  const onTextFieldChanges = (e) => {
    onSearch$.next(e.target.value);
    setKeyword(e.target.value);
  };
  const onMultipleSelectChanges = (e) => {
    const lastString = e.target.value[e.target.value.length - 1];
    if (lastString === 'all' || e.target.value.length === 0) {
      onFilterChange(filterId, 'all');
    } else {
      const values = e.target.value.filter((value) => value !== 'all');
      onFilterChange(filterId, values.join());
    }
  };
  const onFromDateSelected = (date) => {
    if (date.isValid()) {
      onFilterChange('dateFrom', date?.format() || 'all');
    }
    setFromDate(date);
  };
  const onToDateSelected = (date) => {
    if (date.isValid()) {
      onFilterChange('dateTo', date?.format() || 'all');
    }
    setToDate(date);
  };
  const onClearDates = () => {
    setToDate(null);
    setFromDate(null);
    onResetFilter(['dateFrom', 'dateTo']);
  };
  const onClearTextField = () => {
    onResetFilter(filterId);
    setKeyword('');
  };
  return _jsxs(_Fragment, {
    children: [
      _jsx(Box, {
        display: 'flex',
        justifyContent: 'end',
        marginBottom: '10px',
        children: _jsx(IconButton, { onClick: onClose, children: _jsx(ClearRoundedIcon, { fontSize: 'small' }) })
      }),
      filterId === 'operationTimestamp' &&
        _jsx(LocalizationProvider, {
          dateAdapter: DateAdapter,
          children: _jsxs('form', {
            noValidate: true,
            autoComplete: 'off',
            children: [
              _jsxs(Box, {
                className: classes.timestampFiltersContainer,
                children: [
                  _jsx(DateTimePicker, {
                    label: _jsx(FormattedMessage, { id: 'words.from', defaultMessage: 'From' }),
                    value: fromDate,
                    onChange: onFromDateSelected
                  }),
                  _jsx(DateTimePicker, {
                    label: _jsx(FormattedMessage, { id: 'words.to', defaultMessage: 'To' }),
                    value: toDate,
                    onChange: onToDateSelected
                  }),
                  _jsx(Button, {
                    className: classes.clearButton,
                    disabled: !toDate && !fromDate,
                    variant: 'text',
                    color: 'primary',
                    onClick: () => onClearDates(),
                    children: _jsx(FormattedMessage, { id: 'words.clear', defaultMessage: 'Clear' })
                  })
                ]
              }),
              _jsx(Autocomplete, {
                disableClearable: true,
                options: timezones,
                getOptionLabel: (option) => option,
                value: timezone,
                onChange: (e, value) => {
                  onTimezoneSelected(value);
                },
                fullWidth: true,
                renderInput: (params) =>
                  _jsx(TextField, {
                    ...params,
                    label: _jsx(FormattedMessage, { id: 'auditGrid.timezone', defaultMessage: 'Timezone' }),
                    variant: 'outlined'
                  })
              })
            ]
          })
        }),
      ['siteId', 'user', 'origin'].includes(filterId) &&
        _jsxs(Box, {
          display: 'flex',
          alignItems: 'center',
          children: [
            _jsx(TextField, {
              fullWidth: true,
              select: true,
              label: formatMessage(translations[filterId]),
              value: value ? value : 'all',
              onChange: (e) => onFilterChange(filterId, e.target.value),
              sx: { width: 200 },
              children: options.map((option) =>
                _jsx(MenuItem, { value: option.value, children: option.name }, option.id)
              )
            }),
            _jsx(Button, {
              className: classes.clearButton,
              disabled: !value,
              variant: 'text',
              color: 'primary',
              onClick: () => onResetFilter(filterId),
              children: _jsx(FormattedMessage, { id: 'words.clear', defaultMessage: 'Clear' })
            })
          ]
        }),
      filterId === 'operations' &&
        _jsxs(Box, {
          display: 'flex',
          alignItems: 'center',
          children: [
            _jsx(TextField, {
              fullWidth: true,
              select: true,
              label: formatMessage(translations[filterId]),
              value: value?.split(',') ?? ['all'],
              slotProps: {
                select: { multiple: true }
              },
              onChange: onMultipleSelectChanges,
              sx: { width: 200 },
              children: options.map((option) =>
                _jsx(MenuItem, { value: option.value, children: option.name }, option.id)
              )
            }),
            _jsx(Button, {
              className: classes.clearButton,
              disabled: !value,
              variant: 'text',
              color: 'primary',
              onClick: () => onResetFilter(filterId),
              children: _jsx(FormattedMessage, { id: 'words.clear', defaultMessage: 'Clear' })
            })
          ]
        }),
      'target' === filterId &&
        _jsx(TextField, {
          value: keyword,
          label: formatMessage(translations[filterId]),
          slotProps: {
            input: {
              endAdornment:
                keyword &&
                _jsx(Tooltip, {
                  title: _jsx(FormattedMessage, { id: 'words.clear', defaultMessage: 'Clear' }),
                  children: _jsx(IconButton, {
                    size: 'small',
                    className: classes.clearButton,
                    onClick: () => onClearTextField(),
                    children: _jsx(ClearRoundedIcon, {})
                  })
                })
            }
          },
          fullWidth: true,
          onChange: onTextFieldChanges
        })
    ]
  });
}
export default AuditGridFilterPopoverBody;
