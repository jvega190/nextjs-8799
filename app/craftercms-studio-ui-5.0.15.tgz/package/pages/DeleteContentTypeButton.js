/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from 'react/jsx-runtime';
import IconButton from '@mui/material/IconButton';
import DeleteRounded from '@mui/icons-material/DeleteRounded';
import DeleteContentTypeDialog from '../components/DeleteContentTypeDialog';
import { useEnhancedDialogState } from '../hooks/useEnhancedDialogState';
function DeleteContentTypeButton({ contentType, onComplete }) {
  const deleteContentTypeDialogState = useEnhancedDialogState();
  return _jsxs(_Fragment, {
    children: [
      _jsx(IconButton, {
        onClick: () => deleteContentTypeDialogState.onOpen(),
        size: 'large',
        children: _jsx(DeleteRounded, {})
      }),
      _jsx(DeleteContentTypeDialog, {
        open: deleteContentTypeDialogState.open,
        onClose: deleteContentTypeDialogState.onClose,
        isSubmitting: deleteContentTypeDialogState.isSubmitting,
        hasPendingChanges: deleteContentTypeDialogState.hasPendingChanges,
        isMinimized: deleteContentTypeDialogState.isMinimized,
        onSubmittingAndOrPendingChange: deleteContentTypeDialogState.onSubmittingAndOrPendingChange,
        contentType: contentType,
        onComplete: () => {
          deleteContentTypeDialogState.onClose();
          onComplete?.();
        }
      })
    ]
  });
}
export default DeleteContentTypeButton;
