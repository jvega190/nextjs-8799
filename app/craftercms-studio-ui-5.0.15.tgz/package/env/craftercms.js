/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { createRoot } from 'react-dom/client';
import * as reactJsxRuntime from 'react/jsx-runtime';
import * as MaterialUI from '@mui/material';
import * as ReactRedux from 'react-redux';
import * as ReactIntl from 'react-intl';
import * as rxjs from 'rxjs';
import { createAction } from '@reduxjs/toolkit';
import createEmotion from '@emotion/css/create-instance';
import { getStore, getStoreSync } from '../state/store';
import { registerPlugin } from '../services/plugin';
import { components, icons, services, utils } from './studioUI';
let UND;
const ReduxToolkit = { createAction };
const ReactDOMClient = { createRoot };
export const libs = {
  rxjs,
  React,
  ReactDOM,
  ReactDOMClient,
  ReactIntl,
  MaterialUI,
  ReactRedux,
  ReduxToolkit,
  createEmotion,
  react: React,
  reactJsxRuntime,
  'react/jsx-runtime': reactJsxRuntime,
  'react-dom': ReactDOM,
  'react-dom/client': ReactDOMClient,
  'react-redux': ReactRedux,
  'react-intl': ReactIntl,
  '@mui/material': MaterialUI,
  '@emotion/css/create-instance': createEmotion,
  '@reduxjs/toolkit': ReduxToolkit
};
// UMD builds wouldn't give the chance to track the file builder the plugin loads from
// unless the plugin descriptor provided the site, type, name & file args.
// An option would be including a query argument on the URL of the plugin with the expected ID e.g.
// `.../plugin/file?site=mySite&type=myType&name=myName&fileName=myFile&expectedPluginId=org.craftercms.samplePlugin`
// Upon receiving a call to `craftercms.define` and invoking the factory to get the plugin descriptor, get the id and
// try to find a script which matches `expectedPluginId=${pluginDescriptor.id}`. This might mean having to drop the
// use of dynamic import and use regular scripts as dynamic imports don't add a script to the DOM we could go find.
// Perhaps UMD shouldn't be supported; only support es module-style plugin bundle builds.
export const define = function (id, deps, factory) {
  // Anonymous modules
  if (typeof id !== 'string') {
    // Adjust args appropriately
    factory = deps;
    deps = id;
    id = null;
  }
  // This module may not have dependencies
  if (!Array.isArray(deps)) {
    factory = deps;
    deps = [];
  }
  const resolved = deps.map((dep) => {
    libs[dep] === UND &&
      console.error(
        `${id ? `The "${id}" plugin` : 'A plugin'} requires "${dep}" which is not provided by CrafterCMS. You should bundle this dependency with your plugin.`
      );
    return libs[dep];
  });
  const plugin = factory.apply(null, resolved);
  registerPlugin(plugin);
};
define.amd = true;
export const craftercms = {
  libs,
  define,
  getStore: getStoreSync,
  components,
  icons,
  services,
  utils,
  store$: getStore
};
export const publishCrafterGlobal = () => {
  window.craftercms = craftercms;
};
export default craftercms;
