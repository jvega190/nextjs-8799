/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { get, postJSON } from '../utils/ajax';
import { toQueryString } from '../utils/object';
import { map } from 'rxjs/operators';
export function list(siteId, cmisRepoId, options = {}) {
  const qs = toQueryString({
    siteId,
    cmisRepoId,
    ...options
  });
  return get(`/studio/api/2/cmis/list${qs}`).pipe(map((response) => response?.response?.items));
}
export function search(siteId, cmisRepoId, searchTerm, options = {}) {
  const qs = toQueryString({
    siteId,
    cmisRepoId,
    searchTerm,
    ...options
  });
  return get(`/studio/api/2/cmis/search${qs}`).pipe(map((response) => response?.response?.items));
}
export function clone(siteId, cmisRepoId, cmisPath, studioPath) {
  return postJSON(`/studio/api/2/cmis/clone`, {
    siteId,
    cmisRepoId,
    cmisPath,
    studioPath
  }).pipe(map(() => true));
}
