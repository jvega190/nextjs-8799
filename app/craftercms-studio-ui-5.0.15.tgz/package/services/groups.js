/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { toQueryString } from '../utils/object';
import { del, get, patchJSON, postJSON } from '../utils/ajax';
import { map } from 'rxjs/operators';
const paginationDefault = {
  limit: 100,
  offset: 0
};
export function fetchAll(options) {
  const mergedOptions = {
    ...paginationDefault,
    ...options
  };
  return get(`/studio/api/2/groups${toQueryString(mergedOptions)}`).pipe(
    map(({ response }) =>
      Object.assign(response.groups, {
        limit: response.limit < mergedOptions.limit ? mergedOptions.limit : response.limit,
        offset: response.offset,
        total: response.total
      })
    )
  );
}
export function fetchUsersFromGroup(id, options) {
  const qs = toQueryString({
    ...paginationDefault,
    options
  });
  return get(`/studio/api/2/groups/${id}/members${qs}`).pipe(
    map(({ response }) =>
      Object.assign(response.users, {
        limit: response.limit,
        offset: response.offset,
        total: response.total
      })
    )
  );
}
export function create(group) {
  return postJSON('/studio/api/2/groups', group).pipe(map((response) => response?.response?.group));
}
export function update(group) {
  return patchJSON(`/studio/api/2/groups`, group).pipe(map((response) => response?.response?.group));
}
export function trash(groupId) {
  return del(`/studio/api/2/groups?id=${groupId}`).pipe(map(() => true));
}
export function addUserToGroup(groupId, username) {
  return addUsersToGroup(groupId, [username]).pipe(map((response) => response[0]));
}
export function addUsersToGroup(groupId, idsOrUsernames) {
  return postJSON(`/studio/api/2/groups/${groupId}/members`, {
    [typeof idsOrUsernames[0] === 'string' ? 'usernames' : 'ids']: idsOrUsernames
  }).pipe(map((response) => response?.response?.users));
}
export function deleteUserFromGroup(groupId, usernameOrUserId) {
  // @ts-ignore - types are correct, signature to accept either is simply not published by deleteUsersFromGroup
  return deleteUsersFromGroup(groupId, [usernameOrUserId]);
}
export function deleteUsersFromGroup(groupId, usernamesOrUserIds) {
  const qs = toQueryString({
    [typeof usernamesOrUserIds[0] === 'string' ? 'username' : 'userId']: usernamesOrUserIds
  });
  return del(`/studio/api/2/groups/${groupId}/members${qs}`).pipe(map(() => true));
}
