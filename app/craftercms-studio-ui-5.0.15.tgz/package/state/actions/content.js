/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { createAction } from '@reduxjs/toolkit';
// region Quick Create
export const fetchQuickCreateList = /*#__PURE__*/ createAction('FETCH_QUICK_CREATE_LIST');
export const fetchQuickCreateListComplete = /*#__PURE__*/ createAction('FETCH_QUICK_CREATE_LIST_COMPLETE');
export const fetchQuickCreateListFailed = /*#__PURE__*/ createAction('FETCH_QUICK_CREATE_LIST_FAILED');
// endregion
// region Detailed Item
export const fetchDetailedItem = /*#__PURE__*/ createAction('FETCH_DETAILED_ITEM');
export const reloadDetailedItem = /*#__PURE__*/ createAction('RELOAD_DETAILED_ITEM');
export const completeDetailedItem = /*#__PURE__*/ createAction('COMPLETE_DETAILED_ITEM');
export const fetchDetailedItemComplete = /*#__PURE__*/ createAction('FETCH_DETAILED_ITEM_COMPLETE');
export const fetchDetailedItemFailed = /*#__PURE__*/ createAction('FETCH_DETAILED_ITEM_FAILED');
export const fetchDetailedItems = /*#__PURE__*/ createAction('COMPLETE_DETAILED_ITEMS');
export const fetchDetailedItemsComplete = /*#__PURE__*/ createAction('FETCH_DETAILED_ITEMS_COMPLETE');
export const fetchDetailedItemsFailed = /*#__PURE__*/ createAction('FETCH_DETAILED_ITEMS_FAILED');
export const fetchSandboxItem = /*#__PURE__*/ createAction('FETCH_SANDBOX_ITEM');
export const fetchSandboxItems = /*#__PURE__*/ createAction('FETCH_SANDBOX_ITEMS');
export const fetchSandboxItemComplete = /*#__PURE__*/ createAction('FETCH_SANDBOX_ITEM_COMPLETE');
export const fetchSandboxItemsComplete = /*#__PURE__*/ createAction('FETCH_SANDBOX_ITEMS_COMPLETE');
export const fetchSandboxItemFailed = /*#__PURE__*/ createAction('FETCH_SANDBOX_ITEM_FAILED');
export const fetchSandboxItemsFailed = /*#__PURE__*/ createAction('FETCH_SANDBOX_ITEMS_FAILED');
export const sandboxItemsMissing = /*#__PURE__*/ createAction('SANDBOX_ITEMS_MISSING');
// endregion
export const updateItemsByPath = /*#__PURE__*/ createAction('UPDATE_ITEMS_BY_PATH');
// region Clipboard
export const setClipboard = /*#__PURE__*/ createAction('SET_CLIPBOARD');
export const restoreClipboard = /*#__PURE__*/ createAction('RESTORE_CLIPBOARD');
export const clearClipboard = /*#__PURE__*/ createAction('CLEAR_CLIPBOARD');
// endregion
// region itemsActions
export const duplicateItem = /*#__PURE__*/ createAction('DUPLICATE_ITEM');
export const duplicateAsset = /*#__PURE__*/ createAction('DUPLICATE_ASSET');
export const duplicateWithPolicyValidation = /*#__PURE__*/ createAction('DUPLICATE_WITH_POLICY_VALIDATION');
export const pasteItem = /*#__PURE__*/ createAction('PASTE_ITEM');
export const pasteItemWithPolicyValidation = /*#__PURE__*/ createAction('PASTE_ITEM_WITH_POLICY_VALIDATION');
export const unlockItem = /*#__PURE__*/ createAction('UNLOCK_ITEM');
export const unlockItemCompleted = /*#__PURE__*/ createAction('UNLOCK_ITEM_COMPLETED');
export const unlockItemFailed = /*#__PURE__*/ createAction('LOCK_ITEM_FAILED');
export const lockItem = /*#__PURE__*/ createAction('LOCK_ITEM');
export const lockItemCompleted = /*#__PURE__*/ createAction('LOCK_ITEM_COMPLETED');
export const lockItemFailed = /*#__PURE__*/ createAction('LOCK_ITEM_FAILED');
// This action's semantic is to unlock the item only if the lock owner is the current user.
export const conditionallyUnlockItem = /*#__PURE__*/ createAction('CONDITIONALLY_UNLOCK_ITEM');
export const deleteController = /*#__PURE__*/ createAction('DELETE_CONTROLLER');
export const deleteTemplate = /*#__PURE__*/ createAction('DELETE_TEMPLATE');
// endregion
