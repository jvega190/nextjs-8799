import { GuestStore } from './models/GuestStore';
import { IntlShape } from 'react-intl';
export type GuestEpicMiddlewareDependencies = {
    getIntl: () => IntlShape;
};
export declare function createGuestStore(): GuestStore;
export default createGuestStore;
