import { GuestStore } from './models/GuestStore';
export declare function createGuestStore(): GuestStore;
export default createGuestStore;
