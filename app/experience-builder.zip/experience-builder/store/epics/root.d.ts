import { GuestStandardAction } from '../models/GuestStandardAction';
import { GuestState } from '../models/GuestStore';
declare const epic: import("redux-observable").Epic<GuestStandardAction, GuestStandardAction, GuestState, any>;
export default epic;
