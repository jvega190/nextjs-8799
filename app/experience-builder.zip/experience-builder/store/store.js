/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { createEpicMiddleware } from 'redux-observable';
import { configureStore } from '@reduxjs/toolkit';
import epic from './epics/root';
import reducer from './reducers/root';
let store;
export function createGuestStore() {
    if (store) {
        return store;
    }
    const epicMiddleware = createEpicMiddleware();
    store = configureStore({
        reducer,
        middleware: (getDefaultMiddleware) => getDefaultMiddleware({
            thunk: false,
            // serializable is not good companion while we have
            // non-serializable values on the state (elements).
            serializableCheck: false,
            // immutable is causing max stack issues, probably also due
            // to the non-serializable values on the state.
            immutableCheck: false
        }).concat(epicMiddleware),
        devTools: { name: 'Guest Store' }
        // devTools: process.env.NODE_ENV === 'production' ? false : { name: 'Guest Store' }
    });
    epicMiddleware.run(epic);
    return store;
}
export default createGuestStore;
