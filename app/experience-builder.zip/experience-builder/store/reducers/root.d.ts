import { GuestState } from '../models/GuestStore';
import { ReducerWithInitialState } from '@reduxjs/toolkit/src/createReducer';
declare const reducer: ReducerWithInitialState<GuestState>;
export default reducer;
