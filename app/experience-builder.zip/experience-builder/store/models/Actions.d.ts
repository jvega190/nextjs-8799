import { GuestStandardAction } from './GuestStandardAction';
import { SyntheticEvent } from 'react';
import { ElementRecord } from '../../models/InContextEditing';
import GuestReducer from './GuestReducer';
import { assetDragEnded, assetDragStarted, clearContentTreeFieldSelected, clearHighlightedDropTargets, componentDragEnded, componentDragStarted, componentInstanceDragEnded, componentInstanceDragStarted, contentTreeFieldSelected, contentTreeSwitchFieldInstance, contentTypeDropTargetsRequest, highlightModeChanged, hostCheckIn, setPreviewEditMode, trashed, updateRteConfig } from '@craftercms/studio-ui/state/actions/preview';
import { Observable } from 'rxjs';
import { addAssetTypes, computedDragEnd, computedDragOver, contentReady, desktopAssetDragEnded, desktopAssetDragStarted, documentDragEnd, documentDragLeave, documentDragOver, documentDrop, dropzoneEnter, dropzoneLeave, editComponentInline, exitComponentInlineEdit, iceZoneSelected, insertComponent, insertInstance, moveComponent, scrolling, scrollingStopped, setDropPosition, setEditMode, startListening, desktopAssetUploadComplete, desktopAssetUploadProgress, desktopAssetUploadStarted } from '../actions';
export type GuestActionTypes = 'mouseover' | 'mouseleave' | 'dragstart' | 'dragover' | 'dragleave' | 'drop' | 'dragend' | 'click' | 'dblclick' | typeof setDropPosition.type | typeof addAssetTypes.type | typeof moveComponent.type | typeof insertComponent.type | typeof insertInstance.type | typeof computedDragEnd.type | typeof computedDragOver.type | typeof iceZoneSelected.type | typeof editComponentInline.type | typeof exitComponentInlineEdit.type | typeof setEditMode.type | typeof startListening.type | typeof scrolling.type | typeof scrollingStopped.type | typeof dropzoneEnter.type | typeof dropzoneLeave.type | typeof componentDragStarted.type | typeof componentDragEnded.type | typeof componentInstanceDragStarted.type | typeof componentInstanceDragEnded.type | typeof desktopAssetDragStarted.type | typeof desktopAssetUploadStarted.type | typeof desktopAssetUploadProgress.type | typeof desktopAssetUploadComplete.type | typeof desktopAssetDragEnded.type | typeof assetDragStarted.type | typeof assetDragEnded.type | typeof trashed.type | typeof setPreviewEditMode.type | typeof highlightModeChanged.type | typeof clearHighlightedDropTargets.type | typeof contentTypeDropTargetsRequest.type | typeof hostCheckIn.type | typeof contentTreeFieldSelected.type | typeof clearContentTreeFieldSelected.type | typeof contentTreeSwitchFieldInstance.type | typeof updateRteConfig.type | typeof documentDragOver.type | typeof documentDragLeave.type | typeof documentDrop.type | typeof documentDragEnd.type | typeof contentReady.type;
export type MouseEventAction = GuestStandardAction<{
    event: SyntheticEvent<Element, MouseEvent> | MouseEvent;
    record: ElementRecord;
}>;
export type WithRecordAction = GuestReducer<{
    record: ElementRecord;
}>;
export type MouseEventActionObservable = Observable<GuestStandardAction>;
