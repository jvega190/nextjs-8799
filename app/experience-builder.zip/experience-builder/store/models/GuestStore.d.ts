import { EnhancedStore } from '@reduxjs/toolkit';
import { GuestStandardAction } from './GuestStandardAction';
import { DropZone, ICERecord } from '../../models/InContextEditing';
import { LookupTable } from '@craftercms/studio-ui/models/LookupTable';
import { StateObservable } from 'redux-observable';
import ContentType from '@craftercms/studio-ui/models/ContentType';
import { ContentInstance } from '@craftercms/studio-ui/models/ContentInstance';
import { EditingStatus } from '../../constants';
import { RteConfig } from '../../models/Rte';
import Person from '@craftercms/studio-ui/models/Person';
import { SearchItem } from '@craftercms/studio-ui/models';
interface T {
    [K: string]: any;
}
export interface GuestState {
    dragContext: {
        targetIndex: number;
        inZone: boolean;
        invalidDrop?: boolean;
        dropZone?: DropZone;
        players: any[];
        siblings: any[];
        containers: any[];
        over?: any;
        prev?: any;
        next?: any;
        coordinates?: any;
        dragged: ICERecord | DataTransferItem | SearchItem;
        dropZones: DropZone[];
        scrolling?: boolean;
        contentType?: ContentType;
        instance?: ContentInstance;
        isInstanceDuplicateInZone?: boolean;
    };
    hostCheckedIn: boolean;
    status: EditingStatus;
    editMode: boolean;
    highlightMode: string;
    authoringBase: string;
    editModePadding: boolean;
    editable: T;
    draggable: T;
    highlighted: T;
    uploading: LookupTable;
    lockedPaths: LookupTable<{
        user: Person;
    }>;
    externallyModifiedPaths: LookupTable<{
        user: Person;
    }>;
    contentTypes: LookupTable<ContentType>;
    fieldSwitcher?: {
        iceId: number;
        currentElement: number;
        registryEntryIds: number[];
    };
    rteConfig: RteConfig;
    activeSite: string;
    username: string;
}
export type GuestStateObservable = StateObservable<GuestState>;
export type GuestStore = EnhancedStore<GuestState, GuestStandardAction>;
export {};
