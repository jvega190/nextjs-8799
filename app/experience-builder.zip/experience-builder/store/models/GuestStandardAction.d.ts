import StandardAction from '@craftercms/studio-ui/models/StandardAction';
import { GuestActionTypes } from './Actions';
export type GuestStandardAction<Payload extends {} = any> = StandardAction<Payload, GuestActionTypes>;
