import { Observable, ReplaySubject, Subject } from 'rxjs';
import { ElementRecord } from '../models/InContextEditing';
import { SyntheticEvent } from 'react';
import { GuestStateObservable } from './models/GuestStore';
import { GuestStandardAction } from './models/GuestStandardAction';
export declare const clearAndListen$: Subject<void>;
export declare const escape$: Observable<KeyboardEvent>;
export declare const guestCheckIn$: ReplaySubject<boolean>;
declare const getDragOver: () => Subject<{
    event: DragEvent | SyntheticEvent | Event;
    record: ElementRecord;
}>;
declare const getScrolling: () => Observable<Event>;
export { getDragOver as dragover$, getScrolling as scrolling$ };
export declare function initializeDragSubjects(state$: GuestStateObservable): Observable<GuestStandardAction>;
export declare function destroyDragSubjects(): void;
