import { SyntheticEvent } from 'react';
import { Observable } from 'rxjs';
import { ContentItem } from '@craftercms/studio-ui/models';
import { GuestState } from './models/GuestStore';
import { ElementRecord } from '../models/InContextEditing';
export declare function dragOk(status: any): boolean;
export declare function unwrapEvent<T extends Event>(event: SyntheticEvent | Event): T;
export interface BeforeWriteProps<T = 'continue', S = never> {
    path: string;
    site: string;
    username: string;
    stop$?: Observable<S> | S[];
    continue$?: Observable<T> | T[];
    localItem: ContentItem;
}
/**
 * Locks the target item, checks workflow state and checks for background changes
 * to the target. If all goes well, continues (returning the `continue$` stream). If
 * can't continue with the target operation, it returns the `stop$` stream (never, by default).
 */
export declare function beforeWrite$<T extends any = 'continue', S extends any = never>(props: BeforeWriteProps<T, S>): Observable<T | S>;
/**
 * Checks if the target item is locked and checks for background changes. Returns all the objects
 * it uses to compute the result, so they can be used by consumer if needed.
 */
export declare const checkIfLockedOrModified: (state: GuestState, record: ElementRecord) => {
    isLocked: boolean;
    isExternallyModified: boolean;
    model: import("@craftercms/studio-ui/models").ContentInstance;
    parentModelId: string;
    parentModel: import("@craftercms/studio-ui/models").ContentInstance;
    path: string;
    isLockedByCurrentUser: boolean;
};
/**
 * From a dragContext of a component being moved, returns an object with the following properties:
 * movedToSameZone: boolean
 * movedToSamePosition: boolean
 * draggedElementIndex: number
 * targetIndex: number
 */
export declare const getMoveComponentInfo: (dragContext: GuestState["dragContext"]) => {
    movedToSameZone: boolean;
    movedToSamePosition: boolean;
    draggedElementIndex: number;
    targetIndex: number;
};
