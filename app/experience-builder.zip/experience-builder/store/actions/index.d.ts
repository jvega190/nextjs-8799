import { ElementRecord } from '../../models/InContextEditing';
import { EditingStatus } from '../../constants';
import { SandboxItem } from '@craftercms/studio-ui/models';
export declare const contentReady: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"content_ready">;
export declare const setDropPosition: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    targetIndex: number;
}, string>;
export declare const addAssetTypes: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"add_asset_types">;
export declare const moveComponent: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"move_component">;
export declare const insertComponent: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"insert_component">;
export declare const insertInstance: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"insert_instance">;
export declare const computedDragEnd: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"computed_dragend">;
export declare const computedDragOver: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    record: ElementRecord;
    event: any;
}, string>;
export declare const iceZoneSelected: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    record: ElementRecord;
    event: any;
}, string>;
export declare const editComponentInline: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"edit_component_inline">;
export declare const exitComponentInlineEdit: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    path: string;
    saved: boolean;
}, string>;
export declare const setEditMode: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"set_edit_mode">;
export declare const startListening: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"start_listening">;
export declare const scrolling: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"scrolling">;
export declare const scrollingStopped: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"scrolling_stopped">;
export declare const dropzoneEnter: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    elementRecordId: number;
}, string>;
export declare const dropzoneLeave: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    elementRecordId: number;
}, string>;
export declare const documentDragOver: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    event: Event;
}, string>;
export declare const documentDragLeave: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    event: Event;
}, string>;
export declare const documentDrop: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    event: Event;
}, string>;
export declare const documentDragEnd: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    event: Event;
}, string>;
export declare const desktopAssetDragStarted: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    asset: DataTransferItem;
}, string>;
export declare const desktopAssetDragEnded: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"desktop_asset_drag_ended">;
export declare const setEditingStatus: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    status: EditingStatus;
}, string>;
export declare const desktopAssetUploadComplete: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    record: ElementRecord;
    path: string;
}, string>;
export declare const desktopAssetUploadProgress: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    record: ElementRecord;
    percentage: number;
}, string>;
export declare const desktopAssetUploadStarted: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    record: ElementRecord;
}, string>;
export declare const desktopAssetUploadFailed: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<{
    record: ElementRecord;
}, string>;
export declare const setLockedItems: import("@reduxjs/toolkit").ActionCreatorWithOptionalPayload<SandboxItem[], string>;
