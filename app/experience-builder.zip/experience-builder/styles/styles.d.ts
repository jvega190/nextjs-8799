import { Theme, ThemeOptions } from '@mui/material';
import { DropMarkerPartialSx, ZoneMarkerPartialSx } from '../react';
import { SxProps } from '@mui/system';
export declare function useGuestTheme(styleConfig: ThemeOptions): Theme;
type GuestStyleSxKeys = 'base' | 'selectModeHighlight' | 'moveModeHighlight';
export interface GuestStylesSx {
    zoneMarker: Record<GuestStyleSxKeys | 'errorHighlight' | 'warnHighlight' | 'disabledHighlight', ZoneMarkerPartialSx>;
    dropMarker: Record<GuestStyleSxKeys, DropMarkerPartialSx>;
    ghostElement: SxProps<Theme>;
}
export declare const styleSxDefaults: Partial<GuestStylesSx>;
export {};
