import { jsx as _jsx } from "react/jsx-runtime";
import { createRoot } from 'react-dom/client';
import ExperienceBuilder from './react/ExperienceBuilder';
import GuestProxy from './react/GuestProxy';
import { nnou } from '@craftercms/studio-ui/utils/object';
import * as elementRegistry from './elementRegistry';
import * as iceRegistry from './iceRegistry';
import * as contentController from './contentController';
import { fromTopic, post } from './utils/communicator';
import queryString from 'query-string';
import { crafterConf } from '@craftercms/classes';
import { fetchIsAuthoring } from '@craftercms/ice';
import { xbLoadedEvent } from './constants';
import { foo } from './utils/util';
import { guestCheckIn$ as guestCheckInInternal$ } from './store/subjects';
import { filter, take } from 'rxjs/operators';
export function getICEAttributes(config) {
    let { model, modelId, path, fieldId, index, label, isAuthoring = true } = config;
    let attributes = {};
    if (!isAuthoring) {
        return attributes;
    }
    attributes['data-craftercms-model-id'] = model?.craftercms.id ?? modelId;
    attributes['data-craftercms-model-path'] = model?.craftercms.path ?? path;
    nnou(fieldId) && (attributes['data-craftercms-field-id'] = fieldId);
    nnou(index) && (attributes['data-craftercms-index'] = index);
    nnou(label) && (attributes['data-craftercms-label'] = label);
    return attributes;
}
export { fetchIsAuthoring };
export function addAuthoringSupport(config) {
    config = crafterConf.mix(config);
    return new Promise((resolve) => {
        const script = document.createElement('script');
        script.src = `${config.baseUrl}/studio/static-assets/scripts/craftercms-xb.umd.js`;
        script.addEventListener('load', () => {
            // @ts-ignore
            resolve(window.craftercms?.xb);
        });
        document.head.appendChild(script);
    });
}
export function initExperienceBuilder(props) {
    const guestProxyElement = document.createElement('craftercms-guest-proxy');
    const { crafterCMSGuestDisabled } = queryString.parse(window.location.search);
    if (crafterCMSGuestDisabled !== 'true') {
        const root = createRoot(guestProxyElement);
        root.render(
        // @ts-ignore - typing system is not playing nice with the {path} | {model} options of GuestProps
        _jsx(ExperienceBuilder, { isAuthoring: crafterCMSGuestDisabled !== 'true', ...props, children: crafterCMSGuestDisabled !== 'true' && _jsx(GuestProxy, {}) }));
        return { unmount: () => root.unmount() };
    }
    else {
        return { unmount: foo };
    }
}
/** @deprecated Use `initExperienceBuilder` instead. */
export const initInContextEditing = initExperienceBuilder;
export const guestCheckIn$ = guestCheckInInternal$.pipe(filter((checkedIn) => checkedIn), take(1));
export { elementRegistry, iceRegistry, contentController, fromTopic, post };
typeof document !== 'undefined' && setTimeout(() => document?.dispatchEvent(new CustomEvent(xbLoadedEvent)));
export function registerElements(container) {
    if (container) {
        container.querySelectorAll('[data-craftercms-model-id]').forEach((element) => {
            elementRegistry.register({
                element: element,
                path: element.getAttribute('data-craftercms-model-path'),
                modelId: element.getAttribute('data-craftercms-model-id'),
                fieldId: element.getAttribute('data-craftercms-field-id'),
                index: element.getAttribute('data-craftercms-index'),
                label: element.getAttribute('data-craftercms-label')
            });
        });
    }
}
export function deregisterElements(container) {
    if (container) {
        const elements = container.querySelectorAll('[data-craftercms-model-id]');
        elements.forEach((element) => {
            let record = elementRegistry.fromElement(element);
            elementRegistry.deregister(record?.id);
        });
    }
}
