import { ExperienceBuilderProps } from './react/ExperienceBuilder';
import ContentInstance from '@craftercms/studio-ui/models/ContentInstance';
import * as elementRegistry from './elementRegistry';
import * as iceRegistry from './iceRegistry';
import * as contentController from './contentController';
import { fromTopic, post } from './utils/communicator';
import { fetchIsAuthoring, BaseCrafterConfig } from '@craftercms/ice';
export interface ICEAttributes {
    'data-craftercms-model-path': string;
    'data-craftercms-model-id': string;
    'data-craftercms-field-id'?: string;
    'data-craftercms-index'?: string | number;
    'data-craftercms-label'?: string;
    'data-craftercms-type'?: 'collection';
}
export type ICEConfig = {
    isAuthoring: boolean;
    fieldId?: string;
    index?: string | number;
    label?: string;
    model?: ContentInstance;
    modelId?: string;
    path?: string;
} & ({
    model: ContentInstance;
} | {
    modelId: string;
    path: string;
});
export declare function getICEAttributes(config: ICEConfig): ICEAttributes;
export { fetchIsAuthoring };
export declare function addAuthoringSupport(config?: Partial<BaseCrafterConfig>): Promise<any>;
export declare function initExperienceBuilder(props: ExperienceBuilderProps): {
    unmount: (...args: any[]) => any;
};
/** @deprecated Use `initExperienceBuilder` instead. */
export declare const initInContextEditing: typeof initExperienceBuilder;
export declare const guestCheckIn$: import("rxjs").Observable<boolean>;
export { elementRegistry, iceRegistry, contentController, fromTopic, post };
export declare function registerElements(container: HTMLElement): void;
export declare function deregisterElements(container: HTMLElement): void;
