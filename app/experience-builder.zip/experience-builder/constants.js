/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
export var EditingStatus;
(function (EditingStatus) {
    EditingStatus["LISTENING"] = "LISTENING";
    EditingStatus["SORTING_COMPONENT"] = "SORTING_COMPONENT";
    EditingStatus["PLACING_NEW_COMPONENT"] = "PLACING_NEW_COMPONENT";
    EditingStatus["PLACING_DETACHED_COMPONENT"] = "PLACING_DETACHED_COMPONENT";
    EditingStatus["PLACING_DETACHED_ASSET"] = "PLACING_DETACHED_ASSET";
    EditingStatus["EDITING_COMPONENT"] = "EDITING_COMPONENT";
    EditingStatus["EDITING_COMPONENT_INLINE"] = "EDITING_COMPONENT_INLINE";
    EditingStatus["UPLOAD_ASSET_FROM_DESKTOP"] = "UPLOAD_ASSET_FROM_DESKTOP";
    EditingStatus["SHOW_DROP_TARGETS"] = "SHOW_DROP_TARGETS";
    EditingStatus["FIELD_SELECTED"] = "FIELD_SELECTED";
    EditingStatus["HIGHLIGHT_MOVE_TARGETS"] = "HIGHLIGHT_MOVE_TARGETS";
})(EditingStatus || (EditingStatus = {}));
export var HighlightMode;
(function (HighlightMode) {
    HighlightMode["ALL"] = "all";
    HighlightMode["MOVE_TARGETS"] = "move";
})(HighlightMode || (HighlightMode = {}));
export const editOnClass = 'craftercms-ice-on';
export const iceBypassKeyClass = 'craftercms-ice-bypass';
export const moveModeClass = `craftercms-highlight-${HighlightMode.MOVE_TARGETS}`;
export const editModeClass = `craftercms-highlight-${HighlightMode.ALL}`;
export const emptyCollectionClass = 'craftercms-empty-collection';
export const emptyFieldClass = 'craftercms-empty-field';
export const dragAndDropActiveClass = 'craftercms-drag-n-drop-active';
export const editModePaddingClass = 'craftercms-edit-mode-padding';
export const eventCaptureOverlayAttribute = 'data-craftercms-event-capture-overlay';
export const editModeEvent = 'craftercms.editMode';
export const xbLoadedEvent = 'craftercms.xb:loaded';
export const editModeIceBypassEvent = 'craftercms.iceBypass';
