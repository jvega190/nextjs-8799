import { DropZone, ElementRecord, ElementRecordRegistration, HighlightData, ICERecord } from './models/InContextEditing';
import { ValidationResult } from '@craftercms/studio-ui/models/ContentType';
import { RegistryEntry } from './models/Registry';
import { LookupTable } from '@craftercms/studio-ui/models/LookupTable';
declare let db: LookupTable<ElementRecord>;
export declare function get(id: number): ElementRecord;
export declare function setLabel(record: ElementRecord): void;
export declare function register(payload: ElementRecordRegistration): number;
export declare function completeDeferredRegistration(id: number): void;
export declare function deregister(id: string | number): ElementRecord;
/**
 * Returns the ICE id of the first movable ICE record on the
 * specified element record or false if none is movable.
 * */
export declare function getDraggable(id: number): number | boolean;
export declare function getHoverData(id: number): HighlightData;
export declare function getRect(id: number): DOMRect;
export declare function createIntermediateElementRecord(record: ElementRecord, iceId: number): RegistryEntry;
export declare function fromICEId(iceId: number): RegistryEntry;
export declare function getRecordsFromIceId(iceId: number): RegistryEntry[];
export declare function compileDropZone(iceId: number): DropZone;
export declare function compileAllDropZones(iceId: number): DropZone[];
export declare function getSiblingRects(id: number): LookupTable<DOMRect>;
export declare function fromElement(element: Element): ElementRecord;
export declare function hasElement(element: Element): boolean;
export declare function getHighlighted(dropZones: DropZone[]): LookupTable<HighlightData>;
export declare function getDragContextFromDropTargets(dropTargets: ICERecord[], validationsLookup?: LookupTable<LookupTable<ValidationResult>>, currentRecord?: ElementRecord): {
    dropZones: DropZone[];
    siblings: Element[];
    players: Element[];
    containers: Element[];
};
export declare function getElementFromICEProps(modelId: string, fieldId: string, index: string | number): Element;
/**
 * Retrieves the parent node (drop target/zone) of an item
 */
export declare function getParentElementFromICEProps(modelId: string, fieldId: string, index: string | number): HTMLElement;
/**
 * Retrieves all the drop targets elements that host a give ice record
 */
export declare function getParentsElementFromICEProps(modelId: string, fieldId: string, index: string | number): Element[];
export declare function flush(): void;
export declare function getRegistry(): typeof db;
export {};
