import { jsx as _jsx } from "react/jsx-runtime";
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { forwardRef } from 'react';
import { useICE } from './hooks';
import { getCachedContentType } from '../contentController';
// Field component is a slightly lighter/simpler version of RenderField. It has less options to render (e.g. no renderTarget, render)
// Registers the zone but doesn't render the field value, so values don't get repainted when changed.
export const Field = forwardRef(function (props, ref) {
    const { model: modelProp, fieldId, index, component = 'div', componentProps, ...other } = props;
    const { props: ice, model } = useICE({
        model: modelProp,
        fieldId: fieldId === '__CRAFTERCMS_FAKE_FIELD__' ? void 0 : fieldId,
        index,
        ref
    });
    const Component = component;
    const passDownProps = {
        ...other,
        ...ice,
        ...componentProps,
        // If the component is an html element, `model` would end up written as an
        // attribute model="[object Object]".
        ...(typeof component === 'string' ? {} : { model })
    };
    // `data-craftercms-field` attribute is added to all fields for the elements to get the XB on hover cursor styles.
    // `data-craftercms-type="collection"` attribute is added to node-selector and repeat fields for the elements to get
    // the XB padding mode styles.
    const contentTypeId = model.craftercms.contentTypeId;
    const contentType = getCachedContentType(contentTypeId);
    const field = contentType?.fields[fieldId];
    passDownProps['data-craftercms-field'] = '';
    if (field && ['node-selector', 'repeat'].includes(field.type)) {
        passDownProps['data-craftercms-type'] = 'collection';
    }
    return _jsx(Component, { ...passDownProps });
});
export default Field;
