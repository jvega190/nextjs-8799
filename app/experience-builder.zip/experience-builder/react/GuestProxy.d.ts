export declare function GuestProxy(): import("react/jsx-runtime").JSX.Element;
export default GuestProxy;
