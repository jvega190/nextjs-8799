import { Coordinates } from '../models/Positioning';
import { DropZone, ElementRecord } from '../models/InContextEditing';
import { FullSxRecord, PartialSxRecord } from '@craftercms/studio-ui/models/CustomRecord';
export type DropMarkerClassKey = 'root' | 'tips' | 'horizontal' | 'vertical';
export type DropMarkerFullSx = FullSxRecord<DropMarkerClassKey>;
export type DropMarkerPartialSx = PartialSxRecord<DropMarkerClassKey>;
export interface DropMarkerProps {
    over: ElementRecord;
    prev: DOMRect;
    next: DOMRect;
    dropZone: DropZone;
    coordinates: Coordinates;
    onDropPosition: Function;
    sx?: DropMarkerPartialSx;
}
export declare function DropMarker(props: DropMarkerProps): import("react/jsx-runtime").JSX.Element;
export default DropMarker;
