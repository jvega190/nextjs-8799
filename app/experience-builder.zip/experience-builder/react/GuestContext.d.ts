import React from 'react';
import { GuestState } from '../store/models/GuestStore';
import { EqualityFn, ReactReduxContextValue } from 'react-redux';
import { Dispatch, Store } from 'redux';
import { HighlightMode, StandardAction } from '@craftercms/studio-ui/models';
export type GuestContextProps = {
    hasHost: boolean;
    editMode: boolean;
    draggable: GuestState['draggable'];
    highlightMode: HighlightMode;
    onEvent: (event: any, elementRegistryId?: number) => any;
};
export declare const GuestReduxContext: React.Context<ReactReduxContextValue>;
export declare const useDispatch: () => Dispatch<StandardAction>;
interface UseSelector {
    <TState = unknown, Selected = unknown>(selector: (state: TState) => Selected, equalityFn?: EqualityFn<Selected>): Selected;
}
export declare const useSelector: UseSelector;
export declare const useStore: () => Store<GuestState, StandardAction>;
export declare function useGuestContext(): GuestContextProps;
export declare function useIsAuthoring(): boolean;
export declare function GuestContextProvider(props: any): React.JSX.Element;
export {};
