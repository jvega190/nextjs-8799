import { jsx as _jsx } from "react/jsx-runtime";
import { Box } from '@mui/material';
export function DragGhostElement(props) {
    return (_jsx(Box, { className: "craftercms-dragged-element", sx: {
            display: 'block',
            maxWidth: 200,
            backgroundColor: 'common.white',
            color: 'text.secondary',
            padding: '5px 10px',
            borderRadius: 1,
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
            overflow: 'hidden',
            position: 'absolute',
            // top: -1000,
            left: -1000,
            ...props.sx
        }, children: props.label }));
}
export default DragGhostElement;
