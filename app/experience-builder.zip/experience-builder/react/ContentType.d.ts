import React, { ComponentType, ElementType, PropsWithChildren } from 'react';
import ContentInstance from '@craftercms/studio-ui/models/ContentInstance';
export type PropsWithModel = PropsWithChildren<{
    model: ContentInstance;
}>;
export interface ContentTypeProps<P extends PropsWithModel = PropsWithModel> {
    model: ContentInstance;
    contentTypeMap: Record<string, ElementType<P>>;
    notFoundComponent?: ComponentType<P>;
    notMappedComponent?: ComponentType<P>;
}
export declare function NotFoundDefault(): import("react/jsx-runtime").JSX.Element;
export declare function NotDevelopedDefault(): import("react/jsx-runtime").JSX.Element;
export declare const defaultContentTypeMap: Record<string, ElementType<any>>;
export declare const ContentType: React.ForwardRefExoticComponent<ContentTypeProps<PropsWithModel> & React.RefAttributes<any>>;
export default ContentType;
