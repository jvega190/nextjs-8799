import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import * as React from 'react';
import { useEffect, useMemo, useState } from 'react';
import DragIndicatorRounded from '@mui/icons-material/DragIndicatorRounded';
import PencilIcon from '@mui/icons-material/EditOutlined';
import ArrowDownwardRoundedIcon from '@mui/icons-material/ArrowDownwardRounded';
import ArrowUpwardRoundedIcon from '@mui/icons-material/ArrowUpwardRounded';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import GroovyIcon from '@craftercms/studio-ui/icons/Groovy';
import FreemarkerIcon from '@craftercms/studio-ui/icons/Freemarker';
import UltraStyledIconButton from './UltraStyledIconButton';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import MoreRoundedIcon from '@mui/icons-material/MoreVertRounded';
import AddCircleOutlineRoundedIcon from '@mui/icons-material/AddCircleOutlineRounded';
import ContentCopyRoundedIcon from '@mui/icons-material/ContentCopyRounded';
import { deleteItem, duplicateItem, getCachedModel, getCachedModels, getCachedPermissions, getCachedSandboxItem, getModelIdFromInheritedField, insertItem, isInheritedField, modelHierarchyMap, sortDownItem, sortUpItem } from '../contentController';
import { clearAndListen$ } from '../store/subjects';
import { startListening } from '../store/actions';
import { extractCollection, findParentModelId } from '@craftercms/studio-ui/utils/model';
import { isSimple, popPiece } from '@craftercms/studio-ui/utils/string';
import useRef from '@craftercms/studio-ui/hooks/useUpdateRefs';
import { exists, findContainerRecord, getById, getReferentialEntries, runValidation } from '../iceRegistry';
import { post } from '../utils/communicator';
import { requestEdit, snackGuestMessage } from '@craftercms/studio-ui/state/actions/preview';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import { getParentModelId } from '../utils/ice';
import { fromICEId, get } from '../elementRegistry';
import { beforeWrite$ } from '../store/util';
import { useStore } from './GuestContext';
import UltraStyledTypography from './UltraStyledTypography';
import UltraStyledTooltip from './UltraStyledTooltip';
import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';
import { showItemMegaMenu } from '@craftercms/studio-ui/state/actions/dialogs';
import { FormattedMessage } from 'react-intl';
export function ZoneMenu(props) {
    const { record, dispatch, isHeadlessMode, isLockedItem = false } = props;
    const { modelId, fieldId: [fieldId], index } = record;
    const permissions = getCachedPermissions();
    const models = getCachedModels();
    const parentModelId = getParentModelId(modelId, models, modelHierarchyMap);
    const modelPath = isInheritedField(modelId, fieldId)
        ? models[getModelIdFromInheritedField(modelId, fieldId)].craftercms.path
        : (models[modelId].craftercms.path ?? models[parentModelId].craftercms.path);
    const trashButtonRef = React.useRef(undefined);
    const [showTrashConfirmation, setShowTrashConfirmation] = useState(false);
    const iceRecord = getById(record.iceIds[0]);
    const recordType = iceRecord.recordType;
    const collection = useMemo(() => {
        if (['node-selector-item', 'repeat-item'].includes(recordType)) {
            return extractCollection(getCachedModel(modelId), fieldId, index);
        }
        else if (recordType === 'component') {
            // ToDo: Find container collection
            const mapEntry = modelHierarchyMap[modelId];
            if (mapEntry && mapEntry.parentId) {
                return extractCollection(getCachedModel(mapEntry.parentId), mapEntry.parentContainerFieldPath, mapEntry.parentContainerFieldIndex);
            }
            else {
                return null;
            }
        }
        else {
            return null;
        }
    }, [modelId, fieldId, index, recordType]);
    const elementIndex = useMemo(() => {
        // If the record is a component, get the index from searching the
        // model id inside the container collection (previously computed).
        return recordType === 'component'
            ? collection?.indexOf(modelId)
            : parseInt(isSimple(index) ? String(index) : popPiece(String(index)));
    }, [recordType, collection, modelId, index]);
    const nodeSelectorItemRecord = useMemo(
    // region
    () => recordType === 'component'
        ? getById(exists({
            modelId: modelHierarchyMap[modelId].parentId,
            fieldId: modelHierarchyMap[modelId].parentContainerFieldPath,
            index: modelHierarchyMap[modelId].parentContainerFieldIndex
        }))
        : ['node-selector-item', 'repeat-item'].includes(recordType)
            ? iceRecord
            : null, 
    // endregion
    [modelId, recordType, iceRecord]);
    // TODO: Revisit how we detect files. Checking it has a key property doesn't feel robust.
    // File validations only applies to node-selector, not to repeating-group
    const isItemFile = collection && recordType === 'node-selector-item'
        ? Boolean(collection[elementIndex]?.hasOwnProperty('key'))
        : false;
    const collectionContainsFiles = collection && recordType === 'node-selector-item' ? collection.some((item) => item.hasOwnProperty('key')) : false;
    const componentId = recordType === 'component' ? modelId : recordType === 'node-selector-item' ? collection?.[elementIndex] : null;
    const componentPath = models[componentId]?.craftercms.path;
    const { field, contentType } = useMemo(() => getReferentialEntries(record.iceIds[0]), [record.iceIds]);
    // Use componentId to find the container modelId. If not a component, is unlikely to have a container, but in
    // cases where a page is being referenced by another model, we fall back to modelId.
    // If the current modelId is not being referenced by any other model (no parentModelId found), we use modelId.
    const containerModelId = findParentModelId(componentId ?? modelId, modelHierarchyMap, models) ?? modelId;
    const containerItemAvailableActions = models[containerModelId]
        ? getCachedSandboxItem(models[containerModelId].craftercms.path).availableActionsMap
        : null;
    const containerHasEditAction = containerItemAvailableActions?.edit ?? false;
    const itemAvailableActions = getCachedSandboxItem(componentPath ?? modelPath).availableActionsMap;
    const hasEditAction = itemAvailableActions.edit;
    const isMovable = containerHasEditAction &&
        (['node-selector-item', 'repeat-item'].includes(recordType) ||
            Boolean(recordType === 'component' && nodeSelectorItemRecord));
    const numOfItemsInContainerCollection = collection?.length;
    const isFirstItem = isMovable ? elementIndex === 0 : null;
    const isLastItem = isMovable ? elementIndex === numOfItemsInContainerCollection - 1 : null;
    const isOnlyItem = isMovable ? isFirstItem && isLastItem : null;
    const isEmbedded = useMemo(() => !Boolean(getCachedModel(modelId)?.craftercms.path), [modelId]);
    const showCodeEditOptions = hasEditAction && !isHeadlessMode && !isItemFile && ['component', 'page', 'node-selector-item'].includes(recordType);
    const showAddItem = hasEditAction && recordType === 'field' && field.type === 'repeat';
    const { isTrashable, showDuplicate } = useMemo(() => {
        const actions = {
            isTrashable: false,
            showDuplicate: false
        };
        const nodeSelectorEntries = Boolean(nodeSelectorItemRecord) ? getReferentialEntries(nodeSelectorItemRecord) : null;
        if (containerHasEditAction && Boolean(collection)) {
            const validations = nodeSelectorEntries?.field?.validations;
            const maxValidation = validations?.maxCount?.value;
            const minValidation = validations?.minCount?.value;
            const trashableValidation = minValidation ? minValidation < numOfItemsInContainerCollection : true;
            const duplicateValidation = permissions.includes('content_create') &&
                (maxValidation ? maxValidation > numOfItemsInContainerCollection : true);
            // The trash/duplicate are not applicable outside of item selector or repeat group type fields:
            if (
            // Record is an item, then options apply.
            ['node-selector-item', 'repeat-item'].includes(recordType) ||
                // A component has been directly selected (as opposed to an item selector item that was translated to a component):
                // must determine if it is part of an item selector and not a standalone model being rendered on to the page.
                Boolean(recordType === 'component' && nodeSelectorItemRecord)) {
                actions.isTrashable = trashableValidation && recordType !== 'field' && recordType !== 'page';
                actions.showDuplicate =
                    duplicateValidation && !isItemFile && ['repeat-item', 'component', 'node-selector-item'].includes(recordType);
            }
        }
        return actions;
    }, [
        nodeSelectorItemRecord,
        collection,
        numOfItemsInContainerCollection,
        permissions,
        containerHasEditAction,
        recordType,
        isItemFile
    ]);
    const showItemMenuButton = ['node-selector-item', 'component', 'page'].includes(recordType);
    const store = useStore();
    const getItemData = () => {
        const models = getCachedModels();
        const isNodeSelectorItem = recordType === 'component' && Boolean(nodeSelectorItemRecord);
        const itemModelId = isNodeSelectorItem ? nodeSelectorItemRecord.modelId : modelId;
        const itemFieldId = isNodeSelectorItem ? nodeSelectorItemRecord.fieldId : fieldId;
        const itemIndex = isNodeSelectorItem ? nodeSelectorItemRecord.index : index;
        const parentModelId = getParentModelId(itemModelId, models, modelHierarchyMap);
        const path = models[parentModelId ?? itemModelId].craftercms.path;
        return { path, itemModelId, itemFieldId, itemIndex };
    };
    // region Callbacks
    const execOperation = (subscriber) => {
        const { username, activeSite } = store.getState();
        const { path } = getItemData();
        beforeWrite$({
            path,
            site: activeSite,
            username,
            localItem: getCachedSandboxItem(path)
        }).subscribe(subscriber);
    };
    const onCancel = () => {
        clearAndListen$.next();
        dispatch(startListening());
    };
    const commonEdit = (e, typeOfEdit) => {
        e.stopPropagation();
        e.preventDefault();
        if (recordType === 'node-selector-item' && !collectionContainsFiles) {
            // If it's a node selector item, we transform it into the actual item.
            const parentModelId = getParentModelId(componentId, getCachedModels(), modelHierarchyMap);
            post(requestEdit({ typeOfEdit, modelId: componentId, parentModelId }));
        }
        else {
            let modelIdToEdit = modelId;
            // If inherited field - set correct modelId to edit
            if (record.inherited) {
                modelIdToEdit = getModelIdFromInheritedField(modelId, fieldId);
            }
            const parentModelId = getParentModelId(modelIdToEdit, getCachedModels(), modelHierarchyMap);
            post(requestEdit({
                typeOfEdit,
                modelId: modelIdToEdit,
                parentModelId,
                fields: record.fieldId,
                index
            }));
        }
        onCancel();
    };
    const onEdit = (e) => {
        commonEdit(e, 'content');
    };
    const onEditController = (e) => {
        commonEdit(e, 'controller');
    };
    const onEditTemplate = (e) => {
        commonEdit(e, 'template');
    };
    const onAddRepeatItem = (e) => {
        execOperation(() => {
            insertItem(modelId, fieldId, index, contentType);
        });
    };
    const onDuplicateItem = (e) => {
        execOperation(() => {
            if (recordType === 'component' && nodeSelectorItemRecord) {
                duplicateItem(nodeSelectorItemRecord.modelId, nodeSelectorItemRecord.fieldId, nodeSelectorItemRecord.index);
            }
            else {
                duplicateItem(modelId, fieldId, index);
            }
        });
        onCancel();
    };
    const onMoveUp = (e) => {
        e.preventDefault();
        e.stopPropagation();
        execOperation(() => {
            if (recordType === 'component' && nodeSelectorItemRecord) {
                sortUpItem(nodeSelectorItemRecord.modelId, nodeSelectorItemRecord.fieldId, nodeSelectorItemRecord.index);
            }
            else {
                sortUpItem(modelId, fieldId, index);
            }
        });
        onCancel();
    };
    const onMoveDown = (e) => {
        e.preventDefault();
        e.stopPropagation();
        execOperation(() => {
            if (recordType === 'component' && nodeSelectorItemRecord) {
                sortDownItem(nodeSelectorItemRecord.modelId, nodeSelectorItemRecord.fieldId, nodeSelectorItemRecord.index);
            }
            else {
                sortDownItem(modelId, fieldId, index);
            }
        });
        onCancel();
    };
    const doTrash = () => {
        setShowTrashConfirmation(false);
        const minCount = runValidation(findContainerRecord(modelId, fieldId, index).id, 'minCount', [
            numOfItemsInContainerCollection - 1
        ]);
        if (minCount) {
            post(snackGuestMessage(minCount));
        }
        else {
            execOperation(() => {
                if (recordType === 'component' && nodeSelectorItemRecord) {
                    deleteItem(nodeSelectorItemRecord.modelId, nodeSelectorItemRecord.fieldId, nodeSelectorItemRecord.index);
                }
                else {
                    deleteItem(modelId, fieldId, index);
                }
            });
            onCancel();
        }
    };
    const onTrash = (e) => {
        e.preventDefault();
        e.stopPropagation();
        setShowTrashConfirmation(true);
    };
    const onDragStart = (e) => {
        let _record = record;
        if (recordType === 'component' && nodeSelectorItemRecord) {
            _record = get(fromICEId(nodeSelectorItemRecord.id).id);
        }
        e.stopPropagation();
        e.dataTransfer.setData('text/plain', `${_record.id}`);
        e.dataTransfer.setDragImage(document.querySelector('.craftercms-dragged-element'), 20, 20);
        setTimeout(() => {
            dispatch({ type: 'dragstart', payload: { event: null, record: _record } });
        });
    };
    const handleRequestItemMenu = (e) => {
        e.stopPropagation();
        const path = recordType === 'component' || recordType === 'node-selector-item' ? (componentPath ?? modelPath) : modelPath;
        const top = e.clientY;
        const left = e.clientX;
        post(showItemMegaMenu({
            path,
            anchorReference: 'anchorPosition',
            anchorPosition: { top, left }
        }));
    };
    // endregion
    const refs = useRef({ onMoveUp, onMoveDown, onTrash, doTrash, onCancel, isFirstItem, isLastItem });
    // Listen for key input to sort/delete and for clicking outside the zone to dismiss selection.
    useEffect(() => {
        const onKeyDown = (e) => {
            switch (e.key) {
                case 'ArrowLeft':
                case 'ArrowUp': {
                    if (!refs.current.isFirstItem) {
                        refs.current.onMoveUp(e);
                    }
                    break;
                }
                case 'ArrowRight':
                case 'ArrowDown': {
                    if (!refs.current.isLastItem) {
                        refs.current.onMoveDown(e);
                    }
                    break;
                }
                case 'Backspace': {
                    e.preventDefault();
                    setShowTrashConfirmation(true);
                    break;
                }
            }
        };
        const onClickOut = (e) => {
            e.stopPropagation();
            e.preventDefault();
            refs.current.onCancel();
        };
        document.addEventListener('keydown', onKeyDown, false);
        document.addEventListener('click', onClickOut, false);
        return () => {
            document.removeEventListener('keydown', onKeyDown, false);
            document.removeEventListener('click', onClickOut, false);
        };
    }, []);
    return (_jsxs(_Fragment, { children: [_jsxs(Box, { display: "flex", children: [hasEditAction && !isLockedItem && (_jsx(UltraStyledTooltip, { title: _jsx(FormattedMessage, { id: "words.edit", defaultMessage: "Edit" }), children: _jsx(UltraStyledIconButton, { size: "small", onClick: onEdit, children: _jsx(PencilIcon, {}) }) }, "edit")), showCodeEditOptions && (_jsxs(_Fragment, { children: [itemAvailableActions.editTemplate && (_jsx(UltraStyledTooltip, { title: _jsx(FormattedMessage, { id: "zoneMenu.editTemplate", defaultMessage: "Edit template" }), children: _jsx(UltraStyledIconButton, { size: "small", onClick: onEditTemplate, children: _jsx(FreemarkerIcon, {}) }) }, "editTemplate")), itemAvailableActions.editController && (_jsx(UltraStyledTooltip, { title: _jsx(FormattedMessage, { id: "zoneMenu.editController", defaultMessage: "Edit controller" }), children: _jsx(UltraStyledIconButton, { size: "small", onClick: onEditController, children: _jsx(GroovyIcon, {}) }) }, "editController"))] })), !isLockedItem && showAddItem && (_jsx(UltraStyledTooltip, { title: _jsx(FormattedMessage, { id: "zoneMenu.addItem", defaultMessage: "Add new item" }), children: _jsx(UltraStyledIconButton, { size: "small", onClick: onAddRepeatItem, children: _jsx(AddCircleOutlineRoundedIcon, {}) }) }, "addNewItem")), showDuplicate && (_jsx(UltraStyledTooltip, { title: _jsx(FormattedMessage, { id: "zoneMenu.duplicateItem", defaultMessage: "Duplicate item" }), children: _jsx(UltraStyledIconButton, { size: "small", onClick: onDuplicateItem, children: _jsx(ContentCopyRoundedIcon, {}) }) }, "duplicateItem")), isMovable &&
                        (!isLockedItem || !isEmbedded) &&
                        !isOnlyItem && [
                        !isFirstItem && (_jsx(UltraStyledTooltip, { title: _jsx(FormattedMessage, { id: "zoneMenu.moveUp", defaultMessage: "Move up/left (\u2190 or \u2191)" }), children: _jsx(UltraStyledIconButton, { size: "small", onClick: onMoveUp, children: _jsx(ArrowUpwardRoundedIcon, {}) }) }, "moveUp")),
                        !isLastItem && (_jsx(UltraStyledTooltip, { title: _jsx(FormattedMessage, { id: "zoneMenu.moveDown", defaultMessage: "Move down/right (\u2192 or \u2193)" }), children: _jsx(UltraStyledIconButton, { size: "small", onClick: onMoveDown, children: _jsx(ArrowDownwardRoundedIcon, {}) }) }, "moveDown"))
                    ], isTrashable && !isLockedItem && (_jsx(UltraStyledTooltip, { title: _jsx(FormattedMessage, { id: "zoneMenu.trash", defaultMessage: "Trash (\u232B)" }), children: _jsx(UltraStyledIconButton, { size: "small", onClick: onTrash, ref: trashButtonRef, children: _jsx(DeleteOutlineRoundedIcon, {}) }) }, "trash")), isMovable && (!isLockedItem || !isEmbedded) && (_jsx(UltraStyledTooltip, { title: _jsx(FormattedMessage, { id: "words.move", defaultMessage: "Move" }), children: _jsx(UltraStyledIconButton, { size: "small", draggable: true, sx: { cursor: 'grab' }, onDragStart: onDragStart, children: _jsx(DragIndicatorRounded, {}) }) }, "move"))] }), _jsxs(Box, { display: "flex", children: [_jsx(Divider, { orientation: "vertical", flexItem: true, sx: { mx: 0.5 } }), showItemMenuButton && (_jsx(UltraStyledTooltip, { title: _jsx(FormattedMessage, { id: "words.options", defaultMessage: "Options" }), onClick: handleRequestItemMenu, children: _jsx(UltraStyledIconButton, { size: "small", children: _jsx(MoreRoundedIcon, {}) }) })), _jsx(UltraStyledTooltip, { title: _jsx(FormattedMessage, { id: "zoneMenu.cancel", defaultMessage: "Cancel (Esc)" }), children: _jsx(UltraStyledIconButton, { size: "small", onClick: onCancel, children: _jsx(CloseRoundedIcon, {}) }) })] }), _jsxs(Menu, { anchorEl: trashButtonRef.current, open: showTrashConfirmation, onClose: () => setShowTrashConfirmation(false), anchorOrigin: {
                    vertical: 'bottom',
                    horizontal: 'right'
                }, transformOrigin: {
                    vertical: 'top',
                    horizontal: 'right'
                }, sx: { zIndex: 1501 }, children: [_jsx(UltraStyledTypography, { variant: "body1", sx: { padding: '10px 16px 10px 16px' }, children: _jsx(FormattedMessage, { id: "zoneMenu.trashConfirmation", defaultMessage: "{isEmbedded, select, true {Delete} other {Disassociate}} this item?", values: { isEmbedded } }) }), _jsx(MenuItem, { onClick: (e) => {
                            e.preventDefault();
                            setShowTrashConfirmation(false);
                        }, children: _jsx(UltraStyledTypography, { children: _jsx(FormattedMessage, { id: "words.no", defaultMessage: "No" }) }) }), _jsx(MenuItem, { onClick: (e) => refs.current.doTrash(), children: _jsxs(UltraStyledTypography, { children: [_jsx(FormattedMessage, { id: "words.yes", defaultMessage: "Yes" }), ' '] }) })] })] }));
}
// Could use a more generic version...
// function IconButtonCollection({ actions }) {
//   return actions.map((action) => (
//     <Tooltip title={`${action.label} ${action.shortcut ?? ''}`.trim()}>
//       <UltraStyledIconButton size="small" {...action.props}>
//         <DragIndicatorRounded />
//       </UltraStyledIconButton>
//     </Tooltip>
//   ));
// }
export default ZoneMenu;
