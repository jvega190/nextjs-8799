import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { useEffect, useRef, useState } from 'react';
import { getZoneMarkerStyle } from '../utils/dom';
import { Box, Paper, Popper, Typography, useTheme } from '@mui/material';
import LevelDescriptorIcon from '@craftercms/studio-ui/icons/LevelDescriptor';
import FieldIcon from '@craftercms/studio-ui/icons/ContentTypeField';
import LockedStateIcon from '@craftercms/studio-ui/icons/Lock';
import { darken, styled } from '@mui/material/styles';
import { getCachedContentTypes } from '../contentController';
import { getAvatarWithIconColors } from '@craftercms/studio-ui/utils/contentType';
import UltraStyledTypography from './UltraStyledTypography';
import UltraStyledTooltip from './UltraStyledTooltip';
import { FormattedMessage, useIntl } from 'react-intl';
import { defineMessages } from 'react-intl';
const AllowedTypeCircle = styled('div')({
    width: 20,
    height: 20,
    borderStyle: `solid`,
    borderWidth: `1px`,
    borderRadius: '20px',
    display: 'inline-block',
    marginRight: '2px'
});
function getStyles(sx) {
    return {
        box: {
            boxSizing: 'border-box',
            outline: (theme) => `2px solid ${theme.palette.success.main}`,
            outlineOffset: '-2px',
            textAlign: 'center',
            position: 'absolute',
            zIndex: 'tooltip',
            pointerEvents: 'none',
            ...sx?.box
        },
        paper: {
            padding: [0.5, 1],
            fontSize: '14px',
            overflow: 'hidden',
            fontWeight: 700,
            pointerEvents: 'none',
            zIndex: 'tooltip',
            display: 'flex',
            alignItems: 'center',
            flexDirection: 'column',
            ...sx?.paper
        },
        icon: {
            marginRight: 1,
            fontSize: 21,
            ...sx?.icon
        },
        tooltip: {
            transition: 'none',
            zIndex: 'tooltip',
            ...sx?.tooltip
        },
        menuItemsContainer: {
            pointerEvents: 'all',
            alignItems: 'center',
            display: 'flex'
        }
    };
}
const dropTargetModesMessages = defineMessages({
    shared: { id: 'zoneMarker.existing', defaultMessage: 'existing' },
    embedded: { id: 'zoneMarker.embedded', defaultMessage: 'embedded' },
    sharedExisting: { id: 'zoneMarker.existingShared', defaultMessage: 'existing shared' }
});
export function ZoneMarker(props) {
    const { rect, label, classes, inherited, menuItems, showZoneTooltip = true, onPopperClick, lockInfo = null, isStale = false, isEditable, field } = props;
    const isLockedItem = Boolean(lockInfo);
    const [zoneStyle, setZoneStyle] = useState();
    const sx = getStyles(props.sx);
    const elRef = useRef(undefined);
    const theme = useTheme();
    let allowedTypesMeta;
    let contentTypes;
    if (field?.type === 'node-selector' && field.validations.allowedContentTypes) {
        allowedTypesMeta = field.validations.allowedContentTypes.value;
        contentTypes = getCachedContentTypes();
    }
    const { formatMessage } = useIntl();
    useEffect(() => {
        setZoneStyle(getZoneMarkerStyle(rect));
    }, [rect]);
    return (_jsxs(_Fragment, { children: [_jsx(Box, { ref: elRef, style: zoneStyle, sx: sx.box, className: ['craftercms-zone-marker', classes?.box].filter(Boolean).join(' ') }), showZoneTooltip && elRef.current && (_jsx(Popper, { open: true, anchorEl: elRef.current, placement: "top-start", onClick: onPopperClick, sx: sx.tooltip, className: "craftercms-zone-marker-tooltip", modifiers: [
                    {
                        name: 'offset',
                        options: {
                            offset: [0, 5]
                        }
                    }
                ], children: _jsxs(Paper, { className: classes?.paper, sx: sx.paper, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center' }, children: [isLockedItem || isStale ? (_jsx(LockedStateIcon, { sx: sx.icon })) : inherited ? (_jsx(LevelDescriptorIcon, { sx: sx.icon })) : (_jsx(FieldIcon, { sx: sx.icon })), _jsx(UltraStyledTypography, { title: label, noWrap: true, sx: { color: (sx?.paper).color }, children: label }), allowedTypesMeta && (_jsx(Box, { sx: { ml: 1, pointerEvents: 'all', display: 'flex', alignItems: 'center' }, onClick: (e) => e.stopPropagation(), children: Object.entries(allowedTypesMeta).map(([id, modes]) => {
                                        // 'id' can be '*' (meaning all content types), so we need to handle that scenario
                                        const type = id === '*'
                                            ? { id: 'all', name: formatMessage({ id: 'zoneMarker.allTypes', defaultMessage: 'All types' }) }
                                            : contentTypes[id];
                                        const { backgroundColor, textColor } = getAvatarWithIconColors(type?.id ?? type?.name, theme, darken);
                                        return (_jsx(UltraStyledTooltip, { arrow: true, title: _jsx(FormattedMessage, { id: "zoneMarker.dropTargetInfo", defaultMessage: "Drop target compatible with {type} as {modes}", values: {
                                                    type: type?.name ?? '',
                                                    modes: Object.keys(modes)
                                                        .map((mode) => dropTargetModesMessages[mode] ? formatMessage(dropTargetModesMessages[mode]) : mode)
                                                        .join(', ')
                                                } }), children: _jsx(AllowedTypeCircle, { sx: {
                                                    backgroundColor,
                                                    // TODO: The border colour is meant to contrast background colour of
                                                    //  the *Paper*, which is not set here and can be customized by app developers.
                                                    //  At the moment, is being set to the known colour set on guest/src/styles/styles.ts.
                                                    borderColor: textColor
                                                } }) }, id));
                                    }) }))] }), isLockedItem && (_jsx(Typography, { noWrap: true, variant: "body2", component: "div", children: _jsx(FormattedMessage, { id: "zoneMarker.lockedBy", defaultMessage: "Locked by {username}", values: { username: lockInfo.username } }) })), !isEditable && !isLockedItem && (_jsx(Typography, { noWrap: true, variant: "body2", component: "div", children: _jsx(FormattedMessage, { id: "zoneMarker.notEditable", defaultMessage: "Not editable" }) })), isStale && (_jsx(Typography, { noWrap: true, variant: "body2", component: "div", children: _jsx(FormattedMessage, { id: "zoneMarker.modifiedItem", defaultMessage: "Item was modified. Refresh to enable editing." }) })), menuItems && _jsx(Box, { sx: sx.menuItemsContainer, children: menuItems })] }) }))] }));
}
export default ZoneMarker;
