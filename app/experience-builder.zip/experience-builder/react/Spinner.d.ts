export interface SpinnerProps {
    width: number;
    height: number;
    strokeWidth: number;
    className: string;
    strokeLineCap: 'round' | 'butt' | 'square' | 'inherit';
    circleClassName: string;
}
export declare function Spinner(props: SpinnerProps): import("react/jsx-runtime").JSX.Element;
export default Spinner;
