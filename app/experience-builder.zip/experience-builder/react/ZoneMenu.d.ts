import { Dispatch } from 'react';
import { ElementRecord } from '../models/InContextEditing';
import { AnyAction } from '@reduxjs/toolkit';
export interface ZoneMenuProps {
    record: ElementRecord;
    dispatch: Dispatch<AnyAction>;
    isHeadlessMode: boolean;
    isLockedItem?: boolean;
}
export declare function ZoneMenu(props: ZoneMenuProps): import("react/jsx-runtime").JSX.Element;
export default ZoneMenu;
