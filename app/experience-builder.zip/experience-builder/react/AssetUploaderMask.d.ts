export interface AssetUploaderMaskProps {
    rect?: DOMRect;
    label?: string;
    id?: number;
    key?: number;
    progress?: number;
}
export declare function AssetUploaderMask(props: AssetUploaderMaskProps): import("react/jsx-runtime").JSX.Element;
export default AssetUploaderMask;
