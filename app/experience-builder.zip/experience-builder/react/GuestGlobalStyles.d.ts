import { XbUtilityClasses } from '../constants';
import { Interpolation } from '@emotion/react';
import { Theme } from '@mui/material/styles';
import { DeepPartial } from '@craftercms/studio-ui/models/DeepPartial';
export type GlobalStyleKeys = 'craftercms-asset-uploader-mask-container' | 'craftercms-asset-uploader-mask' | 'craftercms-field-instance-switcher' | '.craftercms-placeholder-spinner' | '.craftercms-content-tree-locate' | '.mce-content-body' | '@keyframes craftercms-uploader-mask-animation' | '@keyframes craftercms-placeholder-animation' | '@keyframes craftercms-placeholder-inner-animation' | '@keyframes craftercms-content-tree-locate-animation' | `.${XbUtilityClasses}`;
export type GuestGlobalStyleRules = Record<GlobalStyleKeys, Interpolation<Theme>>;
export interface GuestGlobalStylesProps {
    /**
     * Global styles for XB components. Please memoize your styles to avoid unnecessary renders. */
    styles?: DeepPartial<GuestGlobalStyleRules>;
}
export declare function GuestGlobalStyles(props: GuestGlobalStylesProps): import("react/jsx-runtime").JSX.Element;
export default GuestGlobalStyles;
