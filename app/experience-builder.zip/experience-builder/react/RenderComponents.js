import { jsx as _jsx } from "react/jsx-runtime";
import { forwardRef } from 'react';
import ContentType, { defaultContentTypeMap } from './ContentType';
import RenderRepeat from './RenderRepeat';
import PropTypes from 'prop-types';
export const RenderComponents = forwardRef((props, ref) => {
    const { contentTypeMap = defaultContentTypeMap, contentTypeProps = {}, nthContentTypeProps = {}, renderItem = (component, index) => (_jsx(ContentType, { model: component, contentTypeMap: contentTypeMap, ...contentTypeProps, ...nthContentTypeProps[index] })) } = props;
    return (_jsx(RenderRepeat, { ...props, 
        // Next like is to avoid compiler complaining about the `itemKeyGenerator` prop differences.
        // TODO: Is there a way to carry the type correctly?
        itemKeyGenerator: props.itemKeyGenerator, ref: ref, renderItem: renderItem }));
});
RenderComponents.propTypes = { ...RenderRepeat.propTypes, renderItem: PropTypes.func };
export default RenderComponents;
