import { jsx as _jsx } from "react/jsx-runtime";
import PropTypes from 'prop-types';
import { forwardRef } from 'react';
import Field from './Field';
import RenderField from './RenderField';
import { nnou, nou } from '@craftercms/studio-ui/utils/object';
import { useIsAuthoring } from './GuestContext';
export const RenderRepeat = forwardRef((props, ref) => {
    const { model, fieldId, index, component = 'div', componentProps, itemComponent = 'div', itemProps, renderItem = (item) => JSON.stringify(item, null, ' '), itemKeyGenerator = (item, index) => index } = props;
    const isAuthoring = useIsAuthoring();
    const subIndexGenerator = nnou(index) ? (i) => `${index}.${i}` : (i) => i;
    const itemPropsGenerator = nou(itemProps)
        ? () => void 0
        : typeof itemProps === 'function'
            ? itemProps
            : () => itemProps;
    return (_jsx(RenderField, { ref: ref, model: model, index: index, fieldId: fieldId, component: component, componentProps: componentProps, ...(isAuthoring && { 'data-craftercms-type': 'collection' }), render: (collection) => collection?.map((item, indexInCollection) => {
            const { ref, ...forwardProps } = itemPropsGenerator(item, indexInCollection, collection) ?? {};
            return (_jsx(Field, { ref: ref, model: model, index: subIndexGenerator(indexInCollection), fieldId: fieldId, component: itemComponent, componentProps: forwardProps, children: renderItem(item, subIndexGenerator(indexInCollection), indexInCollection, collection) }, itemKeyGenerator(item, indexInCollection, collection)));
        }) }));
});
RenderRepeat.propTypes = {
    // @ts-ignore
    model: PropTypes.object.isRequired,
    index: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
    fieldId: PropTypes.string.isRequired,
    // @ts-ignore
    component: PropTypes.elementType,
    componentProps: PropTypes.object,
    // @ts-ignore
    itemComponent: PropTypes.elementType,
    itemProps: PropTypes.oneOfType([PropTypes.func, PropTypes.object]),
    itemKeyGenerator: PropTypes.func,
    renderItem: PropTypes.func.isRequired
};
export default RenderRepeat;
