import * as React from 'react';
import { ElementType } from 'react';
import { RenderRepeatProps } from './RenderRepeat';
import { ContentInstance } from '@craftercms/studio-ui/models';
export type RenderComponentsProps<RootProps = {}, ItemProps = {}, ItemType extends ContentInstance = ContentInstance> = Omit<RenderRepeatProps<RootProps, ItemProps, ItemType>, 'renderItem'> & {
    contentTypeProps?: Record<string, any>;
    nthContentTypeProps?: Record<number, any>;
} & ({
    contentTypeMap: Record<string, ElementType>;
    renderItem?: RenderRepeatProps<RootProps, ItemProps, ItemType>['renderItem'];
} | {
    contentTypeMap?: Record<string, ElementType>;
    renderItem: RenderRepeatProps<RootProps, ItemProps, ItemType>['renderItem'];
});
export declare const RenderComponents: React.ForwardRefExoticComponent<RenderComponentsProps<{}, {}, ContentInstance> & React.RefAttributes<any>>;
export default RenderComponents;
