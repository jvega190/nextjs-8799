import React, { ElementType, PropsWithChildren } from 'react';
import { ICEProps } from '../models/InContextEditing';
import ContentInstance from '@craftercms/studio-ui/models/ContentInstance';
export type FieldProps<P = {}> = PropsWithChildren<P & {
    model: ContentInstance;
    index?: ICEProps['index'];
    fieldId?: ICEProps['fieldId'];
    component?: ElementType<P>;
    componentProps?: Partial<P>;
}>;
export declare const Field: React.ForwardRefExoticComponent<{
    model: ContentInstance;
    index?: ICEProps["index"];
    fieldId?: ICEProps["fieldId"];
    component?: React.ElementType<{}>;
    componentProps?: Partial<{}>;
} & {
    children?: React.ReactNode | undefined;
} & React.RefAttributes<any>>;
export default Field;
