import React, { ReactNode } from 'react';
import { FullSxRecord, PartialClassRecord, PartialSxRecord } from '@craftercms/studio-ui/models/CustomRecord';
import Person from '@craftercms/studio-ui/models/Person';
import { ContentTypeField } from '@craftercms/studio-ui/models/ContentType';
export type ZoneMarkerClassKey = 'box' | 'paper' | 'icon' | 'tooltip' | 'menuItemsContainer';
export type ZoneMarkerFullSx = FullSxRecord<ZoneMarkerClassKey>;
export type ZoneMarkerPartialSx = PartialSxRecord<ZoneMarkerClassKey>;
export interface ZoneMarkerProps {
    rect: DOMRect;
    label: string;
    inherited: boolean;
    showZoneTooltip?: boolean;
    menuItems?: ReactNode;
    lockInfo?: Person;
    isStale?: boolean;
    isEditable: boolean;
    onPopperClick?(e: React.MouseEvent<HTMLDivElement, MouseEvent>): void;
    sx?: ZoneMarkerPartialSx;
    classes?: PartialClassRecord<ZoneMarkerClassKey>;
    field?: ContentTypeField;
}
export declare function ZoneMarker(props: ZoneMarkerProps): import("react/jsx-runtime").JSX.Element;
export default ZoneMarker;
