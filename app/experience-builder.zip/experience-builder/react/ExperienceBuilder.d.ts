import React, { type PropsWithChildren } from 'react';
import { GuestStylesSx } from '../styles/styles';
import { ThemeOptions } from '@mui/material';
import { GuestGlobalStylesProps } from './GuestGlobalStyles';
import { ContentInstance } from '@craftercms/studio-ui/models';
import { DeepPartial } from '@craftercms/studio-ui/models/DeepPartial';
interface BaseXBProps {
    themeOptions?: ThemeOptions;
    sxOverrides?: DeepPartial<GuestStylesSx>;
    globalStyleOverrides?: GuestGlobalStylesProps['styles'];
    isAuthoring: boolean;
    scrollElement?: string;
    isHeadlessMode?: boolean;
}
type GenericXBProps<T> = PropsWithChildren<BaseXBProps & T>;
export type ExperienceBuilderProps = GenericXBProps<{
    model: ContentInstance;
} | {
    path: string;
}>;
export declare function ExperienceBuilder(props: GenericXBProps<{
    model: ContentInstance;
}>): React.JSX.Element;
export declare function ExperienceBuilder(props: GenericXBProps<{
    path: string;
}>): React.JSX.Element;
export default ExperienceBuilder;
