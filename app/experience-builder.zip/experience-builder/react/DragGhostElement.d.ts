import { Theme } from '@mui/material';
import { SxProps } from '@mui/system';
export interface DragGhostElementProps {
    sx?: SxProps<Theme>;
    label: string;
}
export declare function DragGhostElement(props: DragGhostElementProps): import("react/jsx-runtime").JSX.Element;
export default DragGhostElement;
