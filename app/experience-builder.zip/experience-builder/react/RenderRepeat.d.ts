import * as React from 'react';
import { ElementType, ReactElement } from 'react';
import ContentInstance from '@craftercms/studio-ui/src/models/ContentInstance';
import { ICEProps } from '../models/InContextEditing';
export interface RenderRepeatProps<RootProps = {}, ItemProps = {}, ItemType extends any = {}> {
    model: ContentInstance;
    index?: ICEProps['index'];
    fieldId: ICEProps['fieldId'];
    component?: ElementType<RootProps>;
    componentProps?: Partial<RootProps>;
    itemComponent?: ElementType<ItemProps>;
    itemProps?: Partial<ItemProps> | ((item: ItemType, index: number, collection: Array<ItemType>) => Partial<ItemProps>);
    itemKeyGenerator?: (item: ItemType, index: number, collection: Array<ItemType>) => string | number;
    renderItem(item: ItemType, fullIndex: string | number, indexInCollection: number, collection: Array<ItemType>): ReactElement;
}
export declare const RenderRepeat: React.ForwardRefExoticComponent<RenderRepeatProps<{}, {}, {}> & React.RefAttributes<any>>;
export default RenderRepeat;
