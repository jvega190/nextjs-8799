import React, { PropsWithChildren } from 'react';
export type CrafterCMSPortalProps = PropsWithChildren<{}>;
export declare function CrafterCMSPortal(props: CrafterCMSPortalProps): React.JSX.Element;
export default CrafterCMSPortal;
