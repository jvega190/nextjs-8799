import { PropsWithChildren } from 'react';
export type CrafterCMSPortalProps = PropsWithChildren<{}>;
export declare function CrafterCMSPortal(props: CrafterCMSPortalProps): ReactJSXElement;
export default CrafterCMSPortal;
