import { PropsWithChildren } from 'react';
export declare function I18nProvider(props: PropsWithChildren<{}>): import("react/jsx-runtime").JSX.Element;
