import { jsxs as _jsxs, jsx as _jsx } from "react/jsx-runtime";
export function FieldInstanceSwitcher(props) {
    const { onNext, onPrev, registryEntryIds, currentElement } = props;
    return (_jsxs("craftercms-field-instance-switcher", { children: [_jsxs("span", { children: [currentElement + 1, "/", registryEntryIds.length] }), _jsx("i", { onClick: onPrev, className: currentElement === 0 ? 'disable' : '', children: _jsx("svg", { focusable: "false", viewBox: "0 0 24 24", "aria-hidden": "true", children: _jsx("path", { d: "M14.71 6.71a.9959.9959 0 00-1.41 0L8.71 11.3c-.39.39-.39 1.02 0 1.41l4.59 4.59c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41L10.83 12l3.88-3.88c.39-.39.38-1.03 0-1.41z" }) }) }), _jsx("i", { onClick: onNext, className: currentElement + 1 === registryEntryIds.length ? 'disable' : '', children: _jsx("svg", { focusable: "false", viewBox: "0 0 24 24", "aria-hidden": "true", children: _jsx("path", { d: "M9.29 6.71c-.39.39-.39 1.02 0 1.41L13.17 12l-3.88 3.88c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0l4.59-4.59c.39-.39.39-1.02 0-1.41L10.7 6.7c-.38-.38-1.02-.38-1.41.01z" }) }) })] }));
}
export default FieldInstanceSwitcher;
