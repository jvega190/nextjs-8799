import React from 'react';
import { FieldProps } from './Field';
import ContentInstance from '@craftercms/studio-ui/models/ContentInstance';
export type RenderFieldProps<P, V = any, F = V> = Omit<FieldProps<P>, 'children'> & {
    renderTarget?: string;
    render?: (value: V, fieldId: string, model: ContentInstance) => F;
};
export declare const RenderField: React.ForwardRefExoticComponent<Omit<FieldProps<{}>, "children"> & {
    renderTarget?: string;
    render?: (value: any, fieldId: string, model: ContentInstance) => any;
} & React.RefAttributes<any>>;
export default RenderField;
