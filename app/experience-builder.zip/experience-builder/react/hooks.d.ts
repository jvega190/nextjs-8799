import { EventHandler, SyntheticEvent } from 'react';
import { ContentInstance } from '@craftercms/studio-ui/models/ContentInstance';
import { ICEProps } from '../models/InContextEditing';
import { MutableRef } from '@craftercms/studio-ui/models';
interface ICEHandlers {
    onMouseOver: EventHandler<SyntheticEvent<HTMLElement, MouseEvent>>;
    onMouseLeave: EventHandler<SyntheticEvent<HTMLElement, MouseEvent>>;
    onDragStart: EventHandler<SyntheticEvent<HTMLElement, MouseEvent>>;
    onDragOver: EventHandler<SyntheticEvent<HTMLElement, MouseEvent>>;
    onDragLeave: EventHandler<SyntheticEvent<HTMLElement, MouseEvent>>;
    onDrop: EventHandler<SyntheticEvent<HTMLElement, MouseEvent>>;
    onDragEnd: EventHandler<SyntheticEvent<HTMLElement, MouseEvent>>;
    onClick: EventHandler<SyntheticEvent<HTMLElement, MouseEvent>>;
    onDoubleClick: EventHandler<SyntheticEvent<HTMLElement, MouseEvent>>;
}
interface UseICEProps extends Omit<ICEProps, 'modelId'>, Partial<ICEHandlers> {
    ref?: MutableRef<any>;
    model: ContentInstance;
    noRef?: boolean;
}
interface ICEMaterials {
    model: ContentInstance;
    props: Partial<ICEHandlers> & {
        ref?: MutableRef<any>;
    };
}
interface UseModelProps extends Omit<ICEProps, 'modelId'> {
    model: ContentInstance;
}
export declare function useICE(props: UseICEProps): ICEMaterials;
export declare function useHotReloadModel(props: UseModelProps): any;
export declare function useFieldValue(props: UseModelProps): any;
export {};
