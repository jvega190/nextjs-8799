interface FieldInstanceSwitcherProps {
    currentElement: number;
    registryEntryIds: number[];
    onNext(): void;
    onPrev(): void;
}
export declare function FieldInstanceSwitcher(props: FieldInstanceSwitcherProps): import("react/jsx-runtime").JSX.Element;
export default FieldInstanceSwitcher;
