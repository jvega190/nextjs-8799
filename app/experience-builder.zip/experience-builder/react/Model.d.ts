import React from 'react';
import { FieldProps } from './Field';
export type ModelProps<P = {}> = Omit<FieldProps<P>, 'fieldId' | 'index'>;
export declare const Model: React.ForwardRefExoticComponent<ModelProps<{}> & React.RefAttributes<any>>;
export default Model;
