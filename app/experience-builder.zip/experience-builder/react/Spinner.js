import { jsx as _jsx } from "react/jsx-runtime";
export function Spinner(props) {
    const { width = 50, height = 50, strokeWidth = 6, className = 'spinner', strokeLineCap = 'round', circleClassName = 'path' } = props;
    return (_jsx("svg", { className: className, width: width, height: height, viewBox: "0 0 66 66", xmlns: "http://www.w3.org/2000/svg", children: _jsx("circle", { className: circleClassName, fill: "none", strokeWidth: strokeWidth, strokeLinecap: strokeLineCap, cx: "33", cy: "33", r: "30" }) }));
}
export default Spinner;
