import { jsx as _jsx } from "react/jsx-runtime";
export function Spinner(props) {
    return (_jsx("svg", { className: props.className, width: props.width, height: props.height, viewBox: "0 0 66 66", xmlns: "http://www.w3.org/2000/svg", children: _jsx("circle", { className: props.circleClassName, fill: "none", strokeWidth: props.strokeWidth, strokeLinecap: props.strokeLineCap, cx: "33", cy: "33", r: "30" }) }));
}
Spinner.defaultProps = {
    width: 50,
    height: 50,
    strokeWidth: 6,
    className: 'spinner',
    strokeLineCap: 'round',
    circleClassName: 'path'
};
export default Spinner;
