import { TooltipProps } from '@mui/material';
export declare const UltraStyledTooltip: (props: TooltipProps) => import("react/jsx-runtime").JSX.Element;
export default UltraStyledTooltip;
