import { jsx as _jsx } from "react/jsx-runtime";
/*
 * Copyright (C) 2007-2022 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import React, { useContext, useMemo } from 'react';
import { createDispatchHook, createSelectorHook, createStoreHook } from 'react-redux';
export const GuestReduxContext = React.createContext(null);
if (process.env.NODE_ENV !== 'production') {
    GuestReduxContext.displayName = 'GuestRedux';
}
export const useDispatch = createDispatchHook(GuestReduxContext);
export const useSelector = createSelectorHook(GuestReduxContext);
export const useStore = createStoreHook(GuestReduxContext);
const GuestContext = React.createContext(null);
export function useGuestContext() {
    return useContext(GuestContext);
}
export function useIsAuthoring() {
    const context = useGuestContext();
    return Boolean(context?.editMode && context.hasHost);
}
export function GuestContextProvider(props) {
    const value = useMemo(() => props.value, [props.value]);
    return _jsx(GuestContext.Provider, { ...props, value: value });
}
