import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { useMemo } from 'react';
import palette from '@craftercms/studio-ui/styles/palette';
import Global from '@mui/material/GlobalStyles';
import { dragAndDropActiveClass, editModeClass, editModePaddingClass, editOnClass, emptyCollectionClass, emptyFieldClass, eventCaptureOverlayAttribute, iceBypassKeyClass, moveModeClass } from '../constants';
import { deepmerge } from '@mui/utils';
import { typographyStyles } from '@craftercms/studio-ui/components/GlobalStyles/typography';
import { useIntl } from 'react-intl';
const overlayBackgroundColor = 'rgba(0, 0, 0, .4)';
export function GuestGlobalStyles(props) {
    const { styles } = props;
    const { formatMessage } = useIntl();
    return useMemo(() => (_jsxs(_Fragment, { children: [_jsx(Global, { styles: deepmerge({
                    // Elements
                    'craftercms-asset-uploader-mask-container': {
                        zIndex: 1010,
                        position: 'absolute',
                        pointerEvents: 'none'
                    },
                    'craftercms-asset-uploader-mask': {
                        background: 'white',
                        opacity: 0.5,
                        height: '100%',
                        width: '100%',
                        display: 'block',
                        transition: 'height 0.3s ease-out',
                        animation: 'craftercms-uploader-mask-animation 1.5s infinite ease-in-out'
                    },
                    'craftercms-field-instance-switcher': {
                        position: 'fixed',
                        bottom: '10px',
                        right: '10px',
                        backgroundColor: palette.white,
                        boxShadow: '0 2px 1px -1px rgba(0,0,0,0.2), 0 1px 1px 0 rgba(0,0,0,0.14), 0 1px 3px 0 rgba(0,0,0,0.12)',
                        padding: '10px 14px',
                        color: palette.black,
                        display: 'flex',
                        alignItems: 'center',
                        zIndex: 2,
                        '& .disable': {
                            pointerEvents: 'none',
                            opacity: '0.5'
                        },
                        '& i': {
                            display: 'inherit',
                            padding: '2px',
                            cursor: 'pointer'
                        },
                        '& svg': {
                            fill: 'currentColor',
                            width: '1em',
                            height: '1em',
                            display: 'inline-block',
                            fontSize: '1.5rem',
                            transition: 'fill 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms',
                            flexShrink: 0,
                            userSelect: 'none'
                        }
                    },
                    // Classes
                    '.craftercms-placeholder-spinner': {
                        animation: 'craftercms-placeholder-animation 2s linear infinite',
                        '& .path': {
                            stroke: palette.blue.main,
                            animation: 'craftercms-placeholder-inner-animation 1.5s ease-in-out infinite'
                        }
                    },
                    '.craftercms-content-tree-locate': {
                        animation: 'craftercms-content-tree-locate-animation 300ms 2 ease-in-out'
                    },
                    // region craftercms-ice-on
                    [`.${editModeClass}`]: {
                        '[data-craftercms-model-id], & [data-craftercms-model-id] a, & [data-craftercms-field], & [data-craftercms-field] a': {
                            cursor: 'url("/studio/static-assets/images/cursor-edit@1.5x.png"), pointer !important'
                        }
                    },
                    [`.${moveModeClass}`]: {
                        '[draggable="true"]': {
                            cursor: 'url("/studio/static-assets/images/cursor-drag@1.5x.png"), move !important'
                        }
                    },
                    [`.${dragAndDropActiveClass}`]: {},
                    [`.${editModePaddingClass}`]: {
                        '[data-craftercms-type="collection"]': {
                            paddingTop: '20px',
                            paddingRight: '20px',
                            paddingBottom: '20px',
                            paddingLeft: '20px'
                        }
                    },
                    [`.${editOnClass}`]: {
                        [`&.${moveModeClass} [${eventCaptureOverlayAttribute}]`]: {
                            background: overlayBackgroundColor,
                            '&::before': {
                                content: `"${formatMessage({
                                    id: 'globalStyles.contentHidden',
                                    defaultMessage: 'Content hidden to enable dragging.'
                                })}"`
                            },
                            '> *': {
                                visibility: 'hidden'
                            }
                        },
                        [`&.${iceBypassKeyClass} [${eventCaptureOverlayAttribute}]:hover::before`]: {
                            backgroundColor: overlayBackgroundColor,
                            content: `"${formatMessage({
                                id: 'globalStyles.turnOffEditMode',
                                defaultMessage: 'Turn off edit mode to interact with this element.'
                            })}"`
                        },
                        [`[${eventCaptureOverlayAttribute}]`]: {
                            position: 'relative',
                            '&::before': {
                                top: 0,
                                left: 0,
                                right: 0,
                                color: '#fff',
                                bottom: 0,
                                content: '""',
                                padding: '20px',
                                fontWeight: 'bold',
                                position: 'absolute'
                            }
                        },
                        [`.${emptyCollectionClass}`]: {
                            minHeight: '100px',
                            minWidth: '100px',
                            backgroundColor: overlayBackgroundColor,
                            '&::before': {
                                color: '#fff',
                                display: 'inline-block',
                                padding: '10px',
                                content: `"${formatMessage({
                                    id: 'globalStyles.emptyTarget',
                                    defaultMessage: 'Empty components target. Drag new or existing content items here to add them'
                                })}"`,
                                fontWeight: 'bold'
                            }
                        },
                        [`.${emptyFieldClass}`]: {
                            minHeight: '40px',
                            minWidth: '50px',
                            borderRadius: '5px',
                            backgroundColor: overlayBackgroundColor,
                            '&::before': {
                                color: '#fff',
                                display: 'inline-block',
                                padding: '10px',
                                content: `"${formatMessage({
                                    id: 'globalStyles.clickToAddContent',
                                    defaultMessage: 'Click to add content.'
                                })}"`,
                                fontWeight: 'bold'
                            }
                        }
                    },
                    // endregion
                    '.mce-content-body': {
                        outlineOffset: 5,
                        outline: `2px solid ${palette.blue.tint}`,
                        '&:focus': {
                            outline: `5px solid ${palette.blue.main}`
                        }
                    },
                    // Keyframes
                    '@keyframes craftercms-uploader-mask-animation': {
                        '0%': {
                            opacity: 0.4
                        },
                        '50%': {
                            opacity: 0.5
                        },
                        '100%': {
                            opacity: 0.4
                        }
                    },
                    '@keyframes craftercms-placeholder-animation': {
                        '100%': { transform: 'rotate(360deg)' }
                    },
                    '@keyframes craftercms-placeholder-inner-animation': {
                        '0%': { strokeDasharray: '1, 150', strokeDashoffset: '0' },
                        '50%': { strokeDasharray: '90, 150', strokeDashoffset: '-35' },
                        '100%': { strokeDasharray: '90, 150', strokeDashoffset: '-124' }
                    },
                    '@keyframes craftercms-content-tree-locate-animation': {
                        '0%': {
                            transform: 'scaleX(1)'
                        },
                        '50%': {
                            transform: 'scale3d(1.05,1.05,1.05)'
                        },
                        to: {
                            transform: 'scaleX(1)'
                        }
                    }
                }, styles ?? {}) }), _jsx(Global, { styles: typographyStyles })] })), [styles, formatMessage]);
}
export default GuestGlobalStyles;
