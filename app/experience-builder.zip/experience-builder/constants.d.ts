export type EditingStatuses = 'LISTENING' | 'SORTING_COMPONENT' | 'PLACING_NEW_COMPONENT' | 'PLACING_DETACHED_COMPONENT' | 'PLACING_DETACHED_ASSET' | 'EDITING_COMPONENT' | 'EDITING_COMPONENT_INLINE' | 'UPLOAD_ASSET_FROM_DESKTOP' | 'SHOW_DROP_TARGETS' | 'FIELD_SELECTED' | 'HIGHLIGHT_MOVE_TARGETS';
export type HighlightModes = 'all' | 'move';
export declare enum EditingStatus {
    LISTENING = "LISTENING",
    SORTING_COMPONENT = "SORTING_COMPONENT",
    PLACING_NEW_COMPONENT = "PLACING_NEW_COMPONENT",
    PLACING_DETACHED_COMPONENT = "PLACING_DETACHED_COMPONENT",
    PLACING_DETACHED_ASSET = "PLACING_DETACHED_ASSET",
    EDITING_COMPONENT = "EDITING_COMPONENT",
    EDITING_COMPONENT_INLINE = "EDITING_COMPONENT_INLINE",
    UPLOAD_ASSET_FROM_DESKTOP = "UPLOAD_ASSET_FROM_DESKTOP",
    SHOW_DROP_TARGETS = "SHOW_DROP_TARGETS",
    FIELD_SELECTED = "FIELD_SELECTED",
    HIGHLIGHT_MOVE_TARGETS = "HIGHLIGHT_MOVE_TARGETS"
}
export declare enum HighlightMode {
    ALL = "all",
    MOVE_TARGETS = "move"
}
export type XbUtilityClasses = 'craftercms-ice-on' | 'craftercms-ice-bypass' | 'data-craftercms-event-capture-overlay' | `craftercms-highlight-${HighlightModes}` | 'craftercms-empty-collection' | 'craftercms-empty-field' | 'craftercms-drag-n-drop-active' | 'craftercms-edit-mode-padding';
export declare const editOnClass: XbUtilityClasses;
export declare const iceBypassKeyClass: XbUtilityClasses;
export declare const moveModeClass: XbUtilityClasses;
export declare const editModeClass: XbUtilityClasses;
export declare const emptyCollectionClass: XbUtilityClasses;
export declare const emptyFieldClass: XbUtilityClasses;
export declare const dragAndDropActiveClass: XbUtilityClasses;
export declare const editModePaddingClass: XbUtilityClasses;
export declare const eventCaptureOverlayAttribute = "data-craftercms-event-capture-overlay";
export declare const editModeEvent = "craftercms.editMode";
export declare const xbLoadedEvent = "craftercms.xb:loaded";
export declare const editModeIceBypassEvent = "craftercms.iceBypass";
