/*
 * Copyright (C) 2007-2025 Crafter Software Corporation. All Rights Reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import { createIntl, createIntlCache } from 'react-intl';
import { Subject } from 'rxjs';
import { hostCheckIn } from '@craftercms/studio-ui/state/actions/preview';
import { fromTopic } from './communicator';
const importsLookup = {
    de: () => import('../translations/de.json'),
    es: () => import('../translations/es.json'),
    ko: () => import('../translations/ko.json')
};
/* private */
let currentTranslations = { en: {} };
/* private */
let fetchedLocales = { en: true };
/* private */
const intl$$ = new Subject();
/* public */
export const intl$ = intl$$.asObservable();
/* private */
// Default to English; Studio sends the authoring locale via hostCheckIn.
let intl = createIntl({ locale: 'en', messages: currentTranslations.en }, createIntlCache());
async function fetchLocale(locale) {
    const importFn = importsLookup[locale];
    if (!importFn) {
        return {};
    }
    const translations = await importFn();
    return translations.default;
}
async function createIntlInstance(localeCode) {
    if (!fetchedLocales[localeCode] && ['de', 'es', 'ko'].includes(localeCode)) {
        const fetchedTranslations = await fetchLocale(localeCode);
        currentTranslations[localeCode] = { ...currentTranslations[localeCode], ...fetchedTranslations };
        fetchedLocales[localeCode] = true;
    }
    return createIntl({
        locale: localeCode,
        messages: currentTranslations[localeCode] || currentTranslations.en
    }, createIntlCache());
}
let requestedLocale = intl.locale;
// Do not read localStorage here — guest may run for example in a Next.js app.
fromTopic(hostCheckIn.type).subscribe(({ payload }) => {
    const locale = payload?.locale;
    if (locale) {
        requestedLocale = locale;
    }
    if (locale && locale !== intl.locale) {
        createIntlInstance(locale).then((newIntl) => {
            if (locale !== requestedLocale)
                return;
            intl = newIntl;
            intl$$.next(newIntl);
        }, (error) => {
            if (locale !== requestedLocale)
                return;
            console.error(`[Guest] Failed to load locale "${locale}". Falling back to English.`, error);
            const fallbackIntl = createIntl({ locale: 'en', messages: currentTranslations.en }, createIntlCache());
            intl = fallbackIntl;
            intl$$.next(fallbackIntl);
        });
    }
});
export function getCurrentIntl() {
    return intl;
}
