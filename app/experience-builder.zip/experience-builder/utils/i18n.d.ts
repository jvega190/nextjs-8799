import { IntlShape } from 'react-intl';
export declare const intl$: import("rxjs").Observable<IntlShape>;
export declare function getCurrentIntl(): IntlShape;
