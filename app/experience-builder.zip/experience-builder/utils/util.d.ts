import { ElementRecord, ICERecord } from '../models/InContextEditing';
import LookupTable from '@craftercms/studio-ui/src/models/LookupTable';
import { ContentInstance, SandboxItem } from '@craftercms/studio-ui/models';
export declare const foo: (...args: any[]) => any;
export declare const //
X_AXIS = "X", Y_AXIS = "Y", HORIZONTAL = "horizontal", VERTICAL = "vertical", TOLERANCE_PERCENTS: {
    x: number;
    y: number;
}, DEFAULT_RECORD_DATA: ICERecord;
export declare function not(condition: boolean): boolean;
export declare function createLocationArgument(): Pick<Location, "host" | "hostname" | "href" | "origin" | "pathname" | "port" | "protocol" | "search" | "hash">;
export declare function isEditActionAvailable(args: {
    record: ElementRecord | ICERecord;
    models: LookupTable<ContentInstance>;
    sandboxItemsByPath: LookupTable<SandboxItem>;
    parentModelId: string | null;
}): boolean;
