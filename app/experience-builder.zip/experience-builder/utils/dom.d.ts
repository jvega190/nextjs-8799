import { Coordinates, DropMarkerPosition, DropMarkerPositionArgs, InRectStats } from '../models/Positioning';
import { LookupTable } from '@craftercms/studio-ui/models/LookupTable';
import { DropZone } from '../models/InContextEditing';
import { ValidationResult } from '@craftercms/studio-ui/models/ContentType';
import { CSSProperties } from 'react';
import { ContentTypeDropTarget } from '@craftercms/studio-ui/models/ContentTypeDropTarget';
export declare function sibling(element: HTMLElement, next: boolean): Element;
export declare function getDropMarkerPosition(args: DropMarkerPositionArgs): DropMarkerPosition;
export declare function splitRect(rect: DOMRect, axis?: string): DOMRect[];
export declare function insertDropMarker({ $dropMarker, insertPosition, refElement }: {
    $dropMarker: JQuery<any>;
    insertPosition: string;
    refElement: HTMLElement | JQuery | string;
}): void;
export declare function getDistanceBetweenPoints(p1: Coordinates, p2: Coordinates): number;
export declare function findClosestRect(parentRect: DOMRect, subRects: DOMRect[], coordinates: Coordinates): number;
export declare function getChildArrangement(children: Element[], childrenRects: DOMRect[], selfRect?: DOMRect): string;
export declare function getInRectStats(rect: DOMRect, coordinates: Coordinates, tolerancePercents?: Coordinates): InRectStats;
export declare function getRelativePointerPositionPercentages(mousePosition: Coordinates, rect: DOMRect): Coordinates;
export declare function isElementInView(element: Element, fullyInView?: boolean): boolean;
export declare function addAnimation(element: Element | HTMLElement, animationClass: string): void;
export declare function scrollToElement(element: Element, scrollElement: string, animate?: boolean): Element;
export declare function scrollToDropTargets(dropTargets: ContentTypeDropTarget[], scrollElement: string, getElementRegistry: (id: number) => Element): void;
export declare function updateDropZoneValidations(dropZone: DropZone, dropZones: DropZone[], validations: LookupTable<ValidationResult>): DropZone[];
export declare function getZoneMarkerStyle(rect: DOMRect, padding?: number): CSSProperties;
export declare function fadeIn(el: HTMLElement): void;
export declare function elementOffset(element: Element): {
    top: number;
    left: number;
};
export declare const DRAG_SCROLL_MARGIN = 150;
export declare const DRAG_SCROLL_STEP = 5;
export declare const DRAG_SCROLL_INTERVAL = 8;
/**
 * Returns the nearest scrollable parent element of the provided element.
 *
 * @param {Element} element - The element for which to find the nearest scrollable container.
 * @returns {Element} The closest scrollable parent element, or the document's scrolling element if none are found.
 */
export declare function getScrollContainer(element: Element): Element;
/**
 * Returns the visible bounds (top, bottom, left, right) for drag-scroll detection.
 * If the scroll container is the document, calculates bounds based on the viewport.
 * Otherwise, returns the bounding rect of the scroll container element.
 *
 * @param scrollContainer - Element to use for scrolling
 */
export declare function getDragScrollBounds(scrollContainer: Element): {
    top: number;
    bottom: number;
    left: number;
    right: number;
};
/**
 * Scrolls the given container vertically by the specified number of pixels.
 *
 * If the scroll container is the document's scrolling element, this function scrolls the window.
 * Otherwise, it scrolls the provided element by modifying its scrollTop property.
 *
 * @param {Element} scrollContainer - The container element to scroll. This can be a DOM element or the document's scrolling element.
 * @param {number} delta - The number of pixels by which to scroll vertically. Positive values scroll down, negative values scroll up.
 */
export declare function scrollContainerBy(scrollContainer: Element, delta: number): void;
