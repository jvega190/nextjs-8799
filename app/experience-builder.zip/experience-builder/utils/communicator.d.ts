import { Observable } from 'rxjs';
import StandardAction from '@craftercms/studio-ui/models/StandardAction';
export declare const message$: Observable<StandardAction>;
interface PostFunction {
    (action: StandardAction): void;
    (type: string, payload?: any): void;
}
export declare const post: PostFunction;
export declare function fromTopic(type: string): Observable<StandardAction>;
export {};
