import { LookupTable } from '@craftercms/studio-ui/models/LookupTable';
import { ContentTypeField } from '@craftercms/studio-ui/models/ContentType';
import { ContentInstance } from '@craftercms/studio-ui/models/ContentInstance';
import { ModelHierarchyMap } from '@craftercms/studio-ui/utils/content';
import { RecordTypes, ReferentialEntries } from '../models/InContextEditing';
export declare function findComponentContainerFields(fields: LookupTable<ContentTypeField> | ContentTypeField[]): ContentTypeField[];
export declare function getParentModelId(modelId: string, models: LookupTable<ContentInstance>, children: ModelHierarchyMap): string;
export declare function getCollectionWithoutItemAtIndex(collection: string[], index: string | number): string[];
export declare function getCollection(model: ContentInstance, fieldId: string, index: string | number): string[];
export declare function setCollection(model: ContentInstance, fieldId: string, index: number | string, collection: string[]): {
    [x: string]: any;
    craftercms: import("@craftercms/studio-ui/models/ContentInstance").ContentInstanceSystemProps;
};
export declare function determineRecordType(entities: Pick<ReferentialEntries, 'fieldId' | 'contentType' | 'index' | 'field'>): RecordTypes;
