import React from 'react';
import { TinyMCE } from 'tinymce';
declare global {
    interface Window {
        tinymce: TinyMCE;
        ace: AceAjax.Ace;
    }
    type CrafterCMSCustomElementProps = React.DetailedHTMLProps<Omit<React.HTMLAttributes<HTMLDivElement>, 'className'> & {
        class?: string;
    }, HTMLDivElement>;
    namespace JSX {
        interface IntrinsicElements {
            'craftercms-zone-marker': CrafterCMSCustomElementProps;
            'craftercms-asset-uploader-mask-container': CrafterCMSCustomElementProps;
            'craftercms-asset-uploader-mask': CrafterCMSCustomElementProps;
            'craftercms-field-instance-switcher': CrafterCMSCustomElementProps;
        }
    }
}
