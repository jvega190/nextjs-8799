import { ElementRecord } from '../models/InContextEditing';
import { ContentTypeFieldValidations } from '@craftercms/studio-ui/models/ContentType';
import { GuestStandardAction } from '../store/models/GuestStandardAction';
import { Observable } from 'rxjs';
import { RteSetup } from '../models/Rte';
export declare function initTinyMCE(path: string, record: ElementRecord, validations: Partial<ContentTypeFieldValidations>, rteSetup?: RteSetup): Observable<GuestStandardAction>;
