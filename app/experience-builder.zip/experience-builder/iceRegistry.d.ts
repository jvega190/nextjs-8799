import { ContentInstance } from '@craftercms/studio-ui/models/ContentInstance';
import { ContentType, ContentTypeField, ValidationKeys, ValidationResult } from '@craftercms/studio-ui/models/ContentType';
import { LookupTable } from '@craftercms/studio-ui/models/LookupTable';
import { ICEProps, ICERecord, ICERecordRegistration, ReferentialEntries } from './models/InContextEditing';
import { ModelHierarchyMap } from '@craftercms/studio-ui/utils/content';
import { Observer, Subscription } from 'rxjs';
import { AllowedContentTypesData } from '@craftercms/studio-ui/models/AllowedContentTypesData';
export declare const registry: Map<number, ICERecord>;
export interface AllowedContentTypesLookup {
    result: LookupTable<AllowedContentTypesData> | null;
    /**
     * Various instances of the content type can be present
     */
    recordIdKeyLookup: LookupTable<string>;
    allowedLookup: LookupTable<{
        recordIds: number[];
        data: Partial<AllowedContentTypesData>;
    }>;
}
export declare function register(registration: ICERecordRegistration): number;
export declare function deregister(id: number): ICERecord;
export declare function exists(data: Partial<ICEProps>): number;
export declare function getById(id: number | string): ICERecord;
export declare function isRepeatGroup(id: number): boolean;
export declare function isRepeatGroupItem(id: number): boolean;
export declare function getMediaDropTargets(type: string): ICERecord[];
export declare function getRecordDropTargets(id: number): ICERecord[];
export declare function getRepeatGroupItemDropTargets(repeatItemRecord: ICERecord): ICERecord[];
export declare function getComponentItemDropTargets(record: ICERecord): number[];
/**
 * Returns a list of ICE records that matches a content type
 * @param contentType {string | ContentType} The content type that the records should match.
 * @param excludeFn {(record: ICERecord, hierarchyMap: ModelHierarchyMap) => boolean} function that returns true if record has to be excluded, and false it not.
 * @param createMode {embedded | shared | sharedExisting | Array<embedded | shared | sharedExisting>} Check if the content is accepted based on a particular storage format (i.e. shared or embedded)
 */
export declare function getContentTypeDropTargets(contentType: string | ContentType, excludeFn?: (record: ICERecord, hierarchyMap: ModelHierarchyMap) => boolean, createMode?: CreateMode | CreateMode[] | undefined): ICERecord[];
export type CreateMode = 'embedded' | 'shared' | 'sharedExisting';
/**
 * Checks if a content type is accepted (as shared, embedded or at-all) by a specific receiver field
 * @param receiverField {ContentTypeField}
 * @param contentTypeId {string}
 * @param createMode {embedded | shared | sharedExisting | Array<embedded | shared | sharedExisting>}
 */
export declare function isTypeAcceptedAsByField(receiverField: ContentTypeField, contentTypeId: string, createMode?: CreateMode | CreateMode[] | undefined): boolean;
export declare function runDropTargetsValidations(dropTargets: ICERecord[]): LookupTable<LookupTable<ValidationResult>>;
export declare function runValidation(iceId: number, validationId: ValidationKeys, args?: unknown[]): ValidationResult;
export declare function getReferentialEntries(record: number | ICERecord): ReferentialEntries;
export declare function getRecordField(record: ICERecord): ContentTypeField;
export declare function isMovable(id: number): boolean;
export declare function isMovableType(id: number): boolean;
export declare function getMovableParentRecord(id: number): number;
export declare function collectMoveTargets(): ICERecord[];
export declare function checkComponentMovability(entries: ReferentialEntries): boolean;
export declare function checkRepeatGroupMovability(entries: ReferentialEntries): boolean;
export declare function findContainerField(model: ContentInstance, fields: ContentTypeField[], modelId: string): ContentTypeField;
export declare function flush(): void;
export declare function findContainerRecord(modelId: string, fieldId: string, index: string | number): ICERecord;
export declare function findChildRecord(modelId: string, fieldId: string, index: string | number): ICERecord;
export declare function getRegistry(): Map<number, ICERecord>;
export declare function getAllowedContentTypes(): AllowedContentTypesData;
export declare function subscribeToAllowedContentTypes(observerOrNext: Partial<Observer<LookupTable<AllowedContentTypesData>>> | ((value: LookupTable<AllowedContentTypesData>) => void)): Subscription;
