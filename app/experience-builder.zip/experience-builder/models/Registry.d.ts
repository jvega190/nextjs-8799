export interface RegistryEntry {
    id: number;
    element: Element;
    modelId: string;
    index: number | string;
    label: string;
    fieldId: string;
    iceId: number;
}
