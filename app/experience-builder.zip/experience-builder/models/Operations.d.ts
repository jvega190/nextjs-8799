export interface Operation {
    type: string;
    payload: any;
    state?: object;
    [id: string]: any;
}
