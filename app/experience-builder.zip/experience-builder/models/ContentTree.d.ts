export interface RenderTree {
    id: string;
    name: string;
    children: RenderTree[];
    type: string;
    modelId?: string;
    parentId?: string;
    embeddedParentPath?: string;
    fieldId?: string;
    index?: string | number;
}
